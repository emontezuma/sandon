import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { ServicioService } from '../servicio/servicio.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { DialogoComponent } from '../dialogo/dialogo.component';

@Component({
  selector: 'app-smed',
  templateUrl: './smed.component.html',
  styleUrls: ['./smed.component.css']
})
export class SmedComponent implements OnInit {

  @ViewChild("lstC0", { static: false }) lstC0: MatSelect;


  constructor(
    public servicio: ServicioService,
    public dialogRef: MatDialogRef<SmedComponent>, 
    public dialogo: MatDialog, 
    @Inject(MAT_DIALOG_DATA) public datos: any
  ) 
  {
    this.llenarPagers();
    this.rConfiguracion();
  }
  
  local: string = "";
  clavePublica: string = "";
  claveInterna: string = "";
  tipo: string = "";
  palabraClave: string = "CronosIntegracion2019";
  clave: string = "";
  movil: boolean = false;
  noLicenciados: number = 0;
  tEnviados: number = 0;
  seleccionMensaje = [];
  seleccionParte = [];
  configuracion: any;
  pagers: any = [];
  maquinas: any = [];
  partes: any = [];
  maquina: number = -1;
  error01: boolean = false;
  error02: boolean = false;
  error03: boolean = false;
  mensajeSMED: string = "";
  validar01: boolean = false;
  validar02: boolean = false;
  faltaMensaje: boolean = true;

  ngOnInit() {
  }

  llenarPagers()
  {
    this.pagers = [];
    let sentencia = "SELECT id, nombre, url_mmcall FROM " + this.servicio.rBD() + ".cat_generales WHERE  estatus = 'A' AND tabla = 100 ORDER BY nombre";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.pagers = resp
    })

    this.maquinas = [];
    sentencia = "SELECT a.id, a.url_mmcall, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, a.nombre AS nmaquina FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY nombre"
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.maquinas = resp
    })
  }

  llenarPartes()
  {
    this.servicio.activarSpinnerSmall.emit(true);  
    this.partes = [];
    this.seleccionParte = [];
    let sentencia = "SELECT a.id, a.nombre FROM " + this.servicio.rBD() + ".cat_partes a INNER JOIN " + this.servicio.rBD() + ".relacion_partes_maquinas b ON a.id = b.parte AND b.maquina = " + this.maquinas[this.maquina].id + " WHERE maquinas = 'N' AND estatus = 'A' UNION ALL SELECT id, nombre FROM " + this.servicio.rBD() + ".cat_partes WHERE maquinas = 'S' AND tipo > 0 AND estatus = 'A' ORDER BY nombre";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length>0)
      {
        this.partes = resp
      }
      
      setTimeout(() => {
        this.servicio.activarSpinnerSmall.emit(false);    
      }, 200);
      
    })
  }

  cambiando(evento: any)
  {
    this.mensajeSMED = "";
    if (this.seleccionParte.length > 0 && this.maquina)
    {
      let cadPartes = "";
      for (var i = 0; i < this.seleccionParte.length; i++)
      {
        cadPartes = cadPartes + this.partes[this.seleccionParte[i]].nombre + "-"
      }
      this.mensajeSMED = cadPartes + "SMED " + this.maquinas[this.maquina].nmaquina
      this.mensajeSMED = this.mensajeSMED.substring(0, 40);
    }
    else
    {
      this.mensajeSMED = "";
    }
    this.faltaMensaje = this.seleccionMensaje.length==0 || this.maquina ==-1 || this.seleccionParte.length==0
  }

  validar(id: number)
  {
    if (id == 1)
    {
      let sentencia = "SELECT CONCAT(key_number, serial) AS mmcall FROM mmcall.locations"
      let campos = {accion: 100, sentencia: sentencia};  
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        if (resp.length > 0)
        {
          this.clave = resp[0].mmcall;
          this.hacerLlamada();
        }        
      })    
        
    }
    else
    {
      this.datos.accion = id;
      this.dialogRef.close(this.datos);
    }
  }

  rConfiguracion()
  {
    this.configuracion = [];
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".configuracion";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.configuracion = resp[0]; 
        
      }
    }, 
    error => 
      {
        console.log(error)
      })
  }

  hacerLlamada()
  {
    let urlFinal = "";
    for (var i = 0; i < this.seleccionMensaje.length; i++)
    {
      urlFinal = urlFinal + this.pagers[this.seleccionMensaje[i]].url_mmcall + ";"
    }
    urlFinal = urlFinal.substr(0, urlFinal.length - 1);

    if (this.configuracion.ip_localhost)
    {
      urlFinal = urlFinal.replace(/localhost:8081/gi, this.configuracion.ip_localhost);
    }
    
    let str = this.mensajeSMED;
    if (urlFinal=="")
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "400px", panelClass:  'dialogo', data: { titulo: "No se pudo enviar el mensaje", mensaje: "No se halló ningún webservice de MMCall asociado a los pager(s) seleccionado(s).<br><br><strong>Por favor consulte con su administrador de la aplicación e intente de nuevo</strong>", alto: "40", id: 0, accion: 0, tiempo: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "in_detener" }
      });
    }
    else
    {
      setTimeout(() => {
        this.finalizaLlamada()
      }, 1000);
      str = this.servicio.tildes(str, "M").substr(0, 40);
      str = str.replace(/[&\/\\()$~%.'":*#?<>{}]/g, " ");
      let destinos =  urlFinal.split(";");
      let mensajes: number = 0;
      let buenos: number = 0;
      let noLicenciados = 0;
      for (var i = 0; i < destinos.length; i++)
      {
        
        if (destinos[i].length > 0)
        {
          this.tEnviados = this.tEnviados + 1;
          let urlActual = destinos[i];
          let directo: boolean = false;
          let radio = destinos[i].indexOf("number=");
          if (radio == -1)
          {
            directo = true;
            radio = +destinos[i];

          }
          if (radio > 0)
          {
            let numeroRadio = destinos[i].substr(radio + 7);
            if (directo) 
            {
              numeroRadio = '' + radio;
            }
            let sentencia = "SELECT " + i + " AS numero, tipo, mmcall, cronos FROM " + this.servicio.rBD() + ".licencias WHERE tipo = 'R' AND mmcall = '" + numeroRadio + "'";
            let campos = {accion: 100, sentencia: sentencia};  
            this.servicio.consultasBD(campos).subscribe( resp =>
            {
              if (resp.length > 0)
              {
                this.local = resp[0].mmcall;
                this.tipo = resp[0].tipo;
                this.generarClave()
                let validada = true;
                let cadComparar = "";
                for (var jj = 0; jj < this.clavePublica.length; jj++) 
                {
                  let numero = (this.clavePublica[jj].charCodeAt(0) ^ this.claveInterna[jj].charCodeAt(0)).toString();
                  if (numero.length == 1)
                  {
                    cadComparar = numero;
                  }
                  else if (numero.length == 2)
                  {
                    cadComparar = numero.substr(1);
                  }
                  else if (numero.length == 3)
                  {
                    cadComparar = numero.substr(1, 1);
                  }
                  if (cadComparar != resp[0].cronos[jj])
                  {
                    validada = false;
                    break;
                  }
                }
                if (validada || this.configuracion.pagers_val=='N')
                {
                  let campos = {accion: 300, url: destinos[+resp[0].numero], mensaje: str, pager: numeroRadio };  
                  this.servicio.llamadaMMCall(campos).subscribe( resp =>
                  {
                    
                    if (resp == "success")
                    {
                      buenos = buenos + 1;            
                    }
                    
                  //},
                  //error => 
                  //{
                    //eemv quitar
                  //  const respuesta = this.dialogo.open(DialogoComponent, {
                  //    width: "450px", panelClass:  'dialogo_atencion', data: { titulo: "¡REPORTE NO GENERADO!", mensaje: "Atención, hubo un problema en el envío de mensajes a MMCall: <br><br>Mensaje de error: " + error.message + "<br><br>Informe de este problema al administrador del sistema", alto: "40", id: 0, accion: 0, tiempo: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "in_detener" }
                  //  });   
                  })
                } 
                else
                {
                  this.noLicenciados = this.noLicenciados + 1;
                }
                if (urlActual == destinos[destinos.length - 1])
                {
                  //this.finalizaLlamada(destinos.length, noLicenciados)
                }
                
              }

              
            })
          }         
        }
      }
    }
  }

  finalizaLlamada()
  {
    let mensajeCompleto: any = [];
    mensajeCompleto.clase = "snack-normal";
    mensajeCompleto.mensaje = "Se " + (this.tEnviados == 1 ? "envió un mensaje" : "enviaron " + this.tEnviados + " mensajes") + " a MMCall.";
    mensajeCompleto.tiempo = 3000;
    this.servicio.mensajeToast.emit(mensajeCompleto);
    this.maquina = -1;
    this.mensajeSMED = "";
    this.faltaMensaje = true;
    this.seleccionMensaje = [];
    this.seleccionParte = [];
    setTimeout(() => {
      this.lstC0.focus()  
    }, 100);
    if (this.noLicenciados > 0)
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "450px", panelClass:  'dialogo_atencion', data: { titulo: "MENSAJE(S) NO ENVIADO(S)", mensaje: "Atención, uno o más pagers no tienen una licencia válida.<br><br>Mensaje(s) previsto(s): <strong>" + this.tEnviados + "</strong><br>Mensaje(s) no enviados(s): <strong>" + this.noLicenciados + "</strong><br><br>Informe de este problema al administrador del sistema", alto: "40", id: 0, accion: 0, tiempo: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "in_detener" }
      });
      respuesta.afterClosed().subscribe(result => 
      {
      }) 
    }
  }

  alterarPalabraClave()
  {
    let nvaPalabra = ""
    let palabraNueva = "ElViS"
    let ciclo = 0;
    for (var i = 0; i < this.palabraClave.length; i++) 
    {
      
      if (i > 0 && i % 5 == 0)
      {
        nvaPalabra = nvaPalabra + palabraNueva[ciclo];
        ciclo = ciclo + 1
      }
      else
      {
        nvaPalabra = nvaPalabra + this.palabraClave[i];
      }
    } 
    return nvaPalabra;  
  }

  generarClave()
  {
    if (!this.local)
    {
      this.clavePublica = "";
      return;
    }
    else if (this.local == "")
    {
      this.clavePublica = "";
      return;
    }

    this.clavePublica = "";
    this.claveInterna = this.alterarPalabraClave();
    let temporal = "";
    let temporal2 = "";
    let numero = "";
    let numero2 = 0;
    let buscarEn = 0;
    let posicion = 0;
    let numeroActual = 0;
    let recorrido = 0;
    if (this.claveInterna.length > this.local.length)
    
    {
      temporal = "";
      temporal2 = this.claveInterna;
      
      do
      {
        if (recorrido >= this.clave.length)
        {
          recorrido = 0;
        }
        numero = this.local[recorrido % this.local.length].charCodeAt(0).toString();
        numero2 = +this.clave[recorrido];

        if (numero.length == 1)
        {
          buscarEn = +numero;
          numeroActual = 0;  
        }
        else if (numero.length == 2)
        {
          let numero1 = +numero.substr(0, 1);
          let numero2 = +numero.substr(1);  
          if (numeroActual == 0)
          {
            buscarEn = numero1;
            numeroActual = 1;  
          }
          else
          {
            buscarEn = numero2;
            numeroActual = 0;  
          }
          posicion = numero1 + numero2 + recorrido;
        }
        else if (numero.length == 3)
        {
          let numero1 = +numero.substr(0, 1);
          let numero2 = +numero.substr(1, 1);  
          let numero3 = +numero.substr(2);  
          if (numeroActual == 0)
          {
            buscarEn = numero1;
            numeroActual = 1;  
          }
          else if (numeroActual == 1)
          {
            buscarEn = numero2;
            numeroActual = 2;  
          }
          else 
          {
            buscarEn = numero3;
            numeroActual = 0;  
          }
          posicion = numero1 + numero2 + numero3 + recorrido;
        }
        posicion = posicion + numero2;
        if (posicion > this.clave.length - 1)
        {
          posicion = posicion % this.clave.length
        }
        temporal = (temporal. length == 0 ? this.tipo : "") + temporal + this.clave[posicion];  
        recorrido = recorrido + 1;
      }
      while (temporal.length < this.claveInterna.length)
      temporal = temporal.substr(0, this.claveInterna.length);
    }
    else if (this.claveInterna.length == this.local.length)
    {
      temporal = this.local;
      temporal2 = this.claveInterna;
    }
    
    else if (this.local.length > this.claveInterna.length)
    {
      temporal = this.local;
      temporal2 = this.claveInterna;
      do
      {
        temporal2 = temporal2 + this.claveInterna;  
      }
      while (temporal2.length < this.local.length)
      temporal2 = temporal2.substr(0, this.local.length);
    }
    let cadComparar = "";
    for (var i = 0; i < temporal.length; i++) 
      {
        let numero = (temporal[i].charCodeAt(0) ^ temporal2[i].charCodeAt(0)).toString();
        if (numero. length == 1)
        {
          cadComparar = numero;
        }
        else if (numero.length == 2)
        {
          cadComparar = numero.substr(1);
        }
        else if (numero.length == 3)
        {
          cadComparar = numero.substr(1, 1);
        }
        this.clavePublica = this.clavePublica + cadComparar; 
      }
  }


}
