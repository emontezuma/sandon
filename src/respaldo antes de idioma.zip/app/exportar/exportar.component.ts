import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { ServicioService } from '../servicio/servicio.service';
import { ActivatedRoute, GuardsCheckStart } from '@angular/router';
import { trigger, style, animate, transition, query, group, state, stagger } from '@angular/animations';
import { ScrollDispatcher, CdkScrollable } from '@angular/cdk/scrolling';
import { Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ViewportRuler } from "@angular/cdk/overlay";
import { MatDialog } from '@angular/material/dialog';
import { MatSelectionList } from '@angular/material/list';
import { DialogoComponent } from '../dialogo/dialogo.component';
import { Router } from '@angular/router';
import { SesionComponent } from '../sesion/sesion.component';
import { DxChartComponent } from "devextreme-angular";
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-exportar',
  templateUrl: './exportar.component.html',
  styleUrls: ['./exportar.component.css'],
  animations: [
    trigger('esquema', [
      transition(':enter', [
        style({ opacity: 0.3, transform: 'translateY(5px)' }),
        animate('0.15s', style({ opacity: 1, transform: 'translateY(0px)' })),
      ]),
      transition(':leave', [
        animate('0.15s', style({ opacity: 0, transform: 'translateY(5px)' }))
      ])
    ]),
    trigger('esquema_del', [
      transition(':enter', [
        style({ opacity: 0.3, transform: 'translateY(5px)' }),
        animate('0.25s', style({ opacity: 1, transform: 'translateY(0px)' })),
      ]),
      transition(':leave', [
        animate('0.25s', style({ opacity: 0, transform: 'translateY(5px)' }))
      ])
    ]),
    trigger('esquema_top', [
      transition(':enter', [
        style({ opacity: 0.3, transform: 'translateY(-15px)' }),
        animate('0.2s', style({ opacity: 1, transform: 'translateY(0px)' })),
      ]),
      transition(':leave', [
        animate('0.2s', style({ opacity: 0, transform: 'translateY(-15px)' }))
      ])
    ]),
    trigger('arriba', [
    transition(':enter', [
      style({ opacity: 0.3, transform: 'scale(0.3)' }),
      animate('0.1s', style({ opacity: 1, transform: 'scale(1)' })),
    ]),
    transition(':leave', [
      animate('0.1s', style({ opacity: 0.3, transform: 'scale(0.3)' }))
    ])
  ]),]
})

  
export class ExportarComponent implements OnInit {

  @ViewChild("txtBuscar", { static: false }) txtBuscar: ElementRef;
  @ViewChild("txtNombre", { static: false }) txtNombre: ElementRef;
  @ViewChild("txtDesde", { static: false }) txtDesde: ElementRef;
  @ViewChild("txtHasta", { static: false }) txtHasta: ElementRef;
  @ViewChild(DxChartComponent, { static: false }) chart: DxChartComponent;
  @ViewChild("listaLineas", { static: false }) listaLineas: MatSelectionList;
  @ViewChild("listaMaquinas", { static: false }) listaMaquinas: MatSelectionList;
  @ViewChild("listaAreas", { static: false }) listaAreas: MatSelectionList;
  @ViewChild("listaFallas", { static: false }) listaFallas: MatSelectionList;
  @ViewChild("listaTecnicos", { static: false }) listaTecnicos: MatSelectionList;
  @ViewChild("listaTurnos", { static: false }) listaTurnos: MatSelectionList;
  @ViewChild("listaPartes", { static: false }) listaPartes: MatSelectionList;
  @ViewChild("listaLotes", { static: false }) listaLotes: MatSelectionList;
  @ViewChild("listaProcesos", { static: false }) listaProcesos: MatSelectionList;
  
  scrollingSubscription: Subscription;
  vistaCatalogo: Subscription;
  //URL_FOLDER = "http://localhost:8081/sigma/assets/datos/";  
  URL_FOLDER = "/sigma/assets/datos/";  

  constructor
  (
    public servicio: ServicioService,
    private route: ActivatedRoute,
    public scroll: ScrollDispatcher,
    private http: HttpClient,
    public dialogo: MatDialog, 
    private router: Router, 
    public datepipe: DatePipe,
    private viewportRuler: ViewportRuler
  ) {

    this.servicio.mensajeError.subscribe((mensaje: any)=>
    {
      let mensajes = mensaje.split(";");
      if (mensajes[0] == 1)
      {
        this.pantalla = 1;
        this.servicio.mensajeInferior.emit("Por favor comuníque este error a su soporte de TI local");
        this.errorMensaje = mensajes[1];
      }
    });

    this.servicio.vista.subscribe((accion: number)=>
    {
      if (accion == 22)
      {
        this.graficando = true;
        this.filtrando = false;
        this.verTop = true;
        this.modelo = 11;
        this.servicio.mensajeInferior.emit("Exportar datos");   
      }
      else if (accion == 23)
      {
        this.graficando = true;
        this.filtrando = false;
        this.verTop = false;
        this.listarAlarmas()
        this.modelo = 13;
        this.iniLeerBD()
      }
      this.servicio.mostrarBmenu.emit(0);
    });
    this.servicio.cadaSegundo.subscribe((accion: boolean)=>
    {
      if (this.router.url.substr(0, 9) == "/exportar")
      {
        this.revisarTiempo();
      }
    });
    this.scrollingSubscription = this.scroll
      .scrolled()
      .subscribe((data: CdkScrollable) => {
        this.miScroll(data);
    });
    this.rConfiguracion();
    this.aplicarConsulta(0);
    
    if (this.servicio.rVista() == 23)
      {
        this.listarAlarmas()
        this.modelo = 3;
        this.iniLeerBD()
        this.verTop = false;
      }
      else
      {
        this.verTop = true;
      }
  }

  ngOnInit() {
    this.servicio.validarLicencia(1)
    this.servicio.mostrarBmenu.emit(0);
  }

  verTop: boolean = true;
  yaConfirmado: boolean = false;
  modelo: number  = 1;
  offSet: number;
  verIrArriba: boolean = false;
  filtrarC: boolean = false;
  hayFiltro: boolean = false
  eliminar: boolean = false;
  editando: boolean = false;
  graficando: boolean = true;
  verBuscar: boolean = true;
  verTabla: boolean = false;
  cambioVista: boolean = true;
  movil: boolean = false;
  parIndicador: string = "1.0-1"
  verGrafico: boolean = false;
  error01: boolean = false;
  error02: boolean = false;
  error03: boolean = false;
  nCatalogo: string = "LÍNEAS DE PRODUCCIÓN"
  verBarra: string = "";
  ultimoReporte: string = "";
  nombreFile: string = "";
  ultimoID: number = 0;
  copiandoDesde: number = 0;
  selLineasT: string = "S";
  selMaquinasT: string = "S";
  selAreasT: string = "S";
  selTecnicosT: string = "S";
  selTurnosT: string = "S";
  selPartesT: string = "S";
  selLotesT: string = "S";
  selFallasT: string = "S";
  selProcesosT: string = "S";
  textoBuscar: string = "";
  miGrafica: any = [];
  tecnicos: any = [];
  partes: any = [];
  turnos: any = [];
  lotes: any = [];
  procesos: any = [];
  arreTiempos: any = [];
  consultas: any = [];
  maquinas: any = [];
  parGrafica: any = [];
  sentenciaR: string = "";
  reporteActual: string = "";
  reporteSel: number = 1;
  consultaTemp: string = "0";
  consultaBuscada: boolean = false;
  
  ultimaActualizacion = new Date();
  errorTitulo: string = "Ocurrió un error durante la conexión al servidor";
  errorMensaje: string = "";
  pantalla: number = 2;  
  miSeleccion: number = 1;
  iconoGeneral: string = "i_alarmas";
  icono_grafica: string = "";
  iconoVista: string = "";
  literalVista: string = "Ver detalle";
  tituloBuscar: string = "";
  alarmados: number = 0;
  elTiempo: number = 0;
  despuesBusqueda: number = 0;
  enCadaSegundo: boolean = false;
  botElim: boolean = false;
  botGuar: boolean = false;
  botCan: boolean = false;
  contarTiempo: boolean = false;
  visualizarImagen: boolean = false;
  sondeo: number = 0;
  registros: any = [];
  opciones: any = [];
  arrFiltrado: any = [];
  detalle: any = [];
  titulos: any = [];
  ayudas: any = [];
  cronometro: any;
  leeBD: any;
  nombreReporte: string = "";
  laSeleccion: any = [];
  configuracion: any = [];
  fallas: any = [];
  lineas: any = [];
  areas: any = [];
  agrupadores1: any = [];
  agrupadores2: any = [];
  arreImagenes: any = [];
  arreHover: any = [];
  notas: string = "";
  hoverp01: boolean = false;
  hoverp02: boolean = false;
  noLeer: boolean = false;
  operacioSel: boolean = false;
  maquinaSel: boolean = false;
  reparandoSel: boolean = false;
  abiertoSel: boolean = false;
  lineaSel: boolean = false;
  filtrando: boolean = false;
  faltaMensaje: string = "";
  responsableSel: boolean = false;
  fallaSel: boolean = false;
  rAlarmado: string = "N";
  horaReporte;
  mensajePadre: string = "";
  filtroParos: string = "";
  filtroAlarmas: string = "";
  filtroFechas: string = "";
  filtroFechasDia: string = "";
  filtroReportes: string = "";
  filtroOEE: string = "";
  filtroWIP: string = "";
  filtroTrazabilidad: string = "";
  filtroCalidad: string = "";
  URL_BASE = "/sigma/api/upload.php"
  URL_IMAGENES = "/sigma/assets/imagenes/";
  mostrarDetalle: boolean = false;
  grActual: number = +this.servicio.rUsuario().preferencias_andon.substr(41, 1);

  ayuda01 = ""

  botonera1: number = 1;
  boton01: boolean = true;
  boton02: boolean = true;
  boton03: boolean = true;
  boton04: boolean = true;

  bot1: boolean = true;
  bot2: boolean = true;
  bot3: boolean = true;
  bot4: boolean = true;
  bot5: boolean = true;
  bot6: boolean = true;
  bot7: boolean = true;

  guardarSel: boolean = true;
  bot1Sel: boolean = false;
  bot2Sel: boolean = false;
  bot3Sel: boolean = false;
  bot4Sel: boolean = false;
  bot5Sel: boolean = false;
  bot6Sel: boolean = false;
  bot7Sel: boolean = false;

  maxmin: {startValue: "0", endValue: 20};

  boton11: boolean = true;
  boton12: boolean = true;
  boton13: boolean = false;

  animando: boolean = true;
  listoMostrar: boolean = true;

  literalSingular: string = "";
  literalSingularArticulo: string = "";
  literalPlural: string = "";

  ayuda11: string = "Cambiar a vista"

    irArriba() 
  {
    this.verIrArriba = false;
    document.querySelector('[cdkScrollable]').scrollTop = 0;    
  }

  miScroll(data: CdkScrollable) 
  {
    const scrollTop = data.getElementRef().nativeElement.scrollTop || 0;
      if (scrollTop < 5) 
      {
        this.verIrArriba = false
      }
      else 
      {
        this.verIrArriba = true
        clearTimeout(this.cronometro);
        this.cronometro = setTimeout(() => {
          this.verIrArriba = false;
        }, 3000);
      }

    this.offSet = scrollTop;
  }


  salidaEfecto(evento: any)
  {
    if (evento.toState)
    {
      this.modelo = this.modelo - 10;
    }
  }

  mostrar(modo: number)
  {
    if (modo == 1 && this.registros.length == 0)
    {
      this.listoMostrar = true;
    }
    else if (this.registros.length > 0)
    {
      this.listoMostrar = false;
    }
    
  }
  rConfiguracion()
  {
    this.configuracion = [];
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".configuracion";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.configuracion = resp[0]; 
      }
    }, 
    error => 
      {
        console.log(error)
      })
  }

  descargarInfo()
  {
    this.nombreReporte = "Reportes de mantenimiento"
    this.reporteActual = "reportes_de_mantenimiento"
    let sentencia = "SELECT COUNT(c.id) AS cuenta FROM " + this.servicio.rBD() + ".reportes c WHERE c.estatus >= 0 " + this.filtroReportes + ";";
    if (this.reporteSel==2)
    {
      this.nombreReporte = "LOG de eventos"
      this.reporteActual = "log_eventos"
      sentencia = "SELECT COUNT(*) AS cuenta FROM " + this.servicio.rBD() + ".log WHERE id > 0 AND " + this.filtroFechas + ";";
    }
    else if (this.reporteSel==3)
    {
      this.nombreReporte = "Todas las alarmas"
      this.reporteActual = "todas_las_alarmas"
      sentencia = "SELECT COUNT(*) AS cuenta FROM " + this.servicio.rBD() + ".alarmas a WHERE a.id > 0 AND " + this.filtroAlarmas + ";";
    }
     if (this.modelo == 3 || this.modelo == 13)
    {
      this.nombreReporte = "Alarmas activas"
      this.reporteActual = "alarmas_activas"
      sentencia = "SELECT COUNT(id) AS cuenta FROM " + this.servicio.rBD() + ".alarmas WHERE ISNULL(fin);";
    }
    if (this.reporteSel== 4)
    {
      this.nombreReporte = "Lotes de (OAE)"
      this.reporteActual = "produccion_oae"
      sentencia = "SELECT COUNT(c.id) AS cuenta FROM " + this.servicio.rBD() + ".lecturas_cortes c LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON c.equipo = d.id WHERE c.id >= 0 " + this.filtroOEE + ";";
    }
    else if (this.reporteSel==5)
    {
      this.nombreReporte = "Todos los lotes (WIP)"
      this.reporteActual = "todos_los_lotes_wip"
      sentencia = "SELECT COUNT(*) AS cuenta FROM " + this.servicio.rBD() + ".lotes a WHERE a.id > 0 " + this.filtroWIP + ";";
    }
    else if (this.reporteSel==6)
    {
      this.nombreReporte = "Trazabilidad de lotes "
      this.reporteActual = "trazabilidad_lotes"
      sentencia = "SELECT COUNT(*) AS cuenta FROM " + this.servicio.rBD() + ".lotes_historia a WHERE a.id > 0 " + this.filtroTrazabilidad + ";";
    }
    else if (this.reporteSel==7)
    {
      this.nombreReporte = "Historico de calidad "
      this.reporteActual = "historico_de_calidad"
      sentencia = "SELECT COUNT(*) AS cuenta FROM " + this.servicio.rBD() + ".calidad_historia a WHERE a.id > 0 " + this.filtroCalidad + ";";
    }
   

    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length == 0)
      {
        this.miGrafica = [];
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "No hay datos para exportar";
        mensajeCompleto.tiempo = 1000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      else if (resp[0].cuenta == 0)
      {
        this.miGrafica = [];
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "No hay datos para exportar";
        mensajeCompleto.tiempo = 1000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      else
        {
          this.sentenciaR = "SELECT 'Numero', 'Orígen', 'Inicio de la falla', 'Fecha a reportar', 'Turno', 'Estatus', 'Fecha de llegada del tecnico', 'Tiempo esperado (segundos)', 'Fecha de resolucion de la falla', 'Tiempos de reparacion (segundos)', 'Tiempo total de la parada (segundos)', 'Inicio del reporte de mantenimiento', 'Fin del reporte de mantenimiento', 'Tiempo del reporte de mantenimiento (segundos)', 'Linea', 'ID de la linea', 'Maquina', 'ID de la maquina', 'Area que atendio', 'ID del area', 'Falla confirmada', 'ID de la falla confirmada', 'Usuario solicitante', 'Departamento del usuario', 'Tecnico que atendio el reporte', 'Tecnico que cerro el reporte', 'Usuario que confirmo la reparacion', 'Tipo de mantenimiento', 'Detalle de la falla (reporte tecnico)', 'Genero interrupcion?', 'Usuario que cambio interrupcion', 'Fecha de cambio interrupcion', 'Alarmado por reporte no cerrado a tiempo', 'Alarmado por tiempo de espera por tecnico excedido', 'Alarmado por tiempo de reparacion excedido', 'Falla reportada por el usuario', 'ID de la falla reportada'" + (this.servicio.rVersion().modulos[2] == 1 ?
          ", 'Numero de parte asociado', 'Referencia del numero de parte', 'Primer por que', 'Segundo por que', 'Tercer por que', 'Cuarto por que', 'Quinto por que', 'Plan', 'Fecha', 'Responsable', 'Departamento', '5M-Mano de obra', '5M-Materiales', '5M-Metodo', '5M-Maquina', '5M-Medio ambiente', 'Comentarios', 'Usuario que registro', 'Usuario que modifico', 'Fecha de creación', 'Fecha de modificacion' " : "") + " UNION SELECT c.id, IF(c.origen = 0, 'ANDON Digital', 'MMCall'), c.fecha, c.fecha_reporte, IFNULL(l.nombre, 'N/A'), c.estatus, c.inicio_atencion, c.tiempollegada, c.cierre_atencion, c.tiemporeparacion, c.tiemporeparacion + c.tiempollegada, c.inicio_reporte, c.cierre_reporte, c.tiemporeporte, IFNULL(a.nombre, 'N/A'), c.linea, IFNULL(b.nombre, 'N/A'), c.maquina, IFNULL(d.nombre, 'N/A'), c.area, IFNULL(e.nombre, 'N/A'), c.falla_ajustada, IFNULL(f.nombre, 'N/A'), IFNULL(j.nombre, 'N/A'), IFNULL(h.nombre, 'N/A'), IFNULL(g.nombre, 'N/A'), IFNULL(m.nombre, 'N/A'), IFNULL(k.nombre, 'N/A'), c.detalle, IF(c.contabilizar = 'S', 'Si', 'No'), IFNULL(v.nombre, 'N/A'), c.contabilizar_fecha, IF(c.alarmado = 'S', 'Si', 'No'), IF(c.alarmado_atender = 'S', 'Si', 'No'), IF(c.alarmado_atendido = 'S', 'Si', 'No'), IFNULL(i.nombre , 'N/A'), c.falla " + (this.servicio.rVersion().modulos[2] == 1 ? ", w.nombre, w.referencia, z.p1, z.p2, z.p3, z.p4, z.p5, z.plan, z.fecha, z.responsable, z.departamento, z.mano_de_obra, z.material, z.metodo, z.maquina, z.medio_ambiente, z.comentarios, y.nombre, x.nombre, z.creacion, z.modificacion " : "") + " FROM " + this.servicio.rBD() + ".reportes c LEFT JOIN " + this.servicio.rBD() + ".cat_lineas a ON c.linea = a.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas b ON c.maquina = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas d ON c.area = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_fallas e ON c.falla_ajustada = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios f ON c.solicitante = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios g ON c.tecnico = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios h ON c.tecnicoatend = h.id LEFT JOIN " + this.servicio.rBD() + ".cat_fallas i ON c.falla = i.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales j ON f.departamento = j.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales k ON c.tipo = k.id LEFT JOIN " + this.servicio.rBD() + ".cat_turnos l ON c.turno = l.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios m ON c.confirmado = m.id LEFT JOIN " + this.servicio.rBD() + ".causa_raiz z ON c.id = z.reporte LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios y ON z.creado = y.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios x ON z.modificado = x.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes w ON c.herramental = w.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios v ON c.contabilizar_usuario = v.id WHERE c.estatus >= 0 " + this.filtroReportes + " ";
          if (this.reporteSel==2)
          {
            this.sentenciaR = "SELECT 'ID', 'Fecha', 'Aplicacion', 'Tipo', 'Nro de reporte', 'Mensaje' UNION SELECT id, fecha, CASE WHEN aplicacion = 20 THEN 'MMCALL' WHEN aplicacion = 30 THEN 'INTERFAZ TELEFONICA' WHEN aplicacion = 40 THEN 'ENVIO DE CORREOS' WHEN aplicacion = 50 THEN 'ENVIO DE SMS' WHEN aplicacion = 60 THEN 'LOG DE EVENTOS' WHEN aplicacion = 70 THEN 'GENERACION DE AUDIOS' WHEN aplicacion = 80 THEN 'REPORTES AUTOMATICOS' ELSE 'MONITOR DE EVENTOS' END, CASE WHEN tipo = 0 THEN 'INFORMACION' WHEN tipo = 2 THEN 'ADVERTENCIA' WHEN tipo = 9 THEN 'ERROR' ELSE 'OTRO' END, proceso, texto FROM " + this.servicio.rBD() + ".log WHERE id >= 0 AND " + this.filtroFechas + " ";
          }
          else if (this.reporteSel==3)
          {
            this.sentenciaR = "SELECT 'No de reporte alarmado', 'Estatus del reporte', 'Nombre de la alerta', 'Fecha de activacion', 'Fecha de terminación', 'Tiempo transcurrido de la alerta (HH:MM:SS)', 'Usuario solicitante', 'Maquina afectada', 'Area encargada', 'Tecnico encargado', 'Nivel de escalamiento (1-5)', 'Total repeticiones' UNION (SELECT a.proceso, IF(c.estatus = 0, 'Sin atender', IF(c.estatus = 10, 'En reparacion', IF(c.estatus = 100, 'Por documentar', 'Cerrado'))), b.nombre, a.inicio, a.fin, IF(ISNULL(a.fin), TIMEDIFF(NOW(), a.inicio), SEC_TO_TIME(tiempo)), IFNULL(e.nombre, 'N/A') AS nsolicitante, IFNULL(g.nombre, 'N/A') AS nmaquina, IFNULL(d.nombre, 'N/A') AS narea, IFNULL(f.nombre, 'N/A') AS ntecnico, IF(a.fase - 10 < 0, 'N/A', a.fase - 10), a.repeticiones FROM " + this.servicio.rBD() + ".alarmas a INNER JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".reportes c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas d ON c.AREA = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas g ON c.maquina = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios e ON c.solicitante = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios f ON c.tecnico = f.id WHERE a.id >= 0 AND " + this.filtroAlarmas + ") ";
            
          }
          else if (this.reporteSel==4)
          {
            this.sentenciaR = "SELECT 'ID del bloque', 'Fecha de reporte', 'Orden de produccion/Lote', 'Turno', 'ID del turno', 'Linea', 'ID de la linea', 'Maquina', 'ID de la maquina', 'Número de parte', 'Referencia del número de parte', 'ID del número de parte', 'Tripulación', 'ID de la tripulación', 'TC teorico', 'Rate teorico (piezas/seg)', 'Piezas', 'Tiempo de produccion (seg)', 'Piezas rechazadas', 'Tiempo de produccion rechazadas (seg)', 'Piezas buffer', 'Tiempo total de paro (seg)', 'Tiempo total disponible (seg)', 'Desempeño del bloque (no topado)', 'Desempeño del bloque (topado)', 'Disponibilidad del bloque', 'Calidad del bloque', 'OAE del bloque (topado)', 'Rate real del bloque (piezas/seg)', 'TC real promedio del bloque (seg)', 'Fecha de inicio del bloque', 'Fecha de fin del bloque' UNION (SELECT c.id, c.dia, b.numero, a.nombre, c.turno, e.nombre, d.linea, d.nombre, c.equipo, f.nombre, f.referencia, c.parte, g.nombre, c.tripulacion, c.tc, IF(c.tc > 0, 1 / c.tc, 0), c.produccion, c.produccion_tc, c.calidad, c.calidad_tc, c.buffer, c.paro AS tparo, c.tiempo_disponible, IF(c.tiempo_disponible > 0, c.produccion_tc / (c.tiempo_disponible - (SELECT tparo)) * 100, 0) AS i1, IF((SELECT i1) > 100, 100, (SELECT i1)), IF(c.tiempo_disponible > 0, (1 - (SELECT tparo) / c.tiempo_disponible) * 100, 0) AS i2, IF(c.produccion_tc > 0, (1 - c.calidad_tc / c.produccion_tc) * 100, 0) AS i3, (IF((SELECT i1) > 100, 100, (SELECT i1)) * IF((SELECT i2) > 100, 100, (SELECT i2)) * IF((SELECT i3) > 100, 100, (SELECT i3)) / 10000), IF(c.tiempo_disponible > 0, c.produccion / c.tiempo_disponible, 0), IF(c.produccion  > 0, c.tiempo_disponible / c.produccion, 0), c.bloque_inicia, c.bloque_finaliza FROM " + this.servicio.rBD() + ".lecturas_cortes c LEFT JOIN " + this.servicio.rBD() + ".lotes b ON c.orden = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_turnos a ON c.turno = a.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON c.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes f ON c.parte = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_tripulacion g ON c.tripulacion = g.id WHERE c.id >= 0 " + this.filtroOEE + ") ";
            
          }
          else if (this.reporteSel==5)
          {
          this.sentenciaR = "SELECT 'id', 'Numero del lote', 'Fecha de entrada', 'Fecha de estimada de salida', 'Fecha real de salida', 'Tiempo total estimado (segundos)', 'Tiempo total ocupado (segundos)', 'Diferencia (estimado - real)', 'Estatus del registro', 'Referencia del nro de parte', 'Descripcion del nro de parte', 'Prioridad', 'Carga pre-asignada', 'Estado', 'Nombre del proceso actual', 'Nombre del equipo actual', 'Nombre de la operacion', 'Secuencia', 'Total inspecciones', 'Fecha de la últimma inspeccion', 'Causa de la últimma inspeccion', 'Usuario que efectuo la últimma inspeccion', 'Total rechazos', 'Fecha del últimmo rechazo', 'Causa del últimmo rechazo', 'Usuario que efectuó el ultimo rechazo', 'Total de alarmas', 'Tiempo de stock excedido', 'Tiempo de proceso excedido' UNION ALL SELECT a.id, a.numero, a.inicia, a.estimada, a.finaliza, a.tiempo, a.tiempo_estimado, (a.tiempo_estimado - a.tiempo), IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(d.referencia, 'N/A') AS referencia, IFNULL(d.nombre, 'N/A') AS producto, IFNULL((SELECT MIN(orden) FROM " + this.servicio.rBD() + ".prioridades WHERE parte = a.parte AND proceso = a.proceso AND fecha >= NOW() AND estatus = 'A'), 'N/A') AS prioridad, j.carga  , CASE WHEN a.estado = 0 THEN 'En Espera' WHEN a.estado = 20 THEN 'En Stock' WHEN a.estado = 50 THEN 'En Proceso' WHEN a.estado = 80 THEN 'En Inspeccion' WHEN a.estado = 90 THEN 'Rechazado' WHEN a.estado = 99 THEN 'Finalizado' END as estado, IFNULL(e.nombre, 'N/A') AS nproceso, IFNULL(b.nombre, 'N/A') AS nequipo, IFNULL(c.nombre, 'N/A') AS nruta_detalle, ruta_secuencia, a.inspecciones, a.inspeccion, IFNULL(f.nombre, 'N/A') AS insp_causa, IFNULL(h.nombre, 'N/A') AS insp_por, a.rechazos, a.rechazo, IFNULL(g.nombre, 'N/A') AS recha_causa, IFNULL(i.nombre, 'N/A') AS recha_por, a.alarmas, IF(a.alarma_tse = 'S', 'Si', 'No'), IF(a.alarma_tpe = 'S', 'Si', 'No') FROM " + this.servicio.rBD() + ".lotes a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas b ON a.equipo = b.id LEFT JOIN " + this.servicio.rBD() + ".det_rutas c ON a.ruta_detalle = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes d ON a.parte = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos e ON a.proceso = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_situaciones f ON a.inspeccion_id = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_situaciones g ON a.rechazo_id = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios h ON a.inspeccionado_por = h.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios i ON a.rechazado_por = i.id LEFT JOIN " + this.servicio.rBD() + ".cargas j ON a.carga = j.id WHERE a.id > 0 " + this.filtroWIP + " "; 
          }
          else if (this.reporteSel==6)
          {
            this.sentenciaR = "SELECT 'Numero del lote', 'Numero de parte', 'Referencia', 'Secuencia', 'Operacion', 'Equipo', 'Fecha de entrada', 'Fecha de stock', 'Fecha de proceso', 'Fecha estimada de termino', 'Fecha real de termino', 'Tiempo de espera', 'Tiempo de stock', 'Tiempo de proceso', 'Tiempo real de operacion', 'Tiempo estimado de operacion', 'Diferencia (estimado - real)', 'Secuencia anterior', 'Operacion anterior', 'Alerta por salto', 'Total reversos' UNION ALL SELECT b.numero, IFNULL(c.nombre, 'N/A'), IFNULL(c.referencia, 'N/A'), a.ruta_secuencia, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), a.fecha_entrada, a.fecha_stock, a.fecha_proceso, a.fecha_estimada, a.fecha_salida, a.tiempo_espera, a.tiempo_stock, a.tiempo_proceso, a.tiempo_total, a.tiempo_estimado, (a.tiempo_estimado - a.tiempo_total), a.ruta_secuencia_antes, IFNULL(f.nombre, 'N/A'), IF(a.alarma_so = 'N', 'NO', 'SI'), a.reversos FROM " + this.servicio.rBD() + ".lotes_historia a LEFT JOIN " + this.servicio.rBD() + ".lotes b ON a.lote = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes c ON b.parte = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos d ON a.proceso = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas e ON a.equipo = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos f ON a.proceso_anterior = f.id  WHERE a.id > 0 " + this.filtroTrazabilidad + " "; 
          }
          else if (this.reporteSel==7)
          {
          this.sentenciaR = "SELECT 'Lote', 'Descripcion (Numero de parte)', 'Referencia (número de parte)', 'Situacion', 'Tipo', 'Usuario', 'Operacion', 'Equipo', 'Secuencia de la ruta', 'Descripcion de la ruta', 'Inicio de la revision', 'Fin de la revision', 'Tiempo en revision' UNION ALL SELECT b.numero, IFNULL(d.nombre, 'N/A') AS producto, IFNULL(d.referencia, 'N/A') AS referencia, IFNULL(f.nombre, 'N/A') AS insp_causa, IF(a.tipo = 0, 'CALIDAD', 'SCRAP/RECHAZO/MERMA'), IFNULL(h.nombre, 'N/A') AS insp_por, IFNULL(e.nombre, 'N/A') AS nproceso, IFNULL(i.nombre, 'N/A'), a.secuencia, IFNULL(j.nombre, 'N/A'), a.inicia, a.finaliza, a.tiempo FROM " + this.servicio.rBD() + ".calidad_historia a LEFT JOIN " + this.servicio.rBD() + ".lotes b ON a.lote = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes d ON a.parte = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos e ON a.proceso = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_situaciones f ON a.inspeccion_id = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios h ON a.inspeccionado_por = h.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas i ON a.equipo = i.id LEFT JOIN " + this.servicio.rBD() + ".det_rutas j ON a.secuencia = j.id WHERE a.id > 0 " + this.filtroCalidad + " "; 
          }
          if (this.modelo == 3 || this.modelo == 13)
          {
            this.sentenciaR = "SELECT 'No de reporte alarmado', 'Estatus del reporte', 'Nombre de la alerta', 'Fecha de activacion', 'Tiempo transcurrido de la alerta (HH:MM:SS)', 'Usuario solicitante', 'Maquina afectada', 'Area encargada', 'Tecnico encargado', 'Nivel de escalamiento (1-5)', 'Total repeticiones' UNION (SELECT a.proceso, IF(c.estatus = 0, 'Sin atender', IF(c.estatus = 10, 'En reparacion', IF(c.estatus = 100, 'Por documentar', 'Cerrado'))), b.nombre, a.inicio, TIMEDIFF(NOW(), a.inicio), IFNULL(e.nombre, 'N/A') AS nsolicitante, IFNULL(g.nombre, 'N/A') AS nmaquina, IFNULL(d.nombre, 'N/A') AS narea, IFNULL(f.nombre, 'N/A') AS ntecnico, IF(a.fase - 10 < 0, 'N/A', a.fase - 10), a.repeticiones FROM " + this.servicio.rBD() + ".alarmas a INNER JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".reportes c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas d ON c.AREA = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas g ON c.maquina = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios e ON c.solicitante = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios f ON c.tecnico = f.id WHERE ISNULL(a.fin) ORDER BY 3);";
          }
          
          this.exportar()
        }
    })
  }

  
  selectionChange(event){
    console.log('selection changed using keyboard arrow');
  }

  
  exportar()
  {
    
    let campos = {accion: 100, sentencia: this.sentenciaR};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp. length > 0)
      {
        this.servicio.generarReporte(resp, this.nombreReporte, this.reporteActual + ".csv")
      }
    })
  }

  siguienteInactivar(id: number)
  {
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "500px", panelClass: 'dialogo_atencion', data: { titulo: "TERMINAR ALARMA", tiempo: 0, mensaje: "Esta acción terminará la alarma del reporte <strong>" + this.registros[id].proceso + "</strong> de manera permanente y de estar configurado, se enviarán mensajes de resolución a todos los involucrados en el reporte.<br><br><strong>¿Desea continuar con la operación?</strong>", id: 0, accion: 0, botones: 2, boton1STR: "Terminar la alarma", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_alarmas" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result)
      {
        if (result.accion == 1) 
        {
          let sentencia = "SELECT a.*, c.informar_resolucion, c.evento FROM " + this.servicio.rBD() + ".alarmas a INNER JOIN " + this.servicio.rBD() + ".cat_alertas c ON a.alerta = c.id WHERE a.id = " + this.registros[id].id;
          let campos = {accion: 100, sentencia: sentencia};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
            if (+resp[0].evento == 101) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".reportes SET alarmado_atender = 'Y' WHERE id = " + resp[0].proceso;
            }
            else if (+resp[0].evento == 102) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".reportes SET alarmado_atendido = 'Y' WHERE id = " + resp[0].proceso;
            }
            else if (+resp[0].evento == 103) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".reportes SET alarmado = 'Y' WHERE id = " + resp[0].proceso;
            } 
            else if (+resp[0].evento == 201) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_bajo = 'N' WHERE equipo = " + resp[0].proceso;
            }
            else if (+resp[0].evento == 202) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_alto = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 204) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_ftq = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 205) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_dis = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 206) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_efi = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 207) 
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_oee = 'N' WHERE equipo = " + resp[0].proceso;
            }   
            sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".alarmas SET estatus = 9, fin = NOW(), tiempo = TIME_TO_SEC(TIMEDIFF(NOW(), inicio))" + (resp[0].informar_resolucion == "S" ? ", informado = 'S'" : "") + ", termino = " + this.servicio.rUsuario().id + " WHERE id = " + this.registros[id].id + ";UPDATE " + this.servicio.rBD() + ".mensajes SET estatus = 'Z' where alarma = " + this.registros[id].id;
            if (resp[0].informar_resolucion == "S")
            {
              sentencia = sentencia + ";INSERT INTO " + this.servicio.rBD() + ".mensajes (alerta, canal, tipo, proceso, alarma, lista) SELECT a.alerta, b.canal, 7, a.proceso, a.id, b.lista FROM " + this.servicio.rBD() + ".alarmas a INNER JOIN " + this.servicio.rBD() + ".mensajes b ON a.id = b.alarma WHERE a.id = " + this.registros[id].id + " AND a.estatus = 9  GROUP BY a.alerta, b.canal, a.proceso, a.id, b.lista";
            }
            campos = {accion: 200, sentencia: sentencia};  
            this.servicio.consultasBD(campos).subscribe( resp =>
            {
              let mensajeCompleto: any = [];
              mensajeCompleto.clase = "snack-normal";
              mensajeCompleto.mensaje = "La alarma del reporte número: <strong>" + this.registros[id].proceso + "</strong> ha sido terminada";
              mensajeCompleto.tiempo = 2000;
              this.servicio.mensajeToast.emit(mensajeCompleto);
              this.registros.splice(id, 1);
              this.contarRegs(); 
              this.noLeer = false;   
            })
          });
        }
        else
        {
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-error";
          mensajeCompleto.mensaje = "Se cancela la terminación de la alarma";
          mensajeCompleto.tiempo = 2000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      }
      else
      {
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "Se cancela la terminación de la alarma";
        mensajeCompleto.tiempo = 2000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      }
    })
  }

  inactivar(id: number)
  {

  let rolBuscar = "A";
  if (this.servicio.rUsuario().rol == rolBuscar)
  {
    this.siguienteInactivar(id);
  }
  else
  {
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".relacion_usuarios_opciones WHERE usuario = " + this.servicio.rUsuario().id + " AND opcion = 30";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0) 
      {
        this.siguienteInactivar(id);
      }
      else
      {
        const respuesta = this.dialogo.open(SesionComponent, 
        {
          width: "400px", panelClass: 'dialogo', data: { tiempo: 10, sesion: 1, rolBuscar: rolBuscar, opcionSel: 30, idUsuario: 0, usuario: "", clave: "", titulo: "Se requiere perfil ADMINISTRADOR", mensaje: "", alto: "90", id: 0, accion: 0, botones: 2, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_sesion" }
        });
        respuesta.afterClosed().subscribe(result => 
        {

          if (result)
          {
            if (result.accion == 1) 
            {
              this.siguienteInactivar(id);
            }
            else
            {
              let mensajeCompleto: any = [];
              mensajeCompleto.clase = "snack-error";
              mensajeCompleto.mensaje = "Inicio de sesión cancelado";
              mensajeCompleto.tiempo = 2000;
              this.servicio.mensajeToast.emit(mensajeCompleto);
            }
          }
          else
          {
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "Inicio de sesión cancelado";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
          }

          })
        }
      })
    }
  }

  cancelarTodas()
  {
  
  this.yaConfirmado = false;
  let rolBuscar = "A";
  if (this.servicio.rUsuario().rol == rolBuscar)
  {
    this.siguienteCancelar();
  }
  else
  {
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".relacion_usuarios_opciones WHERE usuario = " + this.servicio.rUsuario().id + " AND opcion = 30";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0) 
      {
        this.siguienteCancelar();
      }
      else
      {
        const respuesta = this.dialogo.open(SesionComponent, 
        {
          width: "400px", panelClass: 'dialogo', data: { tiempo: 10, sesion: 1, rolBuscar: rolBuscar, opcionSel: 30, idUsuario: 0, usuario: "", clave: "", titulo: "Se requiere perfil ADMINISTRADOR", mensaje: "", alto: "90", id: 0, accion: 0, botones: 2, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_sesion" }
        });
        respuesta.afterClosed().subscribe(result => 
        {

          if (result)
          {
            if (result.accion == 1) 
            {
              this.yaConfirmado = true;
              this.siguienteCancelar();
            }
            else
            {
              let mensajeCompleto: any = [];
              mensajeCompleto.clase = "snack-error";
              mensajeCompleto.mensaje = "Inicio de sesión cancelado";
              mensajeCompleto.tiempo = 2000;
              this.servicio.mensajeToast.emit(mensajeCompleto);
            }
          }
          else
          {
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "Inicio de sesión cancelado";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
          }

          })
        }
      })
    }
  }


  //Desde aqui
  

filtrar()
{
  this.listarConsultas()
  this.filtrando = true;
  this.filtrarC = false;
  this.graficando = false;
  this.bot4Sel = false;
  this.bot7Sel = false;
  this.guardarSel = false;
  this.modelo = 12;
  this.buscarConsulta(this.servicio.rConsulta());
}

buscarConsulta(id: number)
{
  this.botElim = false;
  this.botGuar = false;
  this.botCan = false;
  this.consultaTemp = '' + id;
  this.listarLineas();
  this.listarMaquinas();
  this.listarAreas();
  this.listarFallas();
  this.listarTecnicos();
  this.listarPartes();
  this.listarTurnos();
  this.listarLotes();
  this.listarProcesos();
  let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".consultas_cab WHERE id = " + id;
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe( resp =>
  {
    if (resp.length > 0)
    {      
      if (!resp[0].filtroori)
      {
        resp[0].filtroori = "N";
      }
      
      if (!resp[0].nombre)
      {
        this.botElim = false;  
      }     
      else if (resp[0].nombre == "")
      {
        this.botElim = false;  
      }
      else if (resp[0].usuario != + this.servicio.rUsuario().id)
      {
        this.botElim = false;  
      }
      else
      {
        this.botElim = true;
      }
      this.detalle = resp[0]; 
      this.detalle.periodo = +this.detalle.periodo;
      if (this.detalle.periodo==8)
      {
        this.detalle.desde = new Date(this.detalle.desde);
        this.detalle.hasta = new Date(this.detalle.hasta);
      }
    }
    else
    {
      this.detalle.nombre = "";
      this.detalle.defecto = "N";
      this.detalle.id = "0";
      this.detalle.periodo = 1;
      this.detalle.publico = "N";
      this.detalle.desde = "";
      this.detalle.hasta = "";
      this.detalle.filtrolin = "S";
      this.detalle.filtroori = "S";
      this.detalle.filtromaq = "S";
      this.detalle.filtroare = "S";
      this.detalle.filtrofal = "S";
      this.detalle.filtrotec = "S";
      this.detalle.filtrotur = "S";
      this.detalle.filtronpar = "S";
      this.detalle.filtroord = "S";
      this.detalle.filtrooper = "S";
      
    }
    this.consultaBuscada = false;
    setTimeout(() => {
      this.txtNombre.nativeElement.focus();  
    }, 200);
  }, 
  error => 
    {
      console.log(error)
    })
}

buscarConsultaID()
{
  let sentencia = "SELECT id FROM " + this.servicio.rBD() + ".consultas_cab WHERE (usuario = " + this.servicio.rUsuario().id + ") AND nombre = '" + this.detalle.nombre + "'";
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe( resp =>
  {
    if (resp.length > 0)
    {
      this.detalle.id = resp[0].id  
    }
    else
    {
      this.detalle.id = 0; 
    }
    this.guardar(1)
  })
}


regresar()
{
  this.modelo = 11;
  this.graficando = true;
  this.filtrando = false;
}

listarConsultas()
  {
    let sentencia = "SELECT id, nombre, general, usuario FROM " + this.servicio.rBD() + ".consultas_cab WHERE (usuario = " + this.servicio.rUsuario().id + ") OR (general = 'S' AND NOT ISNULL(nombre)) ORDER BY nombre;";
    this.consultas = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      for (var i = 0; i < resp.length; i++) 
      {
        if (!resp[i].nombre)
        {
          resp[i].nombre = " [Consulta por defecto]";
        }
        else if (resp[i].nombre == "")
        {
          resp[i].nombre = " [Consulta por defecto]";
        }
      }
      this.consultas = resp;
    });
  }


  listarAlarmas()
  {
    let sentencia = "SELECT * FROM (SELECT a.*, b.evento, 0 AS indicador, c.estatus AS restatus, NOW() AS hasta, b.nombre, IFNULL(d.nombre, 'N/A') AS narea, IFNULL(e.nombre, 'N/A') AS nsolicitante, '' AS n1, '' AS n2 FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".reportes c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas d ON c.AREA = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios e ON c.solicitante = e.id WHERE ISNULL(fin) AND b.evento < 200 UNION ALL SELECT a.*, b.evento, IF(b.evento < 203, c.rate, c.oee) AS indicador, c.estatus AS restatus, NOW() AS hasta, b.nombre, IFNULL(d.nombre, 'N/A') AS narea, IFNULL(e.nombre, 'N/A') AS nsolicitante, '' AS n1, '' AS n2 FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".relacion_maquinas_lecturas c ON a.proceso = c.equipo LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON c.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id WHERE ISNULL(fin) AND b.evento > 200 AND b.evento < 300 UNION ALL SELECT a.*, b.evento, 0 AS indicador, 0 AS restatus, c.hasta, IFNULL(e.nombre, 'N/A') AS producto, IFNULL(d.nombre, 'N/A') AS nproceso, IFNULL(f.nombre, 'N/A') AS nequipo, c.numero, e.referencia FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".lotes c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos d ON c.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes e ON c.parte = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas f ON c.equipo = f.id WHERE ISNULL(fin) AND b.evento > 301 AND b.evento < 304 UNION ALL SELECT a.*, b.evento, 0 AS indicador, 0 AS restatus, c.fecha, b.nombre, IFNULL(d.nombre, 'N/A') AS nproceso, IFNULL(f.nombre, 'N/A') AS nequipo, c.carga, '' FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".cargas c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos d ON c.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas f ON c.equipo = f.id WHERE ISNULL(fin) AND b.evento = 304) AS qry01 ORDER BY inicio;"
    this.registros = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.registros = resp;
      this.arreTiempos.length = resp.length;
      this.revisarTiempo();
      this.contarRegs();
    });
  }

   cConsulta(event: any) 
  {
    this.eliminar = event.value != 0;
    this.buscarConsulta(event.value);
  }

  eliminarConsulta()
  {
    this.bot7Sel = false;
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "520px", panelClass: 'dialogo_atencion', data: { titulo: "ELIMINAR CONSULTA", mensaje: "Esta acción eliminará permanentemente la consulta actual y ya no podrá ser usada en el sistema<br><br><strong>¿Desea continuar con la operación?</strong>", id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Continuar y eliminar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_eliminar" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result.accion)
      {
        if (result.accion == 1) 
        {
          let sentencia = "DELETE FROM " + this.servicio.rBD() + ".consultas_cab WHERE id = " + this.detalle.id + ";DELETE FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.detalle.id + ";"
          let campos = {accion: 200, sentencia: sentencia};  
          this.servicio.consultasBD(campos).subscribe(resp =>
          {
            if (this.servicio.rConsulta() == this.detalle.id)
            {
              this.servicio.aConsulta(0);
            }
            this.botElim = false;
            this.detalle.id = 0;
            this.detalle.nombre = "";
            this.detalle.defecto = "N";
            this.detalle.id = "0";
            this.detalle.periodo = 1;
            this.detalle.publico = "N";
            this.detalle.desde = "";
            this.detalle.hasta = "";
            this.detalle.filtrolin = "S";
            this.detalle.filtroori = "S";
            this.detalle.filtromaq = "S";
            this.detalle.filtroare = "S";
            this.detalle.filtrofal = "S";
            this.detalle.filtrotec = "S";
            this.detalle.filtrotur = "S";
            this.detalle.filtronpar = "S";
            this.detalle.filtroord = "S";
            this.detalle.filtrooper = "S";
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "La consulta ha sido  eliminada";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
            setTimeout(() => {
              this.txtNombre.nativeElement.focus();  
            }, 200);
          });
        }
        else
        {
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-error";
          mensajeCompleto.mensaje = "Acción cancelada por el usuario";
          mensajeCompleto.tiempo = 2000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      }
      else
      {
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "Acción cancelada por el usuario";
        mensajeCompleto.tiempo = 2000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      }
    })
  }

  listarLineas()
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 10 AND b.consulta = " + this.consultaTemp + " ORDER BY seleccionado DESC, a.nombre;"
    this.lineas = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.lineas = resp;
        }, 300);
      
    });
  }

  listarProcesos()
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_procesos a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 90 AND b.consulta = " + this.consultaTemp + " ORDER BY seleccionado DESC, a.nombre;"
    this.procesos = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.procesos = resp;
        }, 300);
      
    });
  }


  listarMaquinas()
  {
    let sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 20 AND b.consulta = " + this.consultaTemp + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, nombre;"
    this.maquinas = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      setTimeout(() => {
        this.maquinas = resp;
      }, 300);
    });
  }

  listarAreas()
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 30 AND b.consulta = " + this.consultaTemp + " ORDER BY a.nombre;"
    this.areas = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.areas = resp;
        }, 300);
      
    });
  }

  listarFallas()
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_fallas a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 40 AND b.consulta = " + this.consultaTemp + " ORDER BY a.nombre;"
    this.fallas = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.fallas = resp;
        }, 300);
      
    });
  }

  listarTecnicos()
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_usuarios a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 50 AND b.consulta = " + this.consultaTemp + " WHERE (a.rol = 'T' OR a.rol = 'A') ORDER BY a.nombre;"
    this.tecnicos = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.tecnicos = resp;
        }, 300);
      
      
    });
  }

  listarPartes()
  {
    let sentencia = "SELECT a.id, IF(ISNULL(a.referencia), a.nombre, CONCAT(a.nombre, ' (Ref: ', a.referencia, ')')) AS nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_partes a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 60 AND b.consulta = " + this.consultaTemp + " WHERE a.tipo = 0 ORDER BY seleccionado DESC, nombre;"
    this.partes = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.partes = resp;
        }, 300);
      
      
    });
  }

  listarTurnos()
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_turnos a LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 70 AND b.consulta = " + this.consultaTemp + " ORDER BY seleccionado DESC, a.nombre;"
    this.turnos = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      setTimeout(() => {
        this.turnos = resp;
      }, 300);
      
    });
  }

  listarLotes()
  {
    let sentencia = "SELECT a.id, CONCAT(a.numero, ' / ', c.nombre) AS nombre, IF(ISNULL(b.valor), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".lotes a LEFT JOIN " + this.servicio.rBD() + ".cat_partes c ON a.parte = c.id LEFT JOIN " + this.servicio.rBD() + ".consultas_det b ON b.valor = a.id AND b.tabla = 80 AND b.consulta = " + this.consultaTemp + " WHERE a.estatus = 'A' AND fecha >= DATE_ADD(NOW(), INTERVAL - 2 MONTH) ORDER BY seleccionado DESC, nombre;"
    this.lotes = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        setTimeout(() => {
          this.lotes = resp;
        }, 300);
      
    });
  }


  cancelar()
  {
    this.bot4Sel = false;
    this.eliminar = this.detalle.id != 0;
    this.buscarConsulta(this.detalle.id);
  }

  seleccion(tipo: number, event: any) 
  {
    this.botGuar = true;
    this.botCan = true;
    if (tipo == 1)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.lineas.length; i++) 
        {
          this.lineas[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtrolin = "N";  
        }, 100);
      }
    }
    else if (tipo == 2)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.maquinas.length; i++) 
        {
          this.maquinas[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtromaq = "N";  
        }, 100);
      }
    }
    else if (tipo == 3)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.areas.length; i++) 
        {
          this.areas[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtroare = "N";  
        }, 100);
      }
    }
    else if (tipo == 4)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.fallas.length; i++) 
        {
          this.fallas[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtrofal = "N";  
        }, 100);
      }
    }
    else if (tipo == 5)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.tecnicos.length; i++) 
        {
          this.tecnicos[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtrotec = "N";  
        }, 100);
      }
    }

    else if (tipo == 7)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.partes.length; i++) 
        {
          this.partes[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtronpar = "N";  
        }, 100);
      }
    }
    else if (tipo == 6)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.turnos.length; i++) 
        {
          this.turnos[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtrotur = "N";   
        }, 100);
      }
    }
    else if (tipo == 8)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.lotes.length; i++) 
        {
          this.lotes[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtroord = "N";   
        }, 100);
      }
    }
    else if (tipo == 9)
    {
      if (event.value <= 1) 
      {
        for (var i = 0; i < this.procesos.length; i++) 
        {
          this.procesos[i].seleccionado = event.value;
        }
        setTimeout(() => {
          this.detalle.filtrooper = "N";   
        }, 100);
      }
    }
    
  }

  guardar(id: number)
  {
    this.guardarSel = false;
    let errores = 0;
    this.error01 = false;
    this.error02 = false;
    this.error03 = false;
    this.faltaMensaje = "<strong>No se ha guardado el registro por el siguiente mensaje:</strong> ";
      if (!this.detalle.nombre && id == 1)
    {
        errores = errores + 1;
        this.error01 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar el Nombre de la consulta";      
    }
    else if ((!this.detalle.nombre || this.detalle.nombre=="") && id == 1)
    {
        errores = errores + 1;
        this.error01 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar el Nombre de la consulta";      
    }
    if (this.detalle.periodo == "8")
    {
      if (!this.detalle.desde) 
      {
        errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha de inicio no está permitida";      
      }

      if (!this.detalle.hasta) 
      {
        errores = errores + 1;
          this.error03 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha de fin no está permitida";      
      }

      if (this.detalle.desde && this.detalle.hasta) 
      {
        if (this.detalle.desde > this.detalle.hasta)
        {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha inicial no puede ser mayor a la final";      
        }
      }
    
      
    }
    if (errores > 0)
    {
      setTimeout(() => {
        if (this.error01)
        {
          this.txtNombre.nativeElement.focus();
        }
        else if (this.error02)
        {
          this.txtDesde.nativeElement.focus();
        }
        else if (this.error03)
        {
          this.txtHasta.nativeElement.focus();
        }
      }, 300);
      return;
    }
    if (id== 1 && !this.consultaBuscada)
      {
        this.consultaBuscada = true;
        this.buscarConsultaID();
        return;
      }
      this.consultaBuscada = false;
    this.editando = false;
    this.faltaMensaje = "";
    if (id == 0 && !this.detalle.nombre)
    {
      this.detalle.publico = "N";
    }
    this.botGuar = false;
    this.botCan = false;
    
    let previa = "";
    if (!this.detalle.nombre)
    {
      previa = "DELETE FROM " + this.servicio.rBD() + ".consultas_cab WHERE (ISNULL(nombre) OR nombre = '') AND usuario = " + this.servicio.rUsuario().id + ";";
    }
    let previa2 = "";
    if (this.detalle.defecto == "S")
    {
      previa2 = "UPDATE " + this.servicio.rBD() + ".consultas_cab SET defecto = 'N', actualizacion = NOW() WHERE usuario = " + this.servicio.rUsuario().id + ";";
    }
    let nuevo = true
    let sentencia = previa + previa2 + "INSERT INTO " + this.servicio.rBD() + ".consultas_cab (usuario, " + (id == 1 ? "nombre, " : "") + "publico, periodo, defecto, filtrolin, filtroori, filtromaq, filtroare, filtrofal, filtrotec, filtronpar, filtrotur, filtroord, filtropar, filtrocla" + (this.detalle.periodo != 8 ? ")" : ", desde, hasta, actualizacion)") + " VALUES (" + this.servicio.rUsuario().id + ", '" + (id == 1 ? this.detalle.nombre + "', '" : "") + this.detalle.publico + "', '" + this.detalle.periodo + "', '" + this.detalle.defecto + "', '" + this.detalle.filtrolin + "', '" + this.detalle.filtroori + "', '" + this.detalle.filtromaq + "', '" + this.detalle.filtroare + "', '" + this.detalle.filtrofal + "', '" + this.detalle.filtrotec + "', '" + this.detalle.filtronpar + "', '" + this.detalle.filtrotur + "', '" + this.detalle.filtroord + "', '" + this.detalle.filtropar + "', '" + this.detalle.filtrocla + "'" + (this.detalle.periodo != 8 ? ");" : ", '" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "', '" +  this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "', NOW());")
    if (+this.detalle.id > 0)
    {
      nuevo = false;
      sentencia = previa2 + "UPDATE " + this.servicio.rBD() + ".consultas_cab SET " + (id == 1 ? "nombre = '" + this.detalle.nombre + "', " : "") + "actualizacion = NOW(), publico = '" + this.detalle.publico + "', periodo = '" + this.detalle.periodo + "', defecto = '" + this.detalle.defecto + "', filtrolin = '" + this.detalle.filtrolin + "', filtroori = '" + this.detalle.filtroori + "', filtromaq = '" + this.detalle.filtromaq + "', filtroare = '" + this.detalle.filtroare + "', filtrofal = '" + this.detalle.filtrofal + "', filtrotec = '" + this.detalle.filtrotec + "', filtronpar = '" + this.detalle.filtronpar + "', filtrotur = '" + this.detalle.filtrotur + "', filtroord = '" + this.detalle.filtroord + "', filtropar = '" + this.detalle.filtropar + "', filtrocla = '" + this.detalle.filtrocla + "'" + (this.detalle.periodo != 8 ? "" : ", desde = '" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "', hasta = '" +  this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "' ") + " WHERE id = " + +this.detalle.id + ";";
    }
    
    let campos = {accion: 200, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (nuevo)
      {
        sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".consultas_cab;";
        campos = {accion: 100, sentencia: sentencia};  
        this.servicio.consultasBD(campos).subscribe(resp =>
        {
          this.detalle.id = resp[0].nuevoid
          this.guardar_2(id);
          if (this.detalle.defecto == "S")
          {
            this.servicio.aConsulta(this.detalle.id);
          }
          setTimeout(() => {
            this.txtNombre.nativeElement.focus();  
          }, 200);
        })
      }
      else
      {
        this.guardar_2(id);
      }
    })
  }

  guardar_2(id: number)
  {
    let sentencia = "DELETE FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + +this.detalle.id + ";";
    let campos = {accion: 200, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      let cadTablas = "INSERT INTO " + this.servicio.rBD() + ".consultas_det (consulta, tabla, valor) VALUES";
      if (this.listaLineas)
      {
        for (var i = 0; i < this.listaLineas.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas +  "(" + this.detalle.id + ", 10,  " + +this.listaLineas.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaMaquinas)
      {
        for (var i = 0; i < this.listaMaquinas.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 20,  " + +this.listaMaquinas.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaAreas)
      {
        for (var i = 0; i < this.listaAreas.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 30,  " + +this.listaAreas.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaFallas)
      {
        for (var i = 0; i < this.listaFallas.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 40,  " + +this.listaFallas.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaTecnicos)
      {
        for (var i = 0; i < this.listaTecnicos.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 50,  " + +this.listaTecnicos.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaPartes)
      {
        for (var i = 0; i < this.listaPartes.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 60,  " + +this.listaPartes.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaTurnos)
      {
        for (var i = 0; i < this.listaTurnos.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 70,  " + +this.listaTurnos.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaLotes)
      {
        for (var i = 0; i < this.listaLotes.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 80,  " + +this.listaLotes.selectedOptions.selected[i].value + "),";
        }
      }
      if (this.listaProcesos)
      {
        for (var i = 0; i < this.listaProcesos.selectedOptions.selected.length; i++) 
        {
          cadTablas = cadTablas + "(" + this.detalle.id + ", 90,  " + +this.listaProcesos.selectedOptions.selected[i].value + "),";
        }
      }
      if (cadTablas != "INSERT INTO " + this.servicio.rBD() + ".consultas_det (consulta, tabla, valor) VALUES")
      {
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
          if (id == 0)
          {
            this.modelo = 11;
            this.servicio.aConsulta(this.detalle.id);
            this.graficando = true;
            this.filtrando = false;
            this.aplicarConsulta(this.servicio.rConsulta());
            
          }
        });
      }
      else
      {
        if (id == 0)
          {
            this.modelo = 11;
            this.servicio.aConsulta(this.detalle.id);
            this.graficando = true;
            this.filtrando = false;
            this.aplicarConsulta(this.servicio.rConsulta());
            
          }
      }
      
    })
    this.servicio.mensajeInferior.emit("Graficas de la aplicación");
    let mensajeCompleto: any = [];
    mensajeCompleto.clase = "snack-normal";
    mensajeCompleto.mensaje = "La consulta se ha guardado satisfactoriamente";
    mensajeCompleto.tiempo = 2000;
    this.servicio.mensajeToast.emit(mensajeCompleto);
  }

  cambiando(evento: any)
  {
    this.botGuar = true;
    this.botCan = true;
    if (evento.value == 8)
    {
      if (!this.detalle.desde)
      {
        this.detalle.desde = new Date();
      }
      if (!this.detalle.hasta)
      {
        this.detalle.hasta = new Date();
      }
    }
  }

  aplicarConsulta(id: number)
  {
    this.filtroAlarmas = "";
    this.ayuda01 = ""
    this.filtroParos = "";
    this.filtroFechas = "";
    this.filtroReportes = "";
    this.filtroOEE = "";
    this.filtroWIP = "";
    this.filtroTrazabilidad = "";
    this.filtroCalidad = "";
    
    
    this.filtroFechasDia = "";
    
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".consultas_cab WHERE id = " + id
    if (id == 0)
    {
      sentencia = "SELECT * FROM " + this.servicio.rBD() + ".consultas_cab WHERE usuario = " + this.servicio.rUsuario().id + " AND (defecto = 'S' OR ISNULL(nombre) OR nombre = '') ORDER BY actualizacion DESC LIMIT 1"
    }
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      
      let desde = new Date();
      let hasta = new Date();
      this.hayFiltro = false;
      if (resp.length > 0)
      { 
        this.ayuda01 = "Consulta aplicada: " + (resp[0].nombre ? resp[0].nombre : "Ultima consulta");
        this.servicio.aConsulta(resp[0].id)
        this.hayFiltro = true;
        if (resp[0].periodo == "2")
        {
          if (desde.getDay()==0) 
          {
            //domingo
            desde.setDate(desde.getDate() - 6);
          }
          else 
          {
            desde.setDate(desde.getDate() - (desde.getDay() - 1));
          }
        }
        else if (resp[0].periodo == "3")
        {
          let nuevaFecha = this.servicio.fecha(1, '' , "yyyy/MM") + "/01";         
          desde = new Date(nuevaFecha);
        }
        else if (resp[0].periodo == "4")
        {
          let nuevaFecha = this.servicio.fecha(1, '' , "yyyy") + "/01/01";         
          desde = new Date(nuevaFecha);
        }
        else if (resp[0].periodo == "5")
        {
          desde = new Date();
          if (desde.getDay() == 0) 
          {
            desde.setDate(desde.getDate() - 13);
            hasta.setDate(hasta.getDate() - 7);
          }
          else 
          {
            hasta.setDate(hasta.getDate() - (hasta.getDay()));
            desde.setDate(desde.getDate() - (desde.getDay() - 1) - 7);
          }
        }
        else if (resp[0].periodo == "6")
        {
          let mesTemp = new Date(this.datepipe.transform(new Date(desde), "yyyy/MM") + "/01");
          mesTemp.setDate(mesTemp.getDate() - 1);
          desde = new Date(this.datepipe.transform(new Date(mesTemp), "yyyy/MM") + "/01");
          hasta = new Date(this.datepipe.transform(new Date(mesTemp), "yyyy/MM/dd"));
        }
        else if (resp[0].periodo == "7")
        {
          let mesTemp = new Date(this.datepipe.transform(new Date(desde), "yyyy") + "/01/01");
          mesTemp.setDate(mesTemp.getDate() - 1);
          desde = new Date(this.datepipe.transform(new Date(mesTemp), "yyyy") + "/01/01");
          hasta = new Date(this.datepipe.transform(new Date(mesTemp), "yyyy") + "/12/31");
        }
        else if (resp[0].periodo == "9")
        {
          desde.setDate(desde.getDate() - 1);
          hasta.setDate(hasta.getDate() - 1);
        }
        if (resp[0].periodo == "8")
        {
          desde = new Date(this.datepipe.transform(new Date(resp[0].desde), "yyyy/MM/dd"));
          hasta = new Date(this.datepipe.transform(new Date(resp[0].hasta), "yyyy/MM/dd"));            
        }
        this.filtroAlarmas = " a.inicio >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + " 00:00:00' AND a.inicio <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + " 23:59:59' ";
        this.filtroParos = " AND f.fecha >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND f.fecha <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroFechas = " fecha >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + " 00:00:00' AND fecha <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + " 23:59:59' ";
        this.filtroReportes = " AND c.fecha_reporte >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND c.fecha_reporte <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroOEE = " AND c.dia >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND c.dia <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroFechasDia = " a.fecha >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND a.fecha <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroWIP = " AND a.inicia >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND a.inicia <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroTrazabilidad = " AND a.fecha_entrada >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND a.fecha_entrada <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroCalidad = " AND a.inicia >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND a.inicia <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";

        if (resp[0].filtroori == "0")
        {
          this.filtroReportes = this.filtroReportes + " AND c.origen = 0 "
        }
        else if (resp[0].filtroori == "1")
        {
          this.filtroReportes = this.filtroReportes + " AND c.origen > 0 "
        }
        if (resp[0].filtrolin == "N")
        {
          this.filtroReportes = this.filtroReportes + " AND c.linea IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 10) "
          this.filtroOEE = this.filtroOEE + " AND d.linea IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 10) "
        }
        if (resp[0].filtromaq == "N")
        {
          this.filtroReportes = this.filtroReportes + " AND c.maquina IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 20) "
          this.filtroOEE = this.filtroOEE + " AND c.equipo IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 20) "
          this.filtroWIP = this.filtroWIP + " AND a.equipo IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 20) "
          this.filtroTrazabilidad = this.filtroTrazabilidad + " AND a.equipo IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 20) "
          this.filtroCalidad = this.filtroCalidad + " AND a.equipo IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 20) "
        }
        if (resp[0].filtroare == "N")
        {
          this.filtroReportes = this.filtroReportes + " AND c.area IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 30) "
        }
        if (resp[0].filtrofal == "N")
        {
          this.filtroReportes = this.filtroReportes + " AND c.falla IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 40) "
        }
        if (resp[0].filtrotec == "N")
        {
          this.filtroReportes = this.filtroReportes + " AND c.tecnico IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 50) "
        }     
        if (resp[0].filtronpar == "N")
        {
          this.filtroOEE = this.filtroOEE + " AND c.parte IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 60) "
          this.filtroWIP = this.filtroWIP + " AND a.parte IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 60) "
          this.filtroTrazabilidad = this.filtroTrazabilidad + " AND a.parte IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 60) "
          this.filtroCalidad = this.filtroCalidad + " AND a.parte IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 60) "
        } 
        if (resp[0].filtrotur == "N")
        {
          this.filtroReportes = this.filtroReportes + " AND c.turno IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 70) "
          this.filtroOEE = this.filtroOEE + " AND c.turno IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 70) "
        }
        if (resp[0].filtroord == "N")
        {
          this.filtroOEE = this.filtroOEE + " AND c.orden IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 80) "
          this.filtroWIP = this.filtroWIP + " AND a.id IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 80) "
          this.filtroTrazabilidad = this.filtroTrazabilidad + " AND a.lote IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 80) "
          this.filtroCalidad = this.filtroCalidad + " AND a.lote IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 80) "
        }
        if (resp[0].filtrooper == "N")
        {
          this.filtroWIP = this.filtroWIP + " AND a.proceso IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 90) "
          this.filtroTrazabilidad = this.filtroTrazabilidad + " AND a.proceso IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 90) "
          this.filtroCalidad = this.filtroCalidad + " AND a.proceso IN (SELECT valor FROM " + this.servicio.rBD() + ".consultas_det WHERE consulta = " + this.servicio.rConsulta() + " AND tabla = 90) "
        }
               
      } 
      else
      {
        this.ayuda01 = "Consulta aplicada: Lo que va del mes";
        let nuevaFecha = this.servicio.fecha(1, '' , "yyyy/MM") + "/01";         
        desde = new Date(nuevaFecha);
        this.filtroAlarmas = " a.inicio >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND a.inicio <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroParos = " AND f.fecha >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND f.fecha <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroFechas = " fecha >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND fecha <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroReportes = " AND c.fecha_reporte >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND c.fecha_reporte <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroOEE = " AND c.dia >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND c.dia <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
        this.filtroFechasDia = " a.fecha >= '" + this.datepipe.transform(desde, "yyyy/MM/dd") + "' AND a.fecha <= '" + this.datepipe.transform(hasta, "yyyy/MM/dd") + "' ";
      }
    })
  }   
  
  revisarTiempo()
  {
    if (this.modelo == 13 || this.modelo == 3)
    {
      this.contarTiempo = false;
      for (var i = 0; i < this.registros.length; i++)
      {
        let segundos =  this.servicio.tiempoTranscurrido(this.registros[i].inicio, "").split(";");
        this.arreTiempos[i] = segundos[1] + ":" + (+segundos[2] < 10 ? "0" + segundos[2] : segundos[2]) + ":" + (+segundos[3] < 10 ? "0" + segundos[3] : segundos[3]);
      }
      this.contarTiempo = true;
    }
  }

  iniLeerBD()
  {
    if (!this.servicio.rConfig().visor_revisar_cada)
    {
      this.elTiempo = 5000;
    }
    else
    {
      this.elTiempo = +this.servicio.rConfig().visor_revisar_cada * 1000;
    }
    setTimeout(() => {
      this.leerBD();
    }, +this.elTiempo);
  }

  leerBD()
  {
    if ((this.modelo != 13 && this.modelo != 3) || this.router.url.substr(0, 9) != "/exportar")
    {
      return;
    }
    let sentencia = "";
    
    sentencia = "SELECT * FROM (SELECT a.*, b.evento, 0 AS indicador, c.estatus AS restatus, NOW() AS hasta, b.nombre, IFNULL(d.nombre, 'N/A') AS narea, IFNULL(e.nombre, 'N/A') AS nsolicitante, '' AS n1, '' AS n2 FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".reportes c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas d ON c.AREA = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios e ON c.solicitante = e.id WHERE ISNULL(fin) AND b.evento < 200 UNION ALL SELECT a.*, b.evento, IF(b.evento < 203, c.rate, c.oee) AS indicador, c.estatus AS restatus, NOW() AS hasta, b.nombre, IFNULL(d.nombre, 'N/A') AS narea, IFNULL(e.nombre, 'N/A') AS nsolicitante, '' AS n1, '' AS n2 FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".relacion_maquinas_lecturas c ON a.proceso = c.equipo LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON c.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id WHERE ISNULL(fin) AND b.evento > 200 AND b.evento < 300 UNION ALL SELECT a.*, b.evento, 0 AS indicador, 0 AS restatus, c.hasta, IFNULL(e.nombre, 'N/A') AS producto, IFNULL(d.nombre, 'N/A') AS nproceso, IFNULL(f.nombre, 'N/A') AS nequipo, c.numero, e.referencia FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".lotes c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos d ON c.proceso = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes e ON c.parte = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas f ON c.equipo = f.id WHERE ISNULL(fin) AND b.evento > 301 AND b.evento < 304 UNION ALL SELECT a.*, b.evento, 0 AS indicador, 0 AS restatus, c.fecha, b.nombre, IFNULL(d.nombre, 'N/A') AS nproceso, IFNULL(f.nombre, 'N/A') AS nequipo, c.carga, '' FROM " + this.servicio.rBD() + ".alarmas a LEFT JOIN " + this.servicio.rBD() + ".cat_alertas b ON a.alerta = b.id LEFT JOIN " + this.servicio.rBD() + ".cargas c ON a.proceso = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos d ON c.proceso = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas f ON c.equipo = f.id WHERE ISNULL(fin) AND b.evento = 304) AS qry01 ORDER BY inicio;";
    
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      let actualizar = JSON.stringify(this.registros) != JSON.stringify(resp);
      if (actualizar)
      {
        if (resp.length == 0)
        {
          this.registros = [];
        }
        if (this.registros.length == 0 && resp.length > 0)
        {
          this.registros = resp;
        }
        else 
        {
          for (i = this.registros.length - 1; i >= 0; i--)
          {
            let hallado = false;
            for (var j = 0; j < resp.length; j++)
            {

              if (this.registros[i].id ==  resp[j].id)
              {
                if (this.registros[i].indicador !=  resp[j].indicador || this.registros[i].restatus !=  resp[j].restatus || this.registros[i].hasta !=  resp[j].hasta || this.registros[i].fase != resp[j].fase)
                {
                  this.registros[i].indicador = resp[j].indicador;
                  this.registros[i].hasta = resp[j].hasta;
                  this.registros[i].restatus = resp[j].restatus;
                  this.registros[i].fase = resp[j].fase;
                }
                hallado = true;
                break;
              }
            }
            if (!hallado)
            {
              this.registros.splice(i, 1);
              this.arreTiempos.length = resp.length;
              this.arreHover.length = resp.length;
            }
          }
          for (var i = 0; i < resp.length; i++)
          {
            let agregar = true;
            for (var j = 0; j < this.registros.length; j++)
            {
              if (this.registros[j].id == resp[i].id)
              {
                agregar = false
                break;              
              }
            }
            if (agregar)
            {
              this.registros.splice(i, 0, resp[i])
              this.arreTiempos.length = resp.length;
              this.arreHover.length = resp.length;
            }
          }
          
        }
        this.contarRegs()
      }
      clearTimeout(this.leeBD);
      if (this.router.url.substr(0, 9) == "/exportar")
      {
        this.leeBD = setTimeout(() => {
          this.leerBD()
        }, +this.elTiempo);
      }
    });
  }

  contarRegs()
  {
    if (this.router.url.substr(0, 9) != "/exportar")
    {
      return;
    }
    if (this.modelo == 1)
    {
      this.servicio.mensajeInferior.emit("Exportar datos");   
      return;
    }
    let mensaje = "";
    if (this.registros.length > 0)
    {
      mensaje = "Hay " + (this.registros.length == 1 ? " una alarma activa" : this.registros.length + " alarmas activas") 
    }
    else
    {
      mensaje = "No hay alarmas activas";
    }
    let cadAlarmas: string = "";
    this.alarmados = 0;
    for (var i = 0; i < this.registros.length; i++)
    {
      if (this.registros[i].fase >10)
      {
        this.alarmados = this.alarmados + 1
      }
    }
    if (this.alarmados > 0)
    {
      cadAlarmas = "<span class='resaltar'>" + (this.alarmados == 1 ? "una escalada" : this.alarmados + " escaladas") + "</span>";
    }
    mensaje = mensaje + ' ' + cadAlarmas

    this.servicio.mensajeInferior.emit(mensaje);          
  }


  cancelarAlarmas()
  {
    let sentencia = "SELECT a.*, c.informar_resolucion, c.evento FROM " + this.servicio.rBD() + ".alarmas a INNER JOIN " + this.servicio.rBD() + ".cat_alertas c ON a.alerta = c.id WHERE ISNULL(a.fin)"
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        sentencia = "";
        for (var i = 0; i < resp.length; i++) 
        {
            sentencia =  sentencia + ";UPDATE " + this.servicio.rBD() + ".reportes SET alarmado_atender = 'Y' WHERE id = " + resp[i].proceso;
            if (+resp[i].evento == 102) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".reportes SET alarmado_atendido = 'Y' WHERE id = " + resp[i].proceso;
            }
            else if (+resp[i].evento == 103) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".reportes SET alarmado = 'Y' WHERE id = " + resp[i].proceso;
            } 
            else if (+resp[i].evento == 302) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".lotes SET alarma_tse_paso = 'N', alarma_tse = 'N', alarma_tse_p = 'N' WHERE id id = " + resp[i].proceso;
            }
            else if (+resp[i].evento == 303) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".lotes SET alarma_tpe_paso = 'N', alarma_tpe = 'N', alarma_tpe_p = 'N' WHERE id = " + resp[i].proceso;
            } 
            else if (+resp[i].evento == 201) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_bajo = 'N' WHERE equipo = " + resp[i].proceso;
            } 
            else if (+resp[i].evento == 202) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_alto = 'N' WHERE AND equipo = " + resp[i].proceso;
            } 
            else if (+resp[0].evento == 204) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_ftq = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 205) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_dis = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 206) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_efi = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            else if (+resp[0].evento == 207) 
            {
              sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET alarmado_oee = 'N' WHERE equipo = " + resp[0].proceso;
            }  
            sentencia = sentencia + ";UPDATE " + this.servicio.rBD() + ".alarmas SET estatus = 9, fin = NOW(), tiempo = TIME_TO_SEC(TIMEDIFF(NOW(), inicio))" + (resp[i].informar_resolucion == "S" ? ", informado = 'S'" : "") + ", termino = " + this.servicio.rUsuario().id + " WHERE id = " + resp[i].id + ";UPDATE " + this.servicio.rBD() + ".mensajes SET estatus = 'Z' where alarma = " + resp[i].id;
            if (resp[0].informar_resolucion == "S")
            {
              sentencia = sentencia + ";INSERT INTO " + this.servicio.rBD() + ".mensajes (alerta, canal, tipo, proceso, alarma, lista) SELECT a.alerta, b.canal, 7, a.proceso, a.id, b.lista FROM " + this.servicio.rBD() + ".alarmas a INNER JOIN " + this.servicio.rBD() + ".mensajes b ON a.id = b.alarma WHERE a.id = " + resp[i].id + " AND a.estatus = 9  GROUP BY a.alerta, b.canal, a.proceso, a.id, b.lista";
            }
          }
          sentencia = sentencia.substr(1);
          campos = {accion: 200, sentencia: sentencia};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "Se han terminado todas las alarmas";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
            this.leerBD();
            this.contarRegs(); 
            this.noLeer = false;   
          })
        }
      });
                    
  }
  siguienteCancelar()
  {

    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "520px", panelClass: 'dialogo_atencion', data: { titulo: "TERMINACIÓN MASIVA DE ALARMAS", mensaje: "Esta acción <strong>SUMAMENTE DELICADA</strong> terminará las alarmas activas de la aplicación.<br><br><strong>¿Desea continuar con la operación?</strong><br><br>", id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Terminar alarmas", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_alerta" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result)
      {
        
        if (result.accion == 1) 
        {
          if (this.yaConfirmado)
          {
            this.cancelarAlarmas();
          }
          else
          {

            const respuesta = this.dialogo.open(SesionComponent, 
            {
              width: "400px", panelClass: 'dialogo_atencion', data: { tiempo: 10, sesion: 1, rolBuscar: "A", opcionSel: 0, idUsuario: 0, usuario: "", clave: "", titulo: "Confirmación del ADMINISTRADOR", mensaje: "", alto: "90", id: 0, accion: 0, botones: 2, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_sesion" }
            });
            respuesta.afterClosed().subscribe(result => 
            {
              if (result)
              {
                if (result.accion == 1) 
                {
                  this.cancelarAlarmas();  
                }
                else
                {
                  let mensajeCompleto: any = [];
                  mensajeCompleto.clase = "snack-error";
                  mensajeCompleto.mensaje = "No se confirmó la terminacion de las alertas";
                  mensajeCompleto.tiempo = 2000;
                  this.servicio.mensajeToast.emit(mensajeCompleto);
                }
              }
              else
              {
                let mensajeCompleto: any = [];
                mensajeCompleto.clase = "snack-error";
                mensajeCompleto.mensaje = "No se confirmó la terminación de las alertas";
                mensajeCompleto.tiempo = 2000;
                this.servicio.mensajeToast.emit(mensajeCompleto);
              }
            })
            }
          }        
        else
        {
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-error";
          mensajeCompleto.mensaje = "No se confirmó la terminacion de las alertas";
          mensajeCompleto.tiempo = 2000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      }
      else
      {
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "No se confirmó la terminacion de las alertas";
        mensajeCompleto.tiempo = 2000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      }
    })

}

}

