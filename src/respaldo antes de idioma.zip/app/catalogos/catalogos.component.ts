import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ServicioService } from '../servicio/servicio.service';
import { ActivatedRoute, GuardsCheckStart } from '@angular/router';
import { trigger, style, animate, transition, query, group, state, stagger } from '@angular/animations';
import { ScrollDispatcher, CdkScrollable } from '@angular/cdk/scrolling';
import { Subscription } from 'rxjs';
import { HttpClient  } from '@angular/common/http';
import { ViewportRuler } from "@angular/cdk/overlay";
import { MatSelectionList } from '@angular/material/list';
import { MatDialog } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { DialogoComponent } from '../dialogo/dialogo.component';
import { FiltroparoComponent } from '../filtroparo/filtroparo.component';
import { FiltrorechazoComponent } from '../filtrorechazo/filtrorechazo.component';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-catalogos',
  templateUrl: './catalogos.component.html',
  styleUrls: ['./catalogos.component.css'],
  animations: [
    trigger('esquema', [
      transition(':enter', [
        style({ opacity: 0.3, transform: 'translateY(5px)' }),
        animate('0.15s', style({ opacity: 1, transform: 'translateY(0px)' })),
      ]),
      transition(':leave', [
        animate('0.15s', style({ opacity: 0, transform: 'translateY(5px)' }))
      ])
    ]),
    trigger('esquema_del', [
      transition(':enter', [
        style({ opacity: 0.3, transform: 'translateY(15px)' }),
        animate('0.5s', style({ opacity: 1, transform: 'translateY(0px)' })),
      ]),
      transition(':leave', [
        animate('0.5s', style({ opacity: 0, transform: 'translateY(15px)' }))
      ])
    ]),
    trigger('arriba', [
    transition(':enter', [
      style({ opacity: 0.3, transform: 'scale(0.3)' }),
      animate('0.1s', style({ opacity: 1, transform: 'scale(1)' })),
    ]),
    transition(':leave', [
      animate('0.1s', style({ opacity: 0.3, transform: 'scale(0.3)' }))
    ])
  ]),]
})

export class CatalogosComponent implements OnInit {

  @ViewChild("txtBuscar", { static: false }) txtBuscar: ElementRef;
  @ViewChild("txtNombre", { static: false }) txtNombre: ElementRef;
  @ViewChild("txtTelefonos", { static: false }) txtTelefonos: ElementRef;
  @ViewChild("lstC0", { static: false }) lstC0: MatSelect;
  @ViewChild("lstC1", { static: false }) lstC1: MatSelect;
  @ViewChild("lstC2", { static: false }) lstC2: MatSelect;
  @ViewChild("lstC3", { static: false }) lstC3: MatSelect;
  @ViewChild("lstC4", { static: false }) lstC4: MatSelect;
  @ViewChild("lstC5", { static: false }) lstC5: MatSelect;
  @ViewChild("lstC6", { static: false }) lstC6: MatSelect;
  @ViewChild("listaListad", { static: false }) listaListad: MatSelectionList;
  @ViewChild("listaComplejidad", { static: false }) listaComplejidad: MatSelectionList;
  
  @ViewChild("lista1", { static: false }) lista1: MatSelectionList;
  @ViewChild("lista2", { static: false }) lista2: MatSelectionList;
  @ViewChild("lista3", { static: false }) lista3: MatSelectionList;
  @ViewChild("lista4", { static: false }) lista4: MatSelectionList;
  @ViewChild("lista5", { static: false }) lista5: MatSelectionList;
  @ViewChild("lista6", { static: false }) lista6: MatSelectionList;
  @ViewChild("lista7", { static: false }) lista7: MatSelectionList;

  @ViewChild("lstC10", { static: false }) lstC10: MatSelect;
  @ViewChild("lstC11", { static: false }) lstC11: MatSelect;
  @ViewChild("lstC12", { static: false }) lstC12: MatSelect;
  @ViewChild("lstC13", { static: false }) lstC13: MatSelect;
  @ViewChild("lstC14", { static: false }) lstC14: MatSelect;
  @ViewChild("lstC15", { static: false }) lstC15: MatSelect;


  @ViewChild("txtT1", { static: false }) txtT1: ElementRef;
  @ViewChild("txtT2", { static: false }) txtT2: ElementRef;
  @ViewChild("txtT3", { static: false }) txtT3: ElementRef;
  @ViewChild("txtT4", { static: false }) txtT4: ElementRef;
  @ViewChild("txtT5", { static: false }) txtT5: ElementRef;
  @ViewChild("txtT6", { static: false }) txtT6: ElementRef;
  @ViewChild("txtT7", { static: false }) txtT7: ElementRef;
  @ViewChild("txtT8", { static: false }) txtT8: ElementRef;
  scrollingSubscription: Subscription;
  vistaCatalogo: Subscription;
  //URL_FOLDER = "http://localhost:8081/sigma/assets/datos/";  
  URL_FOLDER = "/sigma/assets/datos/";  

  constructor
  (
    public servicio: ServicioService,
    private route: ActivatedRoute,
    public scroll: ScrollDispatcher,
    private http: HttpClient,
    public dialogo: MatDialog, 
    private router: Router, 
    private viewportRuler: ViewportRuler,
    public datepipe: DatePipe,
    
  ) {

    this.servicio.cambioPantalla.subscribe((pantalla: any)=>
    {
      this.altoPantalla = this.servicio.rPantalla().alto - 92;
      this.anchoPantalla = this.servicio.rPantalla().ancho - 2;// - (pantalla ? 0 : this.servicio.rAnchoSN());// : 0);
    });
   
    this.servicio.teclaBuscar.subscribe((accion: boolean)=>
    {
      this.buscar();
    });
    this.servicio.teclaEscape.subscribe((accion: boolean)=>
    {
      this.cancelar();
    });
    this.servicio.esMovil.subscribe((accion: boolean)=>
    {
      this.movil = accion;
    });
    this.servicio.vista.subscribe((accion: number)=>
    {
      if (this.router.url.substr(0, 10) == "/catalogos")
      {
        if (accion >= 30 && accion <= 43 || accion >= 46 && accion <= 59)
        {
          this.miSeleccion = accion - 29;  
          this.bot9 = this.miSeleccion == 8;
          this.cambiarVista(0)
          this.rRegistros(this.miSeleccion);
          this.iniLeerBD()
          
        }
        this.servicio.mostrarBmenu.emit(0);
      }
    });
    this.servicio.cadaSegundo.subscribe((accion: boolean)=>
    {
      if (this.router.url.substr(0, 10) == "/catalogos")
      {
        this.cadaSegundo();
      }
    });

  
    this.scrollingSubscription = this.scroll
      .scrolled()
      .subscribe((data: CdkScrollable) => {
        this.miScroll(data);
    });
    this.rConfiguracion();
    this.miSeleccion = this.servicio.rVista() - 29;
    this.bot9 = this.miSeleccion == 8;
    this.cambiarVista(2)
    
    this.rRegistros(this.miSeleccion);
    this.iniLeerBD()
  }

  ngOnInit() {
    this.servicio.validarLicencia(1)
    this.servicio.mostrarBmenu.emit(0);
    this.llenarListas(10100, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 100 " );
    this.llenarListas(10110, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 110 " );
  }

  offSet: number;
  idRates: number = 0;
  nListado: number = 0;
  verIrArriba: boolean = false;
  verBuscar: boolean = true;
  verTabla: boolean = false;
  activarNumero: boolean = true;
  primeraVez: boolean = true;
  cambioVista: boolean = true;
  hayFiltro: boolean = false;
  movil: boolean = false;
  nCatalogo: string = "LÍNEAS DE PRODUCCIÓN"
  etiBuscar: string = "Buscar línea";
  verBarra: string = "";
  ultimoReporte: string = "";
  ultimoID: number = 0;
  copiandoDesde: number = 0;
  textoBuscar: string = "";
  sentenciaR: string = "";
  sentenciaR2: string = "";
  vezExportar:number = 0
  cadSQLActual: string = "";
  nuevoRegistro: string = ";";
  nExtraccion: string = "0";
  nLapso: string = "0";
  piezasAntes: number = 0;
  equipoAntes: number = -1;
  validarCU: boolean = false;
  validarUSER: boolean = false;
  loteLista: boolean = false;
  validarM: boolean = false;
  nHorario: string = "T";
  sentenciaRate: string = "";
  nFrecuencia: string = "T";
  verSR: boolean = false;
  vObjetivoCero: boolean = false;
  arreTiempos: any = [];
  arreHover1: any = [];

  wPeriodos: any = [];
  wFechas: any = [];
  wHorarios: any = [];
  wEstatus: any = [];
  wSINO: any = [];
  wSINO2: any = [];
  wUso: any = [];
  turnosLote: any = [];
  fechasLote: any = [];
  

  imagenesValidadas: number = 0;
  
  mostrarImagenRegistro: string = "N";
  mensajeImagen: string = "Campo opcional";
  cancelarEdicion: boolean = false;

  modelo: number = 0;
  ultimaActualizacion = new Date();
  altoPantalla: number = this.servicio.rPantalla().alto - 92;
  anchoPantalla: number = this.servicio.rPantalla().ancho - 10 + this.servicio.rAnchoSN();
  errorTitulo: string = "Ocurrió un error durante la conexión al servidor";
  errorMensaje: string = "";
  pantalla: number = 2;  
  miSeleccion: number = 1;
  seleccionado: number = 0;
  selListadoT: string = "S";
  opciones: string = "S";
  iconoGeneral: string = "";
  iconoVista: string = "";
  literalVista: string = "Ver detalle";
  tituloBuscar: string = "";
  alarmados: number = 0;
  elTiempo: number = 0;
  despuesBusqueda: number = 0;
  enCadaSegundo: boolean = false;
  contarTiempo: boolean = false;
  visualizarImagen: boolean = false;
  paroEnCurso: boolean = false;
  sondeo: number = 0;
  registros: any = [];
  tmpRegistros: any = [];
  arrFiltrado: any = [];
  detalle: any = [];
  disponibilidad: any = [];
  titulos: any = [];
  tablas: any = [];
  recipientes: any = [];
  ayudas: any = [];
  ayuda02: string = "Un orden más arriba";
  ayuda03: string = "Un orden más abajo";
  ayuda04: string  = "Editar el valor";
  cronometro: any;
  vista17: number = 0;
  litVista17: string = "Por equipo";
  icoVista17: string = "i_maquina";
  leeBD: any;
  laSeleccion: any = [];
  configuracion: any = [];
  fallas: any = [];
  idiomas: any = [];
  lineas: any = [];
  procesos: any = [];
  eventos: any = [];
  lotes: any = [];
  paros: any = [];
  maquinas: any = [];
  partes: any = [];
  areas: any = [];
  lineasSel: any = [];
  mapasSel: any = [];
  operacionesSel: any = [];
  cVariables: any = [];
  respondido: number = 0;
  partesSel: any = [];
  maquinasSel: any = [];
  areasSel: any = [];
  plantasSel: any = [];
  fallasSel: any = [];
  opcionesSel: any = [];
  tipos: any = [];
  turnos: any = [];
  listas: any = [];
  usuarios: any = [];
  listados: any = [];
  agrupadores1: any = [];
  agrupadores2: any = [];
  arreImagenes: any = [];
  arreHover: any = [];

  seleccionMensaje = ["M", "C"];
  seleccionescalar1 = ["C"];
  seleccionescalar2 = ["C"];
  seleccionescalar3 = ["C"];
  seleccionescalar4 = ["C"];
  seleccionescalar5 = ["C"];
  seleccionProcesos = [];

  notas: string = "";
  hoverp01: boolean = false;
  hoverp02: boolean = false;
  noLeer: boolean = false;
  operacioSel: boolean = false;
  maquinaSel: boolean = false;
  maquinaSel2: boolean = false;
  maquinaSel3: boolean = false;
  maquinaSel4: boolean = false;
  reparandoSel: boolean = false;
  texto_habilitado: boolean = false;
  abiertoSel: boolean = false;
  lineaSel: boolean = false;
  masivoSel: boolean = false;
  editando: boolean = false;
  faltaMensaje: string = "";
  responsableSel: boolean = false;
  fallaSel: boolean = false;
  rAlarmado: string = "N";
  horaReporte;
  mensajePadre: string = "";
  URL_BASE = "/sigma/api/upload.php"
  URL_IMAGENES = "/sigma/assets/imagenes/";
  mostrarDetalle: boolean = false;

  ayuda01 = "Seleccionar una imagen para subir"

  botonera1: number = 1;
  verParos: number = 1;
  verSubParos: number = 1;
  boton01: boolean = true;
  boton02: boolean = true;
  boton03: boolean = true;
  boton04: boolean = true;

  bot1: boolean = true;
  bot2: boolean = true;
  bot3: boolean = true;
  bot4: boolean = true;
  bot5: boolean = true;
  bot6: boolean = true;
  bot7: boolean = true;
  bot8: boolean = true;
  bot9: boolean = true;

  bot1Sel: boolean = false;
  bot2Sel: boolean = false;
  bot3Sel: boolean = false;
  bot4Sel: boolean = false;
  bot5Sel: boolean = false;
  bot6Sel: boolean = false;
  bot7Sel: boolean = false;
  bot8Sel: boolean = false;
  bot9Sel: boolean = false;

  iniciarSel: boolean = false;
  topeSel: boolean = false;

  boton11: boolean = true;
  boton12: boolean = true;
  boton13: boolean = false;
  yaValidado: number = -1;
  cantidadValidada: boolean = false;
  cantidadActual: number = 0;
  corteActual: number = 0;
  rateEquipo: number = 1;
  rateEquipoOriginal: number = 1;

  animando: boolean = true;
  listoMostrar: boolean = true;

  error01: boolean = false;
  error02: boolean = false;
  error03: boolean = false;
  error04: boolean = false;
  error05: boolean = false;
  error06: boolean = false;
  error07: boolean = false;
  error08: boolean = false;
  error09: boolean = false;
  error10: boolean = false;
  error20: boolean = false;
  error21: boolean = false;
  error22: boolean = false;
  error23: boolean = false;
  error24: boolean = false; 
  error25: boolean = false;
  error30: boolean = false;
  error31: boolean = false;
  error32: boolean = false;
  error33: boolean = false;
  error34: boolean = false;
  error35: boolean = false;
  error36: boolean = false;

  literalSingular: string = "";
  literalSingularArticulo: string = "";
  literalPlural: string = "";

  ayuda11: string = "Cambiar a vista"

  escapar()
  {
    if (this.verBuscar)
    {
      this.textoBuscar = "";
    }
    else
    {
      this.cancelar();
    }
  }

  buscar()
  {
    if (this.verBuscar)
    {
      setTimeout(() => {
        if (this.txtBuscar)
        {
          this.txtBuscar.nativeElement.focus();
        }
        
      }, 150);
    }
  }

  irArriba() 
  {
    this.verIrArriba = false;
    document.querySelector('[cdkScrollable]').scrollTop = 0;    
    
  }

  miScroll(data: CdkScrollable) 
  {
    const scrollTop = data.getElementRef().nativeElement.scrollTop || 0;
      if (scrollTop < 5) 
      {
        this.verIrArriba = false
      }
      else 
      {
        this.verIrArriba = true
        clearTimeout(this.cronometro);
        this.cronometro = setTimeout(() => {
          this.verIrArriba = false;
        }, 3000);
      }

    this.offSet = scrollTop;
  }

  salidaEfecto(evento: any)
  {
    if (evento.toState)
    {
      this.modelo = this.modelo - 10;
    }
  }

  mostrar(modo: number)
  {
    if (modo == 1 && this.registros.length == 0)
    {
      this.listoMostrar = true;
    }
    else if (this.registros.length > 0)
    {
      this.listoMostrar = false;
    }
    
  }

  rRegistros(tabla: number)
  {
    this.seleccionado = 0;
    //this.verBuscar = tabla <= 4 || tabla==11;
    //this.cambioVista = tabla <= 4 || tabla==1;
    this.animando = false;
    this.visualizarImagen = false;
    this.despuesBusqueda = 0;
    this.copiandoDesde = 0;
    this.botonera1 = 1;
    this.registros = [];
    this.arrFiltrado = [];
    this.arreHover = [];
    this.arreImagenes = [];
    this.servicio.activarSpinner.emit(true);     
    this.servicio.activarSpinnerSmall.emit(true);     
    this.noLeer = false;  
    let mensajeSI = false
    //
    let sentencia: string  = "";
    if (tabla == 1)
    {
      this.nCatalogo = "LÍNEAS/CELULAS"
      this.etiBuscar = "Buscar línea";
      this.iconoGeneral = "i_lineas";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Agrupador (1)', 'Agrupador (2)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id ";
      this.tituloBuscar = "Filtrar líneas";
      this.literalSingular = "una línea";
      this.literalPlural = "líneas";
      this.literalSingularArticulo = "La línea";
      this.mensajePadre = "";
    }
    else if (tabla == 2)
    {
      this.nCatalogo = "MÁQUINAS"
      this.etiBuscar = "Buscar máquina";
      this.iconoGeneral = "i_maquina";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, IFNULL(d.nombre, 'N/A') AS nlinea, a.imagen FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON a.linea = d.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Tipo de maquina', 'Agrupador (1)', 'Agrupador (2)', 'Linea asociada', 'ID de la linea asociada', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(g.nombre, 'N/A'), IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IFNULL(f.nombre, 'N/A'), a.linea, IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales g ON a.tipo = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas f ON a.linea = f.id  ";
      this.tituloBuscar = "Filtrar máquinas";
      this.literalSingular = "una máquina";
      this.literalPlural = "máquinas";
      this.literalSingularArticulo = "La máquina";
      this.mensajePadre = "";
    }
    else if (tabla == 3)
    {
      this.nCatalogo = "ÁREAS"
      this.etiBuscar = "Buscar área";
      this.iconoGeneral = "i_responsable";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Agrupador (1)', 'Agrupador (2)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id ";
      this.tituloBuscar = "Filtrar áreas";
      this.literalSingular = "una área";
      this.literalPlural = "áreas";
      this.literalSingularArticulo = "El área";
      this.mensajePadre = "";
    }
    else if (tabla == 28)
    {
      this.nCatalogo = "VARIABLES"
      this.etiBuscar = "Buscar variable";
      this.iconoGeneral = "i_variables";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(d.nombre, 'N/A') AS unidad, IFNULL(e.nombre, 'N/A') AS ntipo, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen, (SELECT COUNT(*) FROM " + this.servicio.rBD() + ".relacion_variables_equipos WHERE variable = a.id) AS tequipos, a.maquinas FROM " + this.servicio.rBD() + ".cat_variables a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.unidad = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.tipo = e.id ORDER BY a.nombre;";
        this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Agrupador (1)', 'Agrupador (2)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id ";
      this.tituloBuscar = "Filtrar variables";
      this.literalSingular = "una variable";
      this.literalPlural = "variables";
      this.literalSingularArticulo = "La variable";
      this.mensajePadre = "";
    }
    else if (tabla == 29)
    {
      this.nCatalogo = "CHECKLISTS"
      this.etiBuscar = "Buscar checklist";
      this.iconoGeneral = "i_checklist";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(CONCAT(d.nombre, ' / ', f.nombre), '(CUALQUIERA)') AS nequipo, IFNULL(e.nombre, 'N/A') AS ndpto, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen, (SELECT COUNT(*) FROM " + this.servicio.rBD() + ".det_checklist WHERE checklist = a.id) AS tvariables FROM " + this.servicio.rBD() + ".cat_checklists a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.departamento = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas f ON d.linea = f.id ORDER BY a.nombre;";
        this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Agrupador (1)', 'Agrupador (2)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id ";
      this.tituloBuscar = "Filtrar checklist";
      this.literalSingular = "un checklist";
      this.literalPlural = "checklists";
      this.literalSingularArticulo = "El checklist";
      this.mensajePadre = "";
    }
    else if (tabla == 30)
    {
      this.nCatalogo = "PLANES"
      this.etiBuscar = "Buscar planes";
      this.iconoGeneral = "i_plan";
      sentencia = "SELECT a.id, a.nombre, a.fecha, a.hora, a.frecuencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(d.nombre, 'N/A') AS nfrecuencia, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".plan_checklists a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".traduccion_when d ON a.frecuencia = d.id AND d.idioma = " + this.servicio.rUsuario().idioma + " AND (d.campo = 10 OR d.campo = 150) ORDER BY a.nombre;";
        this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Agrupador (1)', 'Agrupador (2)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id ";
      this.tituloBuscar = "Filtrar planes";
      this.literalSingular = "un plan";
      this.literalPlural = "planes";
      this.literalSingularArticulo = "El plan";
      this.mensajePadre = "";
    }
    else if (tabla == 4)
    {
      this.nCatalogo = "FALLAS"
      this.etiBuscar = "Buscar falla";
      this.iconoGeneral = "i_falla";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_fallas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Direccion (URL) de MMCall', 'Agrupador (1)', 'Agrupador (2)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_fallas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.agrupador_1 = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.agrupador_2 = e.id LEFT JOIN " + this.servicio.rBD() + ".relacion_fallas_operaciones i ON a.id = i.falla LEFT JOIN " + this.servicio.rBD() + ".cat_lineas f ON i.proceso = f.id AND i.tipo = 1 LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas g ON i.proceso = g.id AND i.tipo = 2  LEFT JOIN " + this.servicio.rBD() + ".cat_areas h ON i.proceso = h.id AND i.tipo = 3";

      this.sentenciaR2 = "SELECT * FROM (SELECT 'ID', 'Nombre/Descripcion', 'Todas las lineas', 'Todas las maquinas', 'Todas las areas', 'Linea asociada', 'ID Linea', 'Maquina asociada', 'ID Maquina', 'Area asociada', 'ID area' UNION SELECT a.id, a.nombre, IF(a.linea = 'S', 'Si', 'No'), IF(a.maquina = 'S', 'Si', 'No'), IF(a.AREA = 'S', 'Si', 'No'), IFNULL(f.nombre, 'N/A'), a.linea, IFNULL(g.nombre, 'N/A'), a.maquina, IFNULL(h.nombre, 'N/A'), a.AREA FROM " + this.servicio.rBD() + ".cat_fallas a LEFT JOIN " + this.servicio.rBD() + ".relacion_fallas_operaciones i ON a.id = i.falla LEFT JOIN " + this.servicio.rBD() + ".cat_lineas f ON i.proceso = f.id AND i.tipo = 1 LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas g ON i.proceso = g.id AND i.tipo = 2 LEFT JOIN " + this.servicio.rBD() + ".cat_areas h ON i.proceso = h.id AND i.tipo = 3 ORDER BY 1 DESC, 2, 3, 4, 5) AS qry ";

      this.tituloBuscar = "Filtrar fallas";
      this.literalSingular = "una falla";
      this.literalPlural = "fallas";
      this.literalSingularArticulo = "La falla";
      this.mensajePadre = "";
    }
    else if (tabla == 5)
    {
      this.nCatalogo = "GENERALES"
      this.etiBuscar = "Buscar registro";
      this.iconoGeneral = "i_general";
      sentencia = "SELECT a.id, a.nombre, d.nombre AS ntabla, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_generales a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".tablas d ON a.tabla = d.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Tabla asociada', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, d.nombre, IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_generales a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".tablas d ON a.tabla = d.id ";
      this.tituloBuscar = "Filtrar generales";
      this.literalSingular = "un registro general";
      this.literalPlural = "registros generales";
      this.literalSingularArticulo = "El registro general";
      this.mensajePadre = "";
    }
    else if (tabla == 6)
    {
      this.nCatalogo = "RECIPIENTES"
      this.etiBuscar = "Buscar recipiente";
      this.iconoGeneral = "i_recipiente";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_distribucion a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Telefonos', 'Correos', 'MMCall', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.telefonos, a.correos, a.mmcall, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_distribucion a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id  ";
      this.tituloBuscar = "Filtrar recipiente";
      this.literalSingular = "un recipiente";
      this.literalPlural = "recipientes";
      this.literalSingularArticulo = "El recipiente";
      this.mensajePadre = "";
    }
    else if (tabla == 7)
    {
      this.nCatalogo = "CORREOS/REPORTE"
      this.etiBuscar = "Buscar correo";
      this.iconoGeneral = "i_correos";
      sentencia = "SELECT a.id, a.nombre, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_correos a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_correos a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ";
      this.tituloBuscar = "Filtrar reporte";
      this.literalSingular = "un reporte";
      this.literalPlural = "reportes";
      this.literalSingularArticulo = "El reporte";
      this.mensajePadre = "";
    }
    else if (tabla == 8)
    {
      this.bot9 = true
      this.nCatalogo = "ALERTAS"
      this.iconoGeneral = "i_alertas";
      this.etiBuscar = "Buscar alerta";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_alertas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Evento', 'Tiempo de espera (segundos)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, IFNULL(d.nombre, 'N/A'), a.transcurrido, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_alertas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".int_eventos d ON a.evento = d.alerta ";
      this.tituloBuscar = "Filtrar alertas";
      this.literalSingular = "una alerta";
      this.literalPlural = "alertas";
      this.literalSingularArticulo = "El alerta";
      this.mensajePadre = "";
    }
    else if (tabla == 9)
    {
      this.nCatalogo = "TURNOS"
      this.iconoGeneral = "i_turnos";
      this.etiBuscar = "Buscar turnos";
      sentencia = "SELECT a.id, a.nombre, a.inicia, a.termina, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_turnos a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Desde', 'Hasta', 'Tiempo del turno', 'Tipo de turno', 'Turno entre dos días', 'Día de afectacion (reportes)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.inicia, a.termina, a.telefonos, a.correos, a.mmcall, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_distribucion a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id  ";
      this.tituloBuscar = "Filtrar turnos";
      this.literalSingular = "un turno";
      this.literalPlural = "turnos";
      this.literalSingularArticulo = "El turno";
      this.mensajePadre = "";
    }
    else if (tabla == 10)
    {
      this.nCatalogo = "FRASES"
      this.iconoGeneral = "i_traductor";
      this.etiBuscar = "Buscar FRASE";
      sentencia = "SELECT a.id, a.literal, a.traduccion FROM " + this.servicio.rBD() + ".traduccion a ORDER BY a.literal;";
      this.sentenciaR = "SELECT 'ID', 'Literal', 'Traduccion' UNION SELECT a.id, a.literal, a.traduccion FROM " + this.servicio.rBD() + ".traduccion ";
      this.tituloBuscar = "Filtrar frase";
      this.literalSingular = "una frase";
      this.literalPlural = "frases";
      this.literalSingularArticulo = "La frase";
      this.mensajePadre = "";
    }
    else if (tabla == 12)
    {
      this.nCatalogo = "USUARIOS"
      this.etiBuscar = "Buscar usuario";
      this.iconoGeneral = "i_grupos";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_usuarios a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre del usuario', 'Politica de seguridad', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Rol del usuario', 'Compania asociada', 'Departamento asociaodo', 'Planta', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, IFNULL(g.nombre, 'N/A'), a.referencia, a.notas, a.imagen, CASE WHEN a.rol ='*' THEN '(Todos los roles)' WHEN a.rol = 'A' THEN 'ADMINISTRADOR' WHEN a.rol = 'G' THEN 'Gestor de la aplicación' WHEN a.rol = 'S' THEN 'Supervisor' WHEN a.rol = 'T' THEN 'Tecnico' WHEN a.rol = 'O' THEN 'Operador' END, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IFNULL(f.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_usuarios a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.compania = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.departamento = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales f ON a.planta = f.id LEFT JOIN " + this.servicio.rBD() + ".politicas g ON a.politica = g.id    ";
      this.tituloBuscar = "Filtrar usuarios";
      this.literalSingular = "un usuario";
      this.literalPlural = "usuarios";
      this.literalSingularArticulo = "El usuario";
      this.mensajePadre = "";
    }
    else if (tabla == 14)
    {
      this.nCatalogo = "POLÍTICAS"
      this.etiBuscar = "Buscar política";
      this.iconoGeneral = "i_politicas";
      sentencia = "SELECT a.id, a.nombre, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".politicas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Un sólo uso', 'Contraseña requerida', 'La contraseña vence', 'Dias de vencimiento', 'Dias de aviso', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, IF(a.deunsolouso = 'S', 'Si', 'No'), IF(a.obligatoria = 'S', 'Si', 'No'), IF(a.vence = 'S', 'Si', 'No'), a.diasvencimiento, a.aviso, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".politicas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id  ";
      this.tituloBuscar = "Filtrar política";
      this.literalSingular = "una política";
      this.literalPlural = "políticas";
      this.literalSingularArticulo = "La política";
      this.mensajePadre = "";
    }
    else if (tabla == 17)
    {
      this.nCatalogo = "RATES"
      this.etiBuscar = "Buscar rate";
      this.nCatalogo = "RATES"
      this.etiBuscar = "Buscar rate";
      this.iconoGeneral = this.icoVista17=="i_maquina" ? "i_rates" : "i_maquina";
      if (this.vista17 == 0)
      {
        sentencia = "SELECT a.*, b.referencia, CASE WHEN a.tiempo = 0 THEN 'SEGUNDO' WHEN a.tiempo = 1 THEN 'MINUTO' WHEN a.tiempo = 2 THEN 'HORA' WHEN a.tiempo = 3 THEN 'DIA' END AS tiempo, IFNULL(b.nombre, '(CUALQUIERA)') AS nombre, IFNULL(CONCAT(c.nombre, ' / ', d.nombre), '(CUALQUIERA)') AS nequipo, d.nombre AS nlinea FROM " + this.servicio.rBD() + ".relacion_partes_equipos a LEFT JOIN " + this.servicio.rBD() + ".cat_partes b ON a.parte = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.equipo = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON c.linea = d.id ORDER BY b.nombre;";
      }
      else
      {
        sentencia = "SELECT piezas, unidad, IFNULL(CONCAT(b.nombre, ' / ', c.nombre), '(CUALQUIERA)') AS nequipo, COUNT(DISTINCT(parte)) AS partes, CASE WHEN tiempo = 0 THEN 'SEGUNDO' WHEN tiempo = 1 THEN 'MINUTO' WHEN tiempo = 2 THEN 'HORA' WHEN tiempo = 3 THEN 'DIA' END AS tiempo FROM " + this.servicio.rBD() + ".relacion_partes_equipos a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas b ON a.equipo = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON b.linea = c.id GROUP BY a.piezas, a.unidad, nequipo ORDER BY piezas;";
      }
      this.sentenciaR = "SELECT 'Número de parte', 'Referencia', 'ID de Número de parte', 'Equipo/Máquina', 'Línea asociada', 'ID de la máquina', 'ID de la línea', 'Rate (piezas)', 'Lapso de tiempo/rate', 'Unidad de medida', 'Margen rate bajo', 'Margen rate alto' UNION SELECT IFNULL(b.nombre, '(CUALQUIER)'), IFNULL(b.referencia, '(CUALQUIER)'), a.parte, IFNULL(c.nombre, '(CUALQUIERA)'), IFNULL(d.nombre, '(CUALQUIERA)'), a.equipo, c.linea, a.piezas, CASE WHEN a.tiempo = 0 THEN 'SEGUNDO' WHEN a.tiempo = 1 THEN 'MINUTO' WHEN a.tiempo = 2 THEN 'HORA' WHEN a.tiempo = 3 THEN 'DIA' END, a.unidad, a.bajo, a.alto FROM " + this.servicio.rBD() + ".relacion_partes_equipos a LEFT JOIN " + this.servicio.rBD() + ".cat_partes b ON a.parte = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.equipo = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON c.linea = d.id  ";
      this.tituloBuscar = "Filtrar rates";
      this.literalSingular = "un rate";
      this.literalPlural = "rates";
      this.literalSingularArticulo = "El rate";
      this.mensajePadre = "";
    }
    else if (tabla == 18)
    {
      this.nCatalogo = "OBJETIVOS"
      this.etiBuscar = "Buscar objetivo";
      this.iconoGeneral = "i_objetivos";
      sentencia = "SELECT a.*, b.referencia, IFNULL(b.nombre, '(CUALQUIERA)') AS nombre, IFNULL(CONCAT(c.nombre, ' / ', d.nombre), '(CUALQUIERA)') AS nequipo, d.nombre AS nlinea, e.numero, f.nombre AS nturno FROM " + this.servicio.rBD() + ".equipos_objetivo a LEFT JOIN " + this.servicio.rBD() + ".cat_partes b ON a.parte = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.equipo = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON c.linea = d.id LEFT JOIN " + this.servicio.rBD() + ".lotes e ON a.lote = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_turnos f ON a.turno = f.id ORDER BY b.nombre;";
      this.sentenciaR = "SELECT 'Número de parte', 'Referencia', 'ID de Número de parte', 'Equipo/Máquina', 'Línea asociada', 'Número de lote', 'Turno asociado', 'ID de la máquina', 'ID de la línea', 'ID del turno', 'Objetivo' UNION SELECT IFNULL(b.nombre, '(CUALQUIER)'), IFNULL(b.referencia, '(CUALQUIER)'), a.parte, IFNULL(c.nombre, '(CUALQUIERA)'), IFNULL(d.nombre, '(CUALQUIERA)'), IFNULL(e.numero, '(CUALQUIER)'), IFNULL(f.nombre, '(CUALQUIER)'), a.equipo, c.linea, a.turno, a.objetivo FROM " + this.servicio.rBD() + ".equipos_objetivo a LEFT JOIN " + this.servicio.rBD() + ".cat_partes b ON a.parte = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.equipo = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON c.linea = d.id LEFT JOIN " + this.servicio.rBD() + ".lotes e ON a.lote = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_turnos f ON a.turno = f.id ";
      this.tituloBuscar = "Filtrar objetivo";
      this.literalSingular = "un objetivo";
      this.literalPlural = "objetivos";
      this.literalSingularArticulo = "El objetivo";
      this.mensajePadre = "";
    }
    else if (tabla == 19)
    {
      this.nCatalogo = "ESTIMADOS"
      this.etiBuscar = "Buscar estimado";
      this.iconoGeneral = "i_estimados";
      sentencia = "SELECT a.*, IFNULL(c.nombre, '(CUALQUIERA)') AS nequipo, IFNULL(d.nombre, '(CUALQUIERA)') AS nlinea FROM " + this.servicio.rBD() + ".estimados a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.equipo = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON a.linea = d.id ORDER BY c.nombre;";
      this.sentenciaR = "SELECT 'Equipo/Máquina', 'Línea asociada', 'ID de la máquina', 'ID de la línea', 'OAE', 'Desempeño', 'FTQ', 'Disponibilidad' UNION SELECT IFNULL(c.nombre, '(CUALQUIERA)'), IFNULL(d.nombre, '(CUALQUIERA)'), a.equipo, c.linea, a.oee, a.efi, a.ftq, a.dis FROM " + this.servicio.rBD() + ".estimados a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.equipo = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON a.linea = d.id ";
      this.tituloBuscar = "Filtrar estimado";
      this.literalSingular = "un estimado";
      this.literalPlural = "estimados";
      this.literalSingularArticulo = "El estimado";
      this.mensajePadre = "";
    }
    else if (tabla == 20)
    {
      this.nCatalogo = "SENSORES"
      this.etiBuscar = "Buscar sensor";
      this.iconoGeneral = "i_sensor";
      sentencia = "SELECT a.*, CONCAT(f.nombre) AS ntipo, CONCAT(d.nombre, ' / ', e.nombre) AS nequipo, e.nombre AS nlinea, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".relacion_procesos_sensores a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".traduccion_when f ON a.tipo = f.id AND f.idioma = " + this.servicio.rUsuario().idioma + " AND f.campo = 140 ORDER BY nequipo, a.sensor;";
      this.sentenciaR = "SELECT 'ID del sensor', 'Equipo/Máquina', 'Línea asociada', 'ID de la máquina', 'ID de la línea', 'Tipo de sensor', 'Multiplicador', 'Base', 'Area por defecto (sensor de calidad)', 'Clasificacion por defecto (sensor de calidad)', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.sensor, d.nombre, e.nombre, a.equipo, d.linea, CONCAT(h.nombre) AS ntipo, a.multiplicador, a.base, IFNULL(f.nombre, 'N/A'), IFNULL(g.nombre, 'N/A'), IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".relacion_procesos_sensores a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas f ON a.area = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales g ON a.clasificacion = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".traduccion_when i ON a.tipo = i.id AND i.idioma = " + this.servicio.rUsuario().idioma + " AND i.campo = 140";
      this.tituloBuscar = "Filtrar sensores";
      this.literalSingular = "un sensor";
      this.literalPlural = "sensores";
      this.literalSingularArticulo = "El sensor";
      this.mensajePadre = "";
    }
    else if (tabla == 21)
    {
      if (this.servicio.rFParo().mes ==0)
      {
        this.servicio.aFParo({mes: this.servicio.fecha(1, "", "MM"), ano: this.servicio.fecha(1, "", "yyyy"), concepto: -1, clase: "-1", area: 0, cadena: "" });
        ;
      }
      mensajeSI = this.servicio.rFParo().concepto == -1;
      if (this.primeraVez)
      {
        this.primeraVez = false;
        this.filtrarParo();
        return;
      }
      this.nCatalogo = "PAROS"
      this.etiBuscar = "Buscar paro";
      this.iconoGeneral = "i_paro";
      
      let uDia = new Date(+this.servicio.rFParo().ano, this.servicio.rFParo().mes, 0).getDate();
     
      let cadWhere = "WHERE a.fecha >= '" + this.servicio.rFParo().ano + "/" + this.servicio.rFParo().mes + "/01' AND a.fecha <= '" + this.servicio.rFParo().ano + "/" + this.servicio.rFParo().mes + "/" + uDia + "' ";
      let cadWhere2 = "";
      if (this.servicio.rFParo().clase != -1)
      {
        cadWhere = cadWhere + " AND a.clase = " + this.servicio.rFParo().clase; 
      }
      if (this.servicio.rFParo().concepto == -1)
      {
        cadWhere = cadWhere + " AND a.tipo = 0 "; 
      }
      else if (this.servicio.rFParo().concepto != 0)
      {
        cadWhere = cadWhere + " AND a.tipo = " + this.servicio.rFParo().concepto;
      }
      if (this.servicio.rFParo().area == -1)
      {
        cadWhere = cadWhere + " AND a.area = 0 "; 
      }
      else if (this.servicio.rFParo().area != 0)
      {
        cadWhere = cadWhere + " AND a.area = " + this.servicio.rFParo().area;
      }
      if (this.servicio.rFParo().cadena)
      {
        cadWhere = cadWhere + " AND a.paro LIKE '%" + this.servicio.rFParo().cadena + "%' "; 
      }
      
      sentencia = "SELECT a.*, a.paro AS nombre, CASE WHEN a.estado = 'P' THEN 'En preparación' WHEN a.estado = 'L' THEN 'Listo' WHEN a.estado = 'C' THEN 'En curso' WHEN a.estado = 'F' THEN 'Finalizado' END AS estado, a.estado AS miEstado, a.desde, a.hasta, SEC_TO_TIME(tiempo) AS totalt, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(b.nombre, 'SIN ASIGNACION') AS narea, IF(ISNULL(e.nombre), c.nombre, CONCAT(c.nombre, ' / ',  e.nombre)) AS nequipo, IFNULL(d.nombre, '(SIN IDENTIFICAR)') AS ntipo FROM " + this.servicio.rBD() + ".detalleparos a LEFT JOIN " + this.servicio.rBD() + ".cat_areas b ON a.area = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.maquina = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON c.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales d ON a.tipo = d.id " + cadWhere + " ORDER BY a.desde DESC;";

      this.sentenciaR = "SELECT * FROM (SELECT 'ID del paro', 'Nombre/Descripción', 'Fecha para reporte', 'Turno', 'Maquina afectada', 'Linea afectada', 'Numero de parte asociado', 'Referencia', 'Lote asociado', 'Reporte ANDON asociado', 'Clase de paro', 'Concepto del paro', 'Area que atiende el paro', 'Estado actual del paro', 'Inicio planeado', 'Fin planeado', 'Inicio real', 'Fin real', 'Tiempo real (segundos)', 'Causa de la terminacion del paro', 'Usuario que inició el paro', 'Usuario que finalizo el paro', 'Notas previas del paro', 'Comentarios y resultados del paro' UNION (SELECT a.id, a.paro, a.fecha, IFNULL(b.nombre, 'N/A'), IFNULL(c.nombre, 'N/A'), IFNULL(d.nombre, 'N/A'), IFNULL(i.nombre, 'N/A'), IFNULL(i.referencia, 'N/A'), IFNULL(j.numero, 'N/A'), a.reporte, CASE WHEN a.clase = 0 THEN 'Planeado' WHEN a.clase = 1 THEN 'Ausencia de piezas' WHEN a.clase = 2 THEN 'Paro manual de operador' WHEN a.clase = 3 THEN 'ANDON' END, IFNULL(e.nombre, 'N/A'), IFNULL(f.nombre, 'N/A'), CASE WHEN a.estado = 'P' THEN 'En preparación' WHEN a.estado = 'L' THEN 'Listo' WHEN a.estado = 'C' THEN 'En curso' WHEN a.estado = 'F' THEN 'Finalizado' END, a.desde, a.hasta, a.inicia, a.finaliza, IF(a.tiempo = 0, TIME_TO_SEC(TIMEDIFF(NOW(), a.inicia)), a.tiempo), CASE WHEN a.finalizo_accion = 'P' THEN 'Pieza detectada' WHEN a.finalizo_accion = 'T' THEN 'Por tiempo' WHEN a.finalizo_accion = 'M' THEN 'Manualmente' WHEN a.finalizo_accion = 'R' THEN 'Desde ANDON' WHEN a.finalizo_accion = 'O' THEN 'Por otro paro' END, IFNULL(g.nombre, 'N/A'), IFNULL(h.nombre, 'N/A'), a.notas, a.resultados FROM " + this.servicio.rBD() + ".detalleparos a LEFT JOIN " + this.servicio.rBD() + ".cat_turnos b ON a.turno = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas c ON a.maquina = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas d ON c.linea = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales e ON a.tipo = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas f ON a.area = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios g ON a.inicio = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios h ON a.finalizo = h.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes i ON a.parte = i.id LEFT JOIN " + this.servicio.rBD() + ".lotes j ON a.lote = j.id " + cadWhere + ")) AS a ORDER BY 1 DESC";
      

      this.tituloBuscar = "Filtrar paros";
      this.literalSingular = "un paro";
      this.literalPlural = "paros";
      this.literalSingularArticulo = "El paro";
      this.mensajePadre = "";
    }
    else if (tabla == 27)
    {
      this.nCatalogo = "RECHAZOS"
      this.etiBuscar = "Buscar rechazo";
      this.iconoGeneral = "i_rechazo";

      if (this.servicio.rFRechazo().mes == 0)
      {
        this.servicio.aFRechazo({mes: this.servicio.fecha(1, "", "MM"), ano: this.servicio.fecha(1, "", "yyyy"), clasificacion: "-1", producto: "-1", maquina: "-1" });
      }
      mensajeSI = this.servicio.rFRechazo().clasificacion == -1;
      let cadWhere = "";
      let cadWhere2 = "";
      if (this.servicio.rFRechazo().producto != -1)
      {
        cadWhere = cadWhere + " AND a.parte = " + this.servicio.rFRechazo().producto; 
        cadWhere2 = cadWhere2 + " AND a.parte = " + this.servicio.rFRechazo().producto; 
      }
      if (this.servicio.rFRechazo().clasificacion > 0)
      {
        cadWhere = cadWhere + " AND a.tipo = " + this.servicio.rFRechazo().clasificacion; 
      }
      
      if (this.servicio.rFRechazo().maquina != -1)
      {
        cadWhere = cadWhere + " AND a.equipo = " + this.servicio.rFRechazo().maquina; 
        cadWhere2 = cadWhere2 + " AND a.equipo = " + this.servicio.rFRechazo().maquina;
      }
      let uDia = new Date(+this.servicio.rFRechazo().ano, this.servicio.rFRechazo().mes, 0).getDate();
      sentencia = "SELECT * FROM (SELECT a.tipo, a.id, a.corte, a.cantidad, a.fecha, a.origen, a.rechazo, IFNULL(c.nombre, 'SIN ASIGNACION') AS narea, IF(ISNULL(e.nombre), d.nombre, CONCAT(d.nombre, ' / ',  e.nombre)) AS nequipo, IFNULL(f.nombre, '(SIN CLASIFICAR)') AS ntipo FROM " + this.servicio.rBD() + ".detallerechazos a INNER JOIN " + this.servicio.rBD() + ".lecturas_cortes b ON a.corte = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas c ON a.area = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales f ON a.tipo = f.id WHERE a.fecha >= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/01' AND a.fecha <= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/" + uDia + "' " + cadWhere + ") AS q1 "
      if (this.servicio.rFRechazo().clasificacion == -1)
      {
        sentencia = sentencia + " UNION ALL SELECT 0 AS tipo, a.id, a.id AS corte, a.calidad - a.calidad_clasificada AS cantidad, a.dia AS fecha, 0 AS origen, 'N/A' AS rechazo, 'SIN ASIGNACION' AS narea, IF(ISNULL(e.nombre), d.nombre, CONCAT(d.nombre, ' / ',  e.nombre)) AS nequipo, '(SIN IDENTIFICAR)' AS ntipo FROM " + this.servicio.rBD() + ".lecturas_cortes a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id WHERE a.calidad - a.calidad_clasificada > 0 AND a.dia >= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/01' AND a.dia <= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/" + uDia + "' " + cadWhere2 + " "
      }
      if (this.servicio.rFRechazo().clasificacion == 0)
      {
        sentencia = "SELECT 0 AS tipo, a.id, a.id AS corte, a.calidad - a.calidad_clasificada AS cantidad, a.dia AS fecha, 0 AS origen, 'N/A' AS rechazo, 'SIN ASIGNACION' AS narea, IF(ISNULL(e.nombre), d.nombre, CONCAT(d.nombre, ' / ',  e.nombre)) AS nequipo, '(SIN CLASIFICAR)' AS ntipo FROM " + this.servicio.rBD() + ".lecturas_cortes a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id WHERE a.calidad - a.calidad_clasificada > 0 AND a.dia >= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/01' AND a.dia <= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/" + uDia + "' " + cadWhere2 + " "
      }
      sentencia = sentencia + "ORDER BY 5, 6;";

      this.sentenciaR = "SELECT a.id, a.corte, a.fecha, a.cantidad, a.rechazo, a.notas, c.nombre, a.area, d.nombre AS n2, a.equipo, e.nombre AS n3, d.linea, f.nombre AS n4, a.tipo, g.nombre AS n5, a.parte, h.nombre AS n6, a.turno, i.numero, a.lote, a.actualizacion, j.nombre AS n7, a.usuario FROM (SELECT a.tipo, a.id, a.corte, a.cantidad, a.fecha, a.origen, a.rechazo, a.area, a.equipo, a.parte, a.turno, a.lote, a.notas, a.actualizacion, a.usuario FROM " + this.servicio.rBD() + ".detallerechazos a INNER JOIN " + this.servicio.rBD() + ".lecturas_cortes b ON a.corte = b.id WHERE a.id > 0 AND a.fecha >= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/01' AND a.fecha <= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/" + uDia + "' UNION ALL SELECT 0 AS tipo, 0 AS id, a.id AS corte, a.calidad - a.calidad_clasificada AS cantidad, a.dia AS fecha, 0 AS origen, 'N/A' AS rechazo, 0 AS AREA, a.equipo, a.parte, a.turno, a.orden, '' AS notas, a.bloque_inicia, 0 AS usuario FROM " + this.servicio.rBD() + ".lecturas_cortes a WHERE a.calidad - a.calidad_clasificada > 0 AND a.dia >= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/01' AND a.dia <= '" + this.servicio.rFRechazo().ano + "/" + this.servicio.rFRechazo().mes + "/" + uDia + "') AS a LEFT JOIN " + this.servicio.rBD() + ".cat_areas c ON a.area = c.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas d ON a.equipo = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas e ON d.linea = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_generales f ON a.tipo  = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_partes g ON a.parte = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_turnos h ON a.turno = h.id LEFT JOIN " + this.servicio.rBD() + ".lotes i ON a.lote = i.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios j ON a.usuario = j.id ORDER BY 3, 21;";

      this.tituloBuscar = "Filtrar rechazos";
      this.literalSingular = "un rechazo";
      this.literalPlural = "rechazos";
      this.literalSingularArticulo = "El rechazo";
      this.mensajePadre = "";
    }

    else if (tabla == 25)
    {
      this.nCatalogo = "NÚMEROS DE PARTE"
      this.etiBuscar = "Buscar partes";
      this.iconoGeneral = "i_partes";
      sentencia = "SELECT a.id, a.nombre, a.referencia, a.modificacion, IF(a.estatus = 'A', 'activo', 'inactivo') AS estatus, IFNULL(c.nombre, 'N/A') AS ucambio, a.imagen FROM " + this.servicio.rBD() + ".cat_partes a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ORDER BY a.nombre;";
      this.sentenciaR = "SELECT 'ID', 'Nombre/Descripcion', 'Referencia', 'Notas', 'Ruta de la imagen asociada', 'Estatus', 'Fecha de creacion', 'Usuario que creo el registro', 'Fecha de ultimo cambio', 'Usuario que efectuo el ultimo cambio' UNION SELECT a.id, a.nombre, a.referencia, a.notas, a.imagen, a.url_mmcall, IFNULL(d.nombre, 'N/A'), IFNULL(e.nombre, 'N/A'), IFNULL(f.nombre, 'N/A'), a.linea, IFNULL(g.nombre, 'N/A'), a.maquina, IFNULL(h.nombre, 'N/A'), a.area, IF(a.estatus = 'A', 'activo', 'inactivo'), a.creacion, IFNULL(b.nombre, 'N/A'), a.modificacion, IFNULL(c.nombre, 'N/A') FROM " + this.servicio.rBD() + ".cat_partes a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id ";
      this.tituloBuscar = "Filtrar parte";
      this.literalSingular = "un número de parte";
      this.literalPlural = "números de parte";
      this.literalSingularArticulo = "El número de parte";
      this.mensajePadre = "";
    }
    this.verSR = false;
    this.cadSQLActual = sentencia;
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.irArriba();
      if(this.miSeleccion == 17 && this.vista17==1)
      {
        for (var i = 0; i < resp.length; i++) 
        {
          resp[i].nombre = resp[i].partes + " NÚMERO(S) DE PARTE"
          resp[i].parte = "N";
        }
      }
      if (mensajeSI)
      {
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-normal";
        mensajeCompleto.mensaje = "Se muestra sólo los registros que requieren atención";
        mensajeCompleto.tiempo = 4000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      
      }
      this.arreHover.length = resp.length;
      this.arreImagenes.length = resp.length
      for (var i=0; i< resp.length; i++)
      {
        
        this.arreImagenes[i] = "S";
              
      }
      
      this.arrFiltrado = resp;
      this.tmpRegistros = resp;
      this.llenarTiempo(0, 50);
    }, 
    error => 
      {
        console.log(error)
      })
  }


  llenarTiempo(inicio, total)
  {
    let limite = inicio + total;

    if (this.miSeleccion != this.seleccionado && this.seleccionado > 0)
    {
      this.registros = [];
      return;
    } 
    this.seleccionado = this.miSeleccion;
    
    if (this.tmpRegistros.length > limite)
    {
      
      setTimeout(() => {
        this.llenarTiempo(inicio + 50, 50);  
      }, 200);
      
    }
    else
    {
      limite = this.tmpRegistros.length;
      setTimeout(() => {
        this.servicio.activarSpinnerSmall.emit(false);   
      }, 200);
        
    }
    for (var i=inicio; i<limite; i++)
    {
      
      this.registros.push(this.tmpRegistros[i]);
            
    }
    
    this.verSR = true;
    this.mostrarDetalle = true;  
    
    //
    this.mostrarImagenRegistro = "S";
    this.cancelarEdicion = false;
    //
    setTimeout(() => {
      this.contarRegs();
      this.servicio.activarSpinner.emit(false);  
      this.visualizarImagen = true; 
      this.animando = true;       
    }, 100);

    
    this.buscar();
  }
  
  imagenError(event, id: number)
  {
    this.arreImagenes[id] = "N";
  }

  imagenBien(event, id: number)
  {
    this.arreImagenes[id] = "S";
    
  }

  filtrar()
  {
    this.sondeo = 0;
    this.animando = false;
    this.registros = this.aplicarFiltro(this.textoBuscar);
    setTimeout(() => {
      this.animando = true;  
    }, 200);
    
    this.contarRegs(); 
  }

  aplicarFiltro(cadena: string) 
  {
    let tmpRegistros = [];
    this.servicio.activarSpinnerSmall.emit(true);
    if (cadena ) 
    {
      for (var i = 0; i < this.arrFiltrado.length; i  ++)
      {
        for (var j in this.arrFiltrado[i])
        {
          if (this.arrFiltrado[i][j])
          {
            if (this.servicio.tildes(this.arrFiltrado[i][j], "M").toLowerCase().indexOf(cadena.toLowerCase()) !== -1)
            {
              tmpRegistros.splice(tmpRegistros.length, 0, this.arrFiltrado[i]);
              break;
            }
          }
        }
      }
    }
    else
    {
      tmpRegistros = this.arrFiltrado;
    }
    this.servicio.activarSpinnerSmall.emit(false);
    return tmpRegistros;
  }
  
  contarRegs()
  {
    if (this.router.url.substr(0, 10) != "/catalogos" || this.noLeer )
    {
      return;
    }
    let mensaje = "";
    
    let cadAdicional: string = (this.registros.length != this.arrFiltrado.length ? " (filtrado de un total de " + this.arrFiltrado.length + ") " : "");
    this.hayFiltro = this.registros.length != this.arrFiltrado.length;
    if (this.registros.length > 0)
    {
      mensaje = "Hay " + (this.registros.length == 1 ? " " + this.literalSingular : this.registros.length + " " + this.literalPlural);
    }
    else
    {
      mensaje = "No hay " + this.literalPlural
    }
    let cadAlarmas: string = "";
    {
      this.alarmados = 0;
      for (var i = 0; i < this.arrFiltrado.length; i++)
      {
        if (this.arrFiltrado[i].estatus == 'inactivo')
        {
          this.alarmados = this.alarmados + 1
        }
      }
      if (this.alarmados > 0)
      {
        cadAlarmas = "<span class='resaltar'>" + (this.alarmados == 1 ? "un registro inactivo" : this.alarmados + " registros inactivos") + "</span>";
      }
    }
    mensaje = mensaje + " " + cadAdicional + " " + this.mensajePadre + " " + cadAlarmas
    this.servicio.mensajeInferior.emit(mensaje);          
  }

  
  rConfiguracion()
  {
    this.configuracion = [];
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".configuracion";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.configuracion = resp[0]; 
      }
    }, 
    error => 
      {
        console.log(error)
      })
  }

  cambiarVista(modo: number)
  {
    this.animando = false;
    this.sondeo = 0;
    let vistaRecuadro: boolean = false;
    if (modo == 1)
    {
      vistaRecuadro = (this.modelo == 13 || this.modelo == 3) && modo == 1;
      this.servicio.guardarVista(this.miSeleccion + 10, (vistaRecuadro ? 1: 0))      
    }
    else
    {
      vistaRecuadro = this.servicio.rUsuario().preferencias_andon.substr(9 + this.miSeleccion, 1) == "1";
    }
    if (vistaRecuadro)
    {
      if (this.modelo > 10)
      {
        this.modelo = this.modelo - 10;
      }
      else
      {
        this.modelo = (modo == 2 ? 2 : 12);
      }
      this.ayuda11 = "Cambiar a vista detalle"
      this.iconoVista = "i_vdetalle"
      this.literalVista = "Ver detalle"
      this.verTabla = false;
    }
    else
    { 
      if (this.modelo > 10)
      {
        this.modelo = this.modelo - 10;
      }
      else
      {
        this.modelo = (modo == 2 ? 3 : 13);  
      }
      this.ayuda11 = "Cambiar a vista recuadro"
      this.iconoVista = "i_vcuadro"
      this.literalVista = "Ver tarjetas"
      this.verTabla = true;
    }
    setTimeout(() => {
      this.animando = true;
      if (this.txtBuscar)
      {
        this.txtBuscar.nativeElement.focus();
      }
    }, 300);
  }

  cadaSegundo()
  {
    }

  
  leerBD()
  {
    if (this.noLeer || this.router.url.substr(0, 10) != "/catalogos")
    {
      return;
    }
    let campo: string = "lineas";
    if  (this.miSeleccion==2)
    {
      campo = "maquinas";
    }
    else if (this.miSeleccion==3)
    {
      campo = "areas";
    }

    else if (this.miSeleccion==4)
    {
      campo = "fallas";
    }
    else if (this.miSeleccion==5)
    {
      campo = "generales";
    }
    else if (this.miSeleccion==6)
    {
      campo = "distribucion";
    }
    else if (this.miSeleccion==7)
    {
      campo = "correos";
    }
    else if (this.miSeleccion==8)
    {
      campo = "alertas";
    }
    else if (this.miSeleccion==9)
    {
      campo = "turnos";
    }
    else if (this.miSeleccion==10)
    {
      campo = "traducciones";
    }
    else if (this.miSeleccion==12)
    {
      campo = "usuarios";
    }
    else if (this.miSeleccion==14)
    {
      campo = "politicas";
    }
    else if (this.miSeleccion==17)
    {
      campo = "rates";
    }
    else if (this.miSeleccion==18)
    {
      campo = "objetivos";
    }
  else if (this.miSeleccion==19)
  {
    campo = "estimados";
  }
  else if (this.miSeleccion==20)
  {
    campo = "sensores";
  }
  else if (this.miSeleccion==21)
  {
    campo = "paros";
  }
    let sentencia = "SELECT " + campo + " FROM " + this.servicio.rBD() + ".actualizaciones";
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      let revisar: boolean = false;
      if (resp.length > 0)
      {
        if (resp[0][campo])
        {
          if (new Date(resp[0][campo]) > this.ultimaActualizacion)
          {
            revisar = true;
          }
        }
      }
      if (revisar)
      {
        campos = {accion: 100, sentencia: this.cadSQLActual};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
          if (this.vista17==1 && this.miSeleccion==17)
          {
            for (var i = 0; i < resp.length; i++) 
            {
              resp[i].nombre = resp[i].partes + " NÚMERO(S) DE PARTE"
              resp[i].parte = "N";
            }
          }
          this.arrFiltrado = resp;
          let arreTemp: any = this.arrFiltrado;
          if (this.hayFiltro)
          {
            arreTemp = this.aplicarFiltro(this.textoBuscar);
          }
          let actualizar: boolean = false; 
          actualizar = JSON.stringify(this.registros) != JSON.stringify(arreTemp);
          if (actualizar)
          {
            if (resp.length == 0)
            {
              this.registros = [];
            }
            if (this.arrFiltrado.length == 0 && resp.length > 0)
            {
              this.registros = arreTemp;
            }
            else 
            {
              for (i = this.registros.length - 1; i >= 0; i--)
              {
                let hallado = false;
                for (var j = arreTemp.length - 1; j >= 0 ; j--)
                {
                  if (this.registros[i].id ==  arreTemp[j].id)
                  {
                    if (this.miSeleccion == 10)
                    {
                      if (this.registros[i].literal !=  arreTemp[j].literal || this.registros[i].traduccion !=  arreTemp[j].traduccion)
                      {
                        this.registros[i].literal = arreTemp[j].literal;
                        this.registros[i].traduccion = arreTemp[j].traduccion;
                      }
                    }
                    else if (this.miSeleccion != 10)
                    {
                      if (this.registros[i].estatus !=  arreTemp[j].estatus || this.registros[i].nombre !=  arreTemp[j].nombre )
                      {
                        this.registros[i].estatus = arreTemp[j].estatus;
                        this.registros[i].nombre = arreTemp[j].nombre;
                      }
                    }
                    if (this.miSeleccion == 2)
                    {
                      if (this.registros[i].nlinea !=  arreTemp[j].nlinea)
                      {
                        this.registros[i].nlinea = arreTemp[j].nlinea;
                      }
                    }
                    else if (this.miSeleccion == 5)
                    {
                      if (this.registros[i].ntabla !=  arreTemp[j].ntabla)
                      {
                        this.registros[i].ntabla = arreTemp[j].ntabla;
                      }
                    }
                    else if (this.miSeleccion == 9)
                    {
                      if (this.registros[i].inicia !=  arreTemp[j].inicia)
                      {
                        this.registros[i].inicia = arreTemp[j].inicia;
                      }
                      if (this.registros[i].termina !=  arreTemp[j].termina)
                      {
                        this.registros[i].termina = arreTemp[j].termina;
                      }
                    }
                    else if (this.miSeleccion == 17)
                    {
                      if (this.registros[i].piezas !=  arreTemp[j].piezas)
                      {
                        this.registros[i].piezas = arreTemp[j].piezas;
                      }
                      if (this.registros[i].tiempo !=  arreTemp[j].tiempo)
                      {
                        this.registros[i].tiempo = arreTemp[j].tiempo;
                      }
                      if (this.vista17==0)
                      {
                        if (this.registros[i].equipo !=  arreTemp[j].equipo)
                        {
                          this.registros[i].equipo = arreTemp[j].equipo;
                        }
                        if (this.registros[i].parte !=  arreTemp[j].parte)
                        {
                          this.registros[i].parte = arreTemp[j].parte;
                        }
                      }
                      else
                      {
                        if (this.registros[i].nequipo !=  arreTemp[j].nequipo)
                        {
                          this.registros[i].nequipo = arreTemp[j].nequipo;
                        }
                        if (this.registros[i].nombre !=  arreTemp[j].nombre)
                        {
                          this.registros[i].nombre = arreTemp[j].nombre;
                        }
                      }
                      
                    }
                    else if (this.miSeleccion == 18)
                    {
                      if (this.registros[i].objetivo !=  arreTemp[j].objetivo)
                      {
                        this.registros[i].objetivo = arreTemp[j].objetivo;
                      }
                      if (this.registros[i].equipo !=  arreTemp[j].equipo)
                      {
                        this.registros[i].equipo = arreTemp[j].equipo;
                      }
                      if (this.registros[i].parte !=  arreTemp[j].parte)
                      {
                        this.registros[i].parte = arreTemp[j].parte;
                      }
                    }
                    else if (this.miSeleccion == 19)
                    {
                      if (this.registros[i].oee !=  arreTemp[j].oee)
                      {
                        this.registros[i].oee = arreTemp[j].oee;
                      }
                      if (this.registros[i].equipo !=  arreTemp[j].equipo)
                      {
                        this.registros[i].equipo = arreTemp[j].equipo;
                      }
                      if (this.registros[i].linea !=  arreTemp[j].linea)
                      {
                        this.registros[i].linea = arreTemp[j].linea;
                      }
                    }
                    else if (this.miSeleccion == 20)
                    {
                      if (this.registros[i].equipo !=  arreTemp[j].equipo)
                      {
                        this.registros[i].equipo = arreTemp[j].equipo;
                      }
                    }
                    else if (this.miSeleccion == 21)
                    {
                      if (this.registros[i].area !=  arreTemp[j].area)
                      {
                        this.registros[i].area = arreTemp[j].area;
                      }
                      if (this.registros[i].maquina !=  arreTemp[j].maquina)
                      {
                        this.registros[i].maquina = arreTemp[j].maquina;
                      }
                      if (this.registros[i].desde !=  arreTemp[j].desde)
                      {
                        this.registros[i].desde = arreTemp[j].desde;
                      }
                      if (this.registros[i].hasta !=  arreTemp[j].hasta)
                      {
                        this.registros[i].hasta = arreTemp[j].hasta;
                      }
                      if (this.registros[i].tipo !=  arreTemp[j].tipo)
                      {
                        this.registros[i].tipo = arreTemp[j].tipo;
                      }
                    }
                    else if (this.miSeleccion == 27)
                    {
                      if (this.registros[i].area !=  arreTemp[j].area)
                      {
                        this.registros[i].area = arreTemp[j].area;
                      }
                      if (this.registros[i].equipo !=  arreTemp[j].equipo)
                      {
                        this.registros[i].equipo = arreTemp[j].equipo;
                      }
                      if (this.registros[i].fecha !=  arreTemp[j].fecha)
                      {
                        this.registros[i].fecha = arreTemp[j].fecha;
                      }
                      if (this.registros[i].rechazo !=  arreTemp[j].rechazo)
                      {
                        this.registros[i].rechazo = arreTemp[j].rechazo;
                      }
                      if (this.registros[i].cantidad !=  arreTemp[j].cantidad)
                      {
                        this.registros[i].cantidad = arreTemp[j].cantidad;
                      }
                      if (this.registros[i].tipo !=  arreTemp[j].tipo)
                      {
                        this.registros[i].tipo = arreTemp[j].tipo;
                      }
                    }
                    hallado = true;
                    break;
                  }
                }
                if (!hallado)
                {
                  this.registros.splice(i, 1);
                }
              }
              for (var i = 0; i < arreTemp.length; i++)
              {
                let agregar = true;
                for (var j = 0; j < this.registros.length; j++)
                {
                  if (this.registros[j].id == arreTemp[i].id)
                  {
                    agregar = false
                    break;              
                  }
                }
                if (agregar)
                {
                  this.registros.splice(i, 0, arreTemp[i])
                  this.sondeo = arreTemp[i].id;
                }
              }
            }
            this.contarRegs()
          }
        });
      }
      this.ultimaActualizacion = new Date();
      clearTimeout(this.leeBD);
      if (this.router.url.substr(0, 10) == "/catalogos")
      {
        this.leeBD = setTimeout(() => {
          this.leerBD()
        }, +this.elTiempo);
      }
  
    })

    }

  editar(id: number)
  {
    
    let miID: number = 0;
    if (id == -1)
    {
      miID = this.detalle.id;
      if (this.miSeleccion==17 && this.vista17==1)
      {
        miID = this.idRates; 
      }
    }
    else
    {
      miID = this.registros[id].id;
      this.idRates = id; 
      this.arreHover[id] = false
    }
    //this.yaValidado = miID;
    this.botonera1 = 2;
    let sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
    if (this.miSeleccion == 1)
    {
      this.iconoGeneral = "i_lineas";
      this.literalSingularArticulo = "La línea";
      this.servicio.mensajeInferior.emit("Edición de líneas");           
    }
    else if (this.miSeleccion == 2)
    {
      this.iconoGeneral = "i_maquina";
      this.literalSingularArticulo = "La máquina";
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID;   
      this.llenarListas(3, this.servicio.rBD() + ".cat_lineas", "");
      this.llenarListas(6, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 50 " );
      this.llenarListas(22, this.servicio.rBD() + ".cat_usuarios", "");
      this.servicio.mensajeInferior.emit("Edición de máquinas");           
    }
    else if (this.miSeleccion == 3)
    {
      this.iconoGeneral = "i_responsable";
      this.literalSingularArticulo = "El área";
      this.servicio.mensajeInferior.emit("Edición de áreas de servicio");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(9, this.servicio.rBD() + ".cat_distribucion", "");
    }
    else if (this.miSeleccion == 28)
    {
      this.iconoGeneral = "i_variables";
      this.literalSingularArticulo = "La variable";
      this.servicio.mensajeInferior.emit("Edición de variables");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_variables a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(1110, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 110 " );
      this.llenarListas(1115, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 115 " );
      this.llenarListas(9, this.servicio.rBD() + ".cat_distribucion", "");
      this.asociarValores(miID);
      this.asociarVariablesMaquinas(miID);
    }
    else if (this.miSeleccion == 29)
    {
      this.iconoGeneral = "i_checklist";
      this.literalSingularArticulo = "El checklist";
      this.servicio.mensajeInferior.emit("Edición de checklist");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_checklists a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(10, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 70 " );
      this.llenarListas(1120, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 120 " );
      this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
      
    }
    else if (this.miSeleccion == 30)
    {
      this.respondido = 0;
      this.iconoGeneral = "i_plan";
      this.literalSingularArticulo = "El plan";
      this.servicio.mensajeInferior.emit("Edición de planes de checklist");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".plan_checklists a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(10150, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND (campo = 10 OR campo = 150) " );
      this.checklistPlan(miID);
    }
    else if (this.miSeleccion == 4)
    {
      this.iconoGeneral = "i_falla";
      this.literalSingularArticulo = "La falla";
      this.servicio.mensajeInferior.emit("Edición de fallas");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_fallas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.asociarTablasFalla(miID);
      this.validarCU = false;
      this.validarM = false;
    }
    else if (this.miSeleccion == 25)
    {
      this.iconoGeneral = "i_partes";
      this.literalSingularArticulo = "El número de parte";
      this.servicio.mensajeInferior.emit("Edición de número de parte");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_partes a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.asociarTablasHerramental(miID);
      this.llenarListas(93, this.servicio.rBD() + ".cat_rutas", "");
      this.validarCU = false;
      this.validarM = false;
    }
    else if (this.miSeleccion == 5)
    {
      this.iconoGeneral = "i_general";
      this.literalSingularArticulo = "El registro general";
      this.servicio.mensajeInferior.emit("Edición de registros generales");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_generales a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(7, this.servicio.rBD() + ".tablas", "");
    }
    else if (this.miSeleccion == 6)
    {
      this.iconoGeneral = "i_recipiente";
      this.literalSingularArticulo = "El recipiente";
      this.servicio.mensajeInferior.emit("Edición de recipientes");           
        sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_distribucion a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
    }

    else if (this.miSeleccion == 7)
    {
      this.iconoGeneral = "i_correos";
      this.literalSingularArticulo = "El correo/reporte";
      this.servicio.mensajeInferior.emit("Edición de correos/reportes");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_correos a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(10010, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 10 " );
      this.llenarListas(10020, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 20 " );
      this.llenarListas(10030, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 30 " );
      this.listarListados(miID)
    }

    else if (this.miSeleccion == 8)
    {
      this.iconoGeneral = "i_alertas";
      this.literalSingularArticulo = "La alerta";
      this.servicio.mensajeInferior.emit("Edición de alertas");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_alertas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.asociarTablasAlerta(miID);
      let filtroTabla = " WHERE estatus = 'A' AND (alerta < 200" 
      if (this.servicio.rVersion().modulos[5] == 1)
      {
        filtroTabla = filtroTabla + " OR alerta BETWEEN 200 AND 300"
      }
      if (this.servicio.rVersion().modulos[4] == 1)
      {
        filtroTabla = filtroTabla + " OR alerta BETWEEN 300 AND 400"
      }
      if (this.servicio.rVersion().modulos[6] == 1)
      {
        filtroTabla = filtroTabla + " OR alerta BETWEEN 400 AND 500"
      }
      filtroTabla = filtroTabla + ")"
      this.llenarListas(31, this.servicio.rBD() + ".int_eventos", filtroTabla);
      this.llenarListas(9, this.servicio.rBD() + ".cat_distribucion", "");
    }
    else if (this.miSeleccion == 9)
    {
      this.iconoGeneral = "i_turnos";
      this.literalSingularArticulo = "El turno";
      this.servicio.mensajeInferior.emit("Edición de turnos");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_turnos a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.llenarListas(22, this.servicio.rBD() + ".cat_usuarios", "");      
    }
    else if (this.miSeleccion == 10)
    {
      this.iconoGeneral = "i_traductor";
      this.literalSingularArticulo = "La frase";
      this.servicio.mensajeInferior.emit("Edición de frases a traducir");           
      sentencia = "SELECT a.* FROM " + this.servicio.rBD() + ".traduccion a WHERE a.id = " + miID; 
    }
    else if (this.miSeleccion == 12)
    {
      this.iconoGeneral = "i_grupos";
      this.literalSingularArticulo = "El usuario";
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".cat_usuarios a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID;   
      this.llenarListas(10, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 70 " );
      this.llenarListas(11, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 80 " );
      this.llenarListas(12, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 90 " );
      this.llenarListas(14, this.servicio.rBD() + ".cat_turnos", "");
      this.llenarListas(13, this.servicio.rBD() + ".politicas", "" );
      this.llenarListas(105, this.servicio.rBD() + ".cat_idiomas", "" );
      this.asociarTablas(miID);
      this.servicio.mensajeInferior.emit("Edición de usuarios"); 
      this.validarUSER = false;          
    }
    else if (this.miSeleccion == 14)
    {
      this.iconoGeneral = "i_politicas";
      this.literalSingularArticulo = "La política";
      this.servicio.mensajeInferior.emit("Edición de políticas");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".politicas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.listarListados(miID);
      this.llenarListas(10120, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 120 " );
      this.llenarListas(10130, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 130 " );
      
    }
    else if (this.miSeleccion == 15)
    {
      this.iconoGeneral = "i_licencia";
      this.literalSingularArticulo = "La licencia";
      this.servicio.mensajeInferior.emit("Edición de licencias");           
      sentencia = "SELECT a.*, IFNULL(b.nombre, 'N/A') AS ucreo, IFNULL(c.nombre, 'N/A') AS ucambio FROM " + this.servicio.rBD() + ".politicas a LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios b ON a.creado = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios c ON a.modificado = c.id WHERE a.id = " + miID; 
      this.listarListados(miID)
    }
    else if (this.miSeleccion == 17)
    {
      this.iconoGeneral = this.icoVista17=="i_maquina" ? "i_rates" : "i_maquina";
      this.literalSingularArticulo = "El rate";
      if (this.vista17==0)
      {
        sentencia = "SELECT * FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE id = " + miID;   
      }
      else
      {
        sentencia = "SELECT a.piezas, a.unidad, a.equipo, IFNULL(CONCAT(b.nombre, ' / ', c.nombre), '(CUALQUIERA)') AS nequipo, COUNT(DISTINCT(a.parte)) AS partes, a.tiempo, a.alto, a.bajo FROM " + this.servicio.rBD() + ".relacion_partes_equipos a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas b ON a.equipo = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON b.linea = c.id WHERE a.piezas = " + this.registros[this.idRates].piezas + " GROUP BY a.piezas, a.unidad, a.equipo";
      }
      
      this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
      this.llenarListas(15, this.servicio.rBD() + ".cat_partes", "");
      this.servicio.mensajeInferior.emit("Edición de rates de producción");           
      
    }
    else if (this.miSeleccion == 18)
    {
      this.iconoGeneral = "i_objetivos";
      this.literalSingularArticulo = "El objetivo";
      sentencia = "SELECT * FROM " + this.servicio.rBD() + ".equipos_objetivo WHERE id = " + miID;   
      this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
      this.llenarListas(15, this.servicio.rBD() + ".cat_partes", "");
      this.llenarListas(17, this.servicio.rBD() + ".lotes", "WHERE a.estado <> 99 AND a.estatus = 'A'");
      this.llenarListas(18, this.servicio.rBD() + ".cat_turnos", "");
      this.servicio.mensajeInferior.emit("Edición de objetivos de producción");           
    }
    else if (this.miSeleccion == 19)
    {
      this.iconoGeneral = "i_estimados";
      this.literalSingularArticulo = "El estimado";
      sentencia = "SELECT * FROM " + this.servicio.rBD() + ".estimados WHERE id = " + miID;   
      this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
      this.llenarListas(19, this.servicio.rBD() + ".cat_lineas", "");
      this.servicio.mensajeInferior.emit("Edición de estimados de indicadores");           
    }
    else if (this.miSeleccion == 20)
    {
      this.iconoGeneral = "i_sensor";
      this.literalSingularArticulo = "El sensor";
      sentencia = "SELECT * FROM " + this.servicio.rBD() + ".relacion_procesos_sensores WHERE id = " + miID;   
      this.llenarListas(20, this.servicio.rBD() + ".cat_maquinas", "");
      this.llenarListas(10140, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 140 " );
      this.llenarListas(5, this.servicio.rBD() + ".cat_areas", "");
      this.llenarListas(107, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 105 " );
     
     
      this.servicio.mensajeInferior.emit("Edición de sensores (OAE)");           
    }
    else if (this.miSeleccion == 21)
    {
      
      this.iconoGeneral = "i_paro";
      this.literalSingularArticulo = "El paro";
      sentencia = "SELECT * FROM " + this.servicio.rBD() + ".detalleparos WHERE id = " + miID;   
      this.llenarListas(23, this.servicio.rBD() + ".cat_areas", "");
      this.llenarListas(6, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 45 " );
      this.servicio.mensajeInferior.emit("Edición de paros");    
      this.llenarListas(4, this.servicio.rBD() + ".cat_maquinas", " WHERE a.oee = 'S' ");       
    }
    else if (this.miSeleccion == 27)
    {
      this.cantidadValidada = false;
      this.iconoGeneral = "i_rechazo";
      this.literalSingularArticulo = "El rechazo";
      this.corteActual = this.detalle.corte;
      if (this.detalle.origen == 0 && this.detalle.tipo == 0)
      {
        
        sentencia = "SELECT *, orden AS lote, 0 AS tipo, 0 AS van, dia AS fecha, calidad - calidad_clasificada AS cantidad, 0 AS existe FROM " + this.servicio.rBD() + ".lecturas_cortes WHERE id = " + this.corteActual;   
      }
      else
      {
        {
          sentencia = "SELECT a.*, 1 AS existe, a.cantidad AS van, b.numero AS orden FROM " + this.servicio.rBD() + ".detallerechazos a LEFT JOIN " + this.servicio.rBD() + ".lotes b ON a.lote = b.id WHERE a.id = " + miID;   
        }
      }
      this.llenarListas(23, this.servicio.rBD() + ".cat_areas", "");
      this.llenarListas(115, this.servicio.rBD() + ".cat_partes", "");
      this.lotes = [];
      this.llenarListas(118, this.servicio.rBD() + ".cat_turnos", "");
      this.llenarListas(106, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 105 " );
      this.servicio.mensajeInferior.emit("Edición de rechazos");    
      this.llenarListas(104, this.servicio.rBD() + ".cat_maquinas", " WHERE a.oee = 'S' ");       
    }
    this.adecuar();
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {

        this.faltaMensaje = "";
        this.error01 = false;
        this.error02 = false;
        this.error03 = false;
        this.error04 = false;
        this.error05 = false;
        this.error06 = false;
        this.error07 = false;
        this.error08 = false;
        this.error09 = false;
        this.error10 = false;
        this.error20 = false;
        this.error21 = false;
        this.error22 = false;
        this.error23 = false;
        this.error24 = false; 
        this.error25 = false;
        this.error30 = false;
        this.error31 = false;
        this.error32 = false;
        this.error33 = false;
        this.error34 = false;
        this.error35 = false;
        this.error36 = false;
        if (this.miSeleccion==3)
        {
          if (resp[0].audios_ruta)
          {
            resp[0].audios_ruta = resp[0].audios_ruta.replace(/\//g, '\\');
          }
          if (resp[0].audios_prefijo)
          {
            resp[0].audios_prefijo = resp[0].audios_prefijo.replace(/\//g, '\\');
          }
        }

        this.detalle = resp[0];
        if (this.miSeleccion==17)
        {
          if (this.vista17==1)
          {
            this.llenarPartes(false);
            this.detalle.parte = "N";
            this.piezasAntes = resp[0].piezas * 1;
            this.equipoAntes = resp[0].equipo;
          }
          this.detalle.piezas = resp[0].piezas * 1;
          this.detalle.alto = resp[0].alto * 1;
          this.detalle.bajo = resp[0].bajo * 1;
          
        }
        if (this.miSeleccion==18)
        {
          this.detalle.objetivo = resp[0].objetivo * 1;
        }
        if (this.miSeleccion==19)
        {
          this.detalle.oee = resp[0].oee * 1;
          this.detalle.efi = resp[0].efi * 1;
          this.detalle.ftq = resp[0].ftq * 1;
          this.detalle.dis = resp[0].dis * 1;
        }
        else if (this.miSeleccion == 21) 
        {
          this.detalle.finaliza_sensor = this.detalle.finaliza_sensor ? this.detalle.finaliza_sensor : "S";
          //this.detalle.masivo = this.detalle.masivo ? this.detalle.masivo : "N";
          this.detalle.fdesde = new Date(this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd"));
          this.detalle.fhasta = new Date(this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd"));
          this.detalle.desde = this.servicio.fecha(2, this.detalle.desde, "HH:mm:ss");
          this.detalle.hasta = this.servicio.fecha(2, this.detalle.hasta, "HH:mm:ss");
          //this.detalle.hora_inicial = this.servicio.fecha(2, this.detalle.hora_inicial, "HH:mm:ss");
          //this.detalle.hora_final = this.servicio.fecha(2, this.detalle.hora_final, "HH:mm:ss");
          if (this.detalle.estado == 'C')
          {
            this.faltaMensaje = "El paro no se podrá editar mientras esté en curso"
          }
          else if (this.detalle.estado == 'F')
          {
            this.faltaMensaje = "El paro ya finalizó. No se podrá editar"
          }
          this.paroEnCurso = this.detalle.estado == "C" || this.detalle.estado == "F";
        }
        else if (this.miSeleccion == 27) 
        {
          this.detalle.nuevo = false;
          this.detalle.fecha = new Date(this.detalle.fecha + " 23:00:00")
          this.buscarListas(0);
          this.buscarRate(1)
          this.detalle.cantidad = resp[0].cantidad * 1;
          this.cantidadActual = this.detalle.van;
          
           
        }
        else if (this.miSeleccion == 28)
        {
          this.detalle.maximo = this.detalle.maximo ? this.detalle.maximo * 1 : this.detalle.maximo
          this.detalle.minimo = this.detalle.minimo? this.detalle.minimo * 1 : this.detalle.minimo
          this.detalle.reiniciar_en = this.detalle.reiniciar_en ? this.detalle.reiniciar_en * 1 : this.detalle.reiniciar_en
          this.detalle.tope = this.detalle.tope ? this.detalle.tope * 1 : this.detalle.tope
          this.activarNumero = this.detalle.tipo_valor == 0;
        }
        else if (this.miSeleccion == 29)
        {
          this.detalle.variables = "S";
          this.variables(miID);
        }
        else if (this.miSeleccion == 9) 
        {
          this.detalle.usuario = resp[0].usuario ? resp[0].usuario : 0;
        }
        this.mostrarImagenRegistro = "S"
        this.mensajeImagen = "Campo opcional"
        this.mostrarDetalle = true;  
        this.editando = false;
        this.modelo = this.modelo !=4 ? 14 : 4;
        this.noLeer = true;
        this.bot5 = true;
        this.bot6 = this.detalle.estatus == "A";
        this.bot7 = true;
        this.faltaMensaje = "";
        this.selListadoT = "S";
        if (this.miSeleccion == 8)
        {
          this.detalle.linea = this.detalle.linea != "N" ? "S" : "N";
          this.detalle.falla = this.detalle.falla != "N" ? "S" : "N";
          this.detalle.proceso = this.detalle.proceso != "N" ? "S" : "N";
          this.detalle.maquina = this.detalle.maquina != "N" ? "S" : "N";
          this.detalle.area =  this.detalle.area != "N" ? "S" : "N"; 
          this.seleccionMensaje = [];
          this.seleccionescalar1 = [];
          this.seleccionescalar2 = [];
          this.seleccionescalar3 = [];
          this.seleccionescalar4 = [];
          this.seleccionescalar5 = [];
          ///
          if (this.detalle.sms == "S")
          {
            this.seleccionMensaje.push("S");
          }
          if (this.detalle.llamada == "S")
          {
            this.seleccionMensaje.push("L");
          }
          if (this.detalle.correo == "S")
          {
            this.seleccionMensaje.push("C");
          }
          if (this.detalle.mmcall == "S")
          {
            this.seleccionMensaje.push("M");
          }
          if (this.detalle.log == "S")
          {
            this.seleccionMensaje.push("G")
          }
          

          if (this.detalle.sms1 == "S")
          {this.seleccionescalar1.push("S");}
          if (this.detalle.llamada1 == "S")
          {this.seleccionescalar1.push("L");}
          if (this.detalle.correo1 == "S")
          {this.seleccionescalar1.push("C");}
          if (this.detalle.mmcall1 == "S")
          {this.seleccionescalar1.push("M");}
          if (this.detalle.log1 == "S")
          {this.seleccionescalar1.push("G")}

          if (this.detalle.sms2 == "S")
          {this.seleccionescalar2.push("S");}
          if (this.detalle.llamada2 == "S")
          {this.seleccionescalar2.push("L");}
          if (this.detalle.correo2 == "S")
          {this.seleccionescalar2.push("C");}
          if (this.detalle.mmcall2 == "S")
          {this.seleccionescalar2.push("M");}
          if (this.detalle.log2 == "S")
          {this.seleccionescalar2.push("G")}

          if (this.detalle.sms3 == "S")
          {this.seleccionescalar3.push("S");}
          if (this.detalle.llamada3 == "S")
          {this.seleccionescalar3.push("L");}
          if (this.detalle.correo3 == "S")
          {this.seleccionescalar3.push("C");}
          if (this.detalle.mmcall3 == "S")
          {this.seleccionescalar3.push("M");}
          if (this.detalle.log3 == "S")
          {this.seleccionescalar3.push("G")}

          if (this.detalle.sms4 == "S")
          {this.seleccionescalar4.push("S");}
          if (this.detalle.llamada4 == "S")
          {this.seleccionescalar4.push("L");}
          if (this.detalle.correo4 == "S")
          {this.seleccionescalar4.push("C");}
          if (this.detalle.mmcall4 == "S")
          {this.seleccionescalar4.push("M");}
          if (this.detalle.log4 == "S")
          {this.seleccionescalar4.push("G")}

          if (this.detalle.sms5 == "S")
          {this.seleccionescalar5.push("S");}
          if (this.detalle.llamada5 == "S")
          {this.seleccionescalar5.push("L");}
          if (this.detalle.correo5 == "S")
          {this.seleccionescalar5.push("C");}
          if (this.detalle.mmcall5 == "S")
          {this.seleccionescalar5.push("M");}
          if (this.detalle.log5 == "S")
          {this.seleccionescalar5.push("G")}
        }
        ///
        if (this.miSeleccion==7)
        {
          let mensajes = this.detalle.extraccion.split(";");
          this.nExtraccion = mensajes[0];
          this.nLapso = mensajes[1];
          this.nFrecuencia = mensajes[2];
          this.nHorario = mensajes[3];
        }
        
        if (this.miSeleccion==1 || this.miSeleccion==2)
        {
          let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".disponibilidad WHERE linea = 0 AND maquina = 0 LIMIT 1;"
          if (this.detalle.disponibilidad == 1 && this.miSeleccion==1)
          {
            sentencia = "SELECT * FROM " + this.servicio.rBD() + ".disponibilidad WHERE linea = " + +this.detalle.id + " LIMIT 1;"
          }
          else if (this.detalle.disponibilidad == 1 && this.miSeleccion==2)
          {
            sentencia = "SELECT * FROM " + this.servicio.rBD() + ".disponibilidad WHERE maquina = " + +this.detalle.id + " LIMIT 1;"
          }
          this.listados = [];
          let campos = {accion: 100, sentencia: sentencia};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
            if (resp.length > 0)
            {
              this.disponibilidad = resp[0];
            }
            else
            {
              this.iniDisp();
            }
          });
          this.detalle.mapa = "N/A"
          if (this.miSeleccion==2)
          {
            sentencia = "SELECT (SELECT id FROM " + this.servicio.rBD() + ".mapas WHERE activo  <> 9 ORDER BY id LIMIT 1) AS primero, (SELECT mapa_id FROM " + this.servicio.rBD() + ".figuras WHERE objeto_id = " + this.detalle.id_mapa + " ORDER BY id LIMIT 1) AS mapa"
            this.listados = [];
            let campos = {accion: 100, sentencia: sentencia};  
            this.servicio.consultasBD(campos).subscribe( resp =>
            {
              if (resp.length > 0)
              {
                if (resp[0].mapa)
                {
                  this.detalle.mapa = "Mapa: " + (+resp[0].primero - +resp[0].mapa + 1);
                }
                
              }
            });
          }
        }
        this.detalle.codigo = this.detalle.codigo == "null" ? "" : this.detalle.codigo;
        
        if (this.miSeleccion==14)
        {
          let mensajes = this.detalle.complejidad.split(";");
          this.detalle.largo = mensajes[0];
          this.detalle.especial = mensajes[1];
          this.detalle.numeros = mensajes[2];
          this.detalle.mayusculas = mensajes[3];
        }
        
        ///
        if (this.despuesBusqueda == 1)
        {
          this.copiandoDesde = this.detalle.id;
          this.detalle.id = 0;
          this.piezasAntes = 0;
          this.equipoAntes = -1;
          this.detalle.estado = "P";
          this.detalle.clase = 0;
          this.mostrarImagenRegistro = "S";
          this.detalle.estatus = "A"
          this.bot3 = true;
          this.bot4 = true;
          if (this.detalle.id==0)
          {
            this.bot5 = false;
            this.bot6 = false;
            this.bot7 = false;
          }
          this.paroEnCurso = false;
          this.editando = true;
          this.faltaMensaje = "No se han guardado los cambios..."
          this.detalle.creado = "";
          this.detalle.modificado = "";
          this.detalle.modificacion = null;
          this.detalle.creacion = null;
        }
        else
        {
          this.editando = false;
          this.bot3 = false;
          this.bot4 = false;;
        }
        if (this.miSeleccion==12)
        {
          this.bot6 = this.detalle.admin != "S" && this.detalle.estatus=="A" && this.detalle.id>0;
          this.bot7 = this.detalle.admin != "S"  && this.detalle.id>0;
          this.detalle.mapa = !this.detalle.mapa ? "S" : this.detalle.mapa;
        }
        this.bot1Sel = false;
        this.bot2Sel = false;
        this.bot3Sel = false;
        this.bot4Sel = false;
        this.bot5Sel = false;
        this.bot6Sel = false;
        this.bot7Sel = false;
        this.llenarListas(1, this.servicio.rBD() + ".cat_generales", " WHERE tabla = " + this.miSeleccion * 10);
        this.llenarListas(2, this.servicio.rBD() + ".cat_generales", " WHERE tabla = " + (this.miSeleccion * 10 + 5));
        setTimeout(() => {
          if (this.txtNombre)
          {
            this.txtNombre.nativeElement.focus();
          }
          else if (this.lstC0)
          {
            if (this.vista17== 1)
            {
              this.txtT1.nativeElement.focus();
            }
            else
            {
              this.lstC0.focus();
            }
            
          }
          this.animando = true;       
        }, 400);
        this.buscar();
      }
    },
    error => 
    {
      console.log(error)
    })
}

llenarPartes(nuevo: boolean)
{

  let sentencia = "SELECT a.id, IF(ISNULL(a.referencia), a.nombre, CONCAT(a.nombre, ' (', a.referencia, ')')) AS nombre, IF(ISNULL(b.id), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_partes a LEFT JOIN " + this.servicio.rBD() + ".relacion_partes_equipos b ON a.id = b.parte AND b.piezas = " + this.detalle.piezas + " AND b.equipo = " + this.detalle.equipo + " WHERE a.estatus = 'A' AND tipo IN (0, 2) ORDER BY seleccionado DESC, nombre;";
  if (nuevo)
  {
    sentencia = "SELECT id, IF(ISNULL(a.referencia), a.nombre, CONCAT(a.nombre, ' (', a.referencia, ')')) AS nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_partes WHERE estatus = 'A' AND tipo IN (0, 2) ORDER BY nombre;";
  } 
  this.partesSel = [];
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe( resp =>
  {
      this.partesSel = resp;  
    
  });
}

validarCodigo()
{
  
  let sentencia = "SELECT id, nombre FROM " + this.servicio.rBD() + ".cat_fallas WHERE codigo = '" + this.detalle.codigo +"' AND NOT ISNULL(codigo) AND codigo <> 'null' AND id <> " + this.detalle.id;
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe(resp =>
  {
    if (resp.length > 0)
    {
      this.validarCU = false;
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "480px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "El código directo para ANDON que está intentando utilizar en esta falla ya está asignado a otra falla:<br><br>Descripción: <strong>" + resp[0].nombre + "</strong><br>ID: <strong>" + resp[0].id + "</strong><br><br>Utilice otro código e intente de nuevo", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_falla" }
      });
    }
    else
    {
      this.validarCU = true;
      this.guardar();
    }
    
  })
}

validarUsuario()
{
  
  let sentencia = "SELECT id, nombre FROM " + this.servicio.rBD() + ".cat_usuarios WHERE referencia = '" + this.detalle.referencia +"' AND id <> " + this.detalle.id;
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe(resp =>
  {
    if (resp.length > 0)
    {
      this.validarUSER = false;
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "480px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "Ya existe un usuario con este perfil de usuario:<br><br>Nombre: <strong>" + resp[0].nombre + "</strong><br>ID: <strong>" + resp[0].id + "</strong><br><br>Cambie la referencia del registro e intente de nuevo", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_falla" }
      });
    }
    else
    {
      this.validarUSER = true;
      this.guardar();
    }
    
  })
}

validarMaquina()
{
  
  let sentencia = "SELECT id FROM " + this.servicio.rBD() + ".cat_maquinas WHERE linea = " + this.detalle.linea + " AND id = " + this.detalle.maquina;
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe(resp =>
  {
    if (resp.length == 0)
    {
      this.validarM = false;
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "480px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "La línea y máquina que esta especificando no se corresponden", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_falla" }
      });
    }
    else
    {
      this.validarM = true;
      this.guardar();
    }
    
  })
}

mensajesRadio()
{
  let mensajeCompleto: any = [];
  mensajeCompleto.clase = "snack-normal";
  mensajeCompleto.mensaje = "Se enviaron mensajes a MMCall";
  mensajeCompleto.tiempo = 2000;
  this.servicio.mensajeToast.emit(mensajeCompleto);
}

  guardar()
  {
    if (this.miSeleccion == 21 && this.detalle.estado =='C')
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "Este paro NO se puede cambiar", tiempo: 0, mensaje: "El paro que desea cambiar está en curso", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "", icono2: "", boton3STR: "", icono3: "", icono0: "i_falla" }
      });
      return;
    }
    this.bot3 = false;
    let errores = 0;
    if (this.miSeleccion==4 && !this.validarCU && this.detalle.codigo)
    {
      this.validarCodigo()
      return;
    }
    if (this.miSeleccion==12 && !this.validarUSER)
    {
      this.validarUsuario()
      return;
    }
    if (this.miSeleccion==4 && !this.validarM && this.detalle.maquina > 0 && this.detalle.linea > 0 )
    {
      this.validarMaquina()
      return;
    }
    this.faltaMensaje = "";
    this.error01 = false;
    this.error02 = false;
    this.error03 = false;
    this.error04 = false;
    this.error05 = false;
    this.error06 = false;
    this.error07 = false;
    this.error08 = false;
    this.error09 = false;
    this.error10 = false;
    this.error20 = false;
    this.error21 = false;
    this.error22 = false;
    this.error23 = false;
    this.error24 = false; 
    this.error25 = false;
    this.error30 = false;
    this.error31 = false;
    this.error32 = false;
    this.error33 = false;
    this.error34 = false;
    this.error35 = false;
    this.error36 = false;

    if (this.miSeleccion == 8)
    {
      this.detalle.tipo = (!this.detalle.tipo ? "0" : this.detalle.tipo);
      this.detalle.linea = (!this.detalle.linea ? "S" : this.detalle.linea);
      this.detalle.maquina = (!this.detalle.maquina ? "S" : this.detalle.maquina);
      this.detalle.area = (!this.detalle.area ? "S" : this.detalle.area);
      this.detalle.falla = (!this.detalle.falla ? "S" : this.detalle.falla);
      this.detalle.proceso = (!this.detalle.proceso ? "S" : this.detalle.proceso);
      
      this.detalle.linea = (this.detalle.linea == 0 ? "S" : this.detalle.linea);
      this.detalle.maquina = (this.detalle.maquina == 0 ? "S" : this.detalle.maquina);
      this.detalle.area = (this.detalle.area == 0 ? "S" : this.detalle.area);
      this.detalle.falla = (this.detalle.falla == 0 ? "S" : this.detalle.falla);
      this.detalle.proceso = (this.detalle.proceso == 0 ? "S" : this.detalle.proceso);
      if (this.detalle.linea == "S")
      {
        this.detalle.maquina = "S";
      }

      this.detalle.tiempo0 = (!this.detalle.tiempo0 ? "0" : this.detalle.tiempo0);
      this.detalle.acumular_veces = (!this.detalle.acumular_veces ? "0" : this.detalle.acumular_veces);
      this.detalle.acumular_tiempo = (!this.detalle.acumular_tiempo ? "0" : this.detalle.acumular_tiempo);
      this.detalle.transcurrido = (!this.detalle.transcurrido ? "0" : this.detalle.transcurrido);
      this.detalle.lista = (!this.detalle.lista ? "0" : this.detalle.lista);
      this.detalle.tiempo1 = (!this.detalle.tiempo1 ? "0" : this.detalle.tiempo1);
      this.detalle.lista1 = (!this.detalle.lista1 ? "0" : this.detalle.lista1);
      this.detalle.veces1 = (!this.detalle.veces1 ? "0" : this.detalle.veces1);
      this.detalle.tiempo2 = (!this.detalle.tiempo2 ? "0" : this.detalle.tiempo2);
      this.detalle.lista2 = (!this.detalle.lista2 ? "0" : this.detalle.lista2);
      this.detalle.veces2 = (!this.detalle.veces2 ? "0" : this.detalle.veces2);
      this.detalle.tiempo3 = (!this.detalle.tiempo3 ? "0" : this.detalle.tiempo3);
      this.detalle.lista3 = (!this.detalle.lista3 ? "0" : this.detalle.lista3);
      this.detalle.veces3 = (!this.detalle.veces3 ? "0" : this.detalle.veces3);
      this.detalle.tiempo4 = (!this.detalle.tiempo4 ? "0" : this.detalle.tiempo4);
      this.detalle.lista4 = (!this.detalle.lista4 ? "0" : this.detalle.lista4);
      this.detalle.veces4 = (!this.detalle.veces4 ? "0" : this.detalle.veces4);
      this.detalle.tiempo5 = (!this.detalle.tiempo5 ? "0" : this.detalle.tiempo5);
      this.detalle.lista5 = (!this.detalle.lista5 ? "0" : this.detalle.lista5);
      this.detalle.veces5 = (!this.detalle.veces5 ? "0" : this.detalle.veces5);
      this.detalle.repetir_veces = (!this.detalle.repetir_veces ? "0" : this.detalle.repetir_veces);
      this.detalle.repetir_veces = (!this.detalle.repetir_veces ? "0" : this.detalle.repetir_veces);
      this.detalle.repetir_tiempo = (!this.detalle.repetir_tiempo ? "0" : this.detalle.repetir_tiempo);
      this.nLapso = (!this.nLapso ? "0" : this.nLapso);
    }
    if (this.miSeleccion != 10 && this.miSeleccion < 17 || this.miSeleccion == 25 || this.miSeleccion >= 29)
    {
      if (!this.detalle.nombre)
      {
          errores = errores + 1;
          this.error01 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar el Nombre/Descripción del registro";      
      }
      else if (this.detalle.nombre.length == 0)
      {
          errores = errores + 1;
          this.error01 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar el Nombre/Descripción del registro";      
      }
    }
    else if (this.miSeleccion == 10)
    {
      if (!this.detalle.literal)
      {
          errores = errores + 1;
          this.error01 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar el literal a traducir";      
      }
      else if (this.detalle.literal.length == 0)
      {
          errores = errores + 1;
          this.error01 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar el literal a traducir";      
      }
      if (!this.detalle.traduccion)
      {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar la traducción";      
      }
      else if (this.detalle.traduccion.length == 0)
      {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Falta especificar la traducción";      
      }
    }
    if (!this.detalle.telefonos && !this.detalle.correos && !this.detalle.mmcall && this.miSeleccion == 6)
    {
        errores = errores + 1;
        this.error02 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para el recipiente";      
    }
    if (this.miSeleccion == 7)
    {
      if (!this.detalle.para)
      {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") El reporte debe tener al menos un correo a quien enviar";      
      }
      if (this.nExtraccion <= "6" && this.nLapso == "0")
      {
        errores = errores + 1;
        this.error04 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique los períodos a considerar";      
      }
      if (this.listaListad.selectedOptions.selected.length == 0)
      {
        errores = errores + 1;
        this.error03 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un reporte";      
      }
      else if (this.listaListad.selectedOptions.selected.length > 10)
      {
        errores = errores + 1;
        this.error05 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") No es posible agregar más de 10 reportes a un reporte de correo";      
      }
    }
    if (this.miSeleccion == 12)
    {
      if (!this.detalle.referencia)
      {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Indique el perfil para el inicio de sesión";      
      }
      if (this.lista4.selectedOptions.selected.length==0)
      {
          errores = errores + 1;
          this.error10 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") El usuario debe tener al menos una opción/funcionalidad";      
      }
    }
    if (this.miSeleccion == 8)
    {
      if (this.detalle.transcurrido == 0)
      {
          if (this.detalle.evento != 301 && this.detalle.evento<305 && this.detalle.evento>307 )
          {
            errores = errores + 1;
            this.error03 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para generar la alerta";      
          }
          
      }
      if (this.detalle.tiempo0 == 0)
      {
          if (this.detalle.evento >= 305 && this.detalle.evento<=307 )
          {
            errores = errores + 1;
            this.error36 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para generar la alerta anticipada";      
          }
          
      }
      if (this.detalle.acumular == 'S' && this.detalle.acumular_veces == 0)
      {
          errores = errores + 1;
          this.error04 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el número de veces que se debe acumular la alerta para generar la alarma";      
      }
      if (this.seleccionMensaje.length == 0)
      {
          errores = errores + 1;
          this.error20 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para la alerta";      
      }
      if (this.detalle.lista == 0)
      {
          errores = errores + 1;
          this.error30 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el recipiente";      
      }
      if (this.detalle.repetir != "N" && this.detalle.repetir_tiempo == 0)
      {
          errores = errores + 1;
          this.error05 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para la repetición";      
      }
      if (this.detalle.escalar1 != "N")
      {
        if (this.detalle.tiempo1 == 0)
        {
            errores = errores + 1;
            this.error06 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para el escalamiento";      
        }
        if (this.seleccionescalar1.length == 0)
        {
            errores = errores + 1;
            this.error21 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para el escalamiento";      
        }
        if (this.detalle.lista1 == 0)
        {
            errores = errores + 1;
            this.error31 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el recipiente para el escalamiento";      
        }
      }
      if (this.detalle.escalar2 != "N")
      {
        if (this.detalle.tiempo2 == 0)
        {
            errores = errores + 1;
            this.error07 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para el escalamiento";      
        }
        if (this.seleccionescalar2.length == 0)
        {
            errores = errores + 1;
            this.error22 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para el escalamiento";      
        }
        if (this.detalle.lista2 == 0)
        {
            errores = errores + 1;
            this.error32 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el recipiente para el escalamiento";      
        }
      }
      if (this.detalle.escalar3 != "N")
      {
        if (this.detalle.tiempo3 == 0)
        {
            errores = errores + 1;
            this.error08 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para el escalamiento";      
        }
        if (this.seleccionescalar3.length == 0)
        {
            errores = errores + 1;
            this.error23 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para el escalamiento";      
        }
        if (this.detalle.lista3 == 0)
        {
            errores = errores + 1;
            this.error33 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el recipiente para el escalamiento";      
        }
      }
      if (this.detalle.escalar4 != "N")
      {
        if (this.detalle.tiempo4 == 0)
        {
            errores = errores + 1;
            this.error09 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para el escalamiento";      
        }
        if (this.seleccionescalar4.length == 0)
        {
            errores = errores + 1;
            this.error24 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para el escalamiento";      
        }
        if (this.detalle.lista4 == 0)
        {
            errores = errores + 1;
            this.error34 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el recipiente para el escalamiento";      
        }
      }
      if (this.detalle.escalar5 != "N")
      {
        if (this.detalle.tiempo5 == 0)
        {
            errores = errores + 1;
            this.error10 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tiempo de espera para el escalamiento";      
        }
        if (this.seleccionescalar5.length == 0)
        {
            errores = errores + 1;
            this.error25 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal de salida para el escalamiento";      
        }
        if (this.detalle.lista5 == 0)
        {
            errores = errores + 1;
            this.error35 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el recipiente para el escalamiento";      
        }
      }
    }
    if (this.miSeleccion == 6)
    {
      this.detalle.hora_desde = !this.detalle.hora_desde ? "00:00:00" : this.detalle.hora_desde;
      this.detalle.hora_hasta = !this.detalle.hora_hasta ? "23:59:59" : this.detalle.hora_hasta;
      
      if (this.detalle.nombre.telefonos == 0 && this.detalle.nombre.mmcall == 0 && this.detalle.nombre.correos == 0)
      {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un canal para el recipiente";      
      }
      if (this.detalle.hora_desde && this.detalle.hora_hasta) 
      {
        if (this.detalle.hora_desde > this.detalle.hora_hasta)
        {
          errores = errores + 1;
          this.error03 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La hora inicial no puede ser mayor a la hora final";      
        }
      }
    }
    else if (this.miSeleccion == 14)
    {
      if (this.detalle.vence=="S")
      {
        if (this.detalle.diasvencimiento==0)
        {   
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique los días de vencimiento";      
        }
        else if (!this.detalle.diasvencimiento)
        {   
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique los días de vencimiento";      
        }
      }
    }
    else if (this.miSeleccion == 17)
    {
      this.detalle.piezas = (!this.detalle.piezas ? "0" : this.detalle.piezas);
      if (this.detalle.equipo==-1)
      {   
        errores = errores + 1;
        this.error03 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la Máquina asociada";      
      }
      if (this.vista17==0)
      {
        if (this.detalle.parte==-1)
        {   
          errores = errores + 1;
          this.error04 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Número de parte asociado";      
        }
      }
      else if (this.lista3.selectedOptions.selected.length == 0 && this.detalle.parte != "S")
      {
        errores = errores + 1;
        this.error04 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos un número de parte asociado al rate";      
      }
      if (this.detalle.piezas==0)
      {   
        errores = errores + 1;
        this.error02 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el número de piezas que se espera producir";      
      }
    }
    else if (this.miSeleccion == 18)
    {
      this.detalle.objetivo = !this.detalle.objetivo ? "0" : this.detalle.objetivo < 0 ? "0" : this.detalle.objetivo > 99999999999999 ? "99999999999999" : this.detalle.objetivo;
      if (this.detalle.equipo==-1)
      {   
        errores = errores + 1;
        this.error03 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la Máquina asociada";      
      }
      if (this.detalle.parte==-1)
      {   
        errores = errores + 1;
        this.error04 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Número de parte asociado";      
      }
      if (this.detalle.lote==-1)
      {   
        errores = errores + 1;
        this.error05 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Lote o Número de Orden de producción asociada";      
      }
      if (this.detalle.turno==-1)
      {   
        errores = errores + 1;
        this.error06 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Turno de producción asociado";      
      }
      if (this.detalle.fijo == "N")
      {
        if (!this.detalle.desde) 
        {
          errores = errores + 1;
            this.error07 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha de inicio no está permitida";      
        }

        if (!this.detalle.hasta) 
        {
          errores = errores + 1;
            this.error08 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha de fin no está permitida";      
        }

        if (this.detalle.desde && this.detalle.hasta) 
        {
          if (this.detalle.desde > this.detalle.hasta)
          {
            errores = errores + 1;
            this.error07 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha inicial no puede ser mayor a la final";      
          }
        }
      }
    }
    else if (this.miSeleccion == 19)
    {
      this.detalle.oee = (!this.detalle.oee ? "0" : this.detalle.oee);
      this.detalle.ftq = (!this.detalle.ftq ? "0" : this.detalle.ftq);
      this.detalle.efi = (!this.detalle.efi ? "0" : this.detalle.efi);
      this.detalle.dis = (!this.detalle.dis ? "0" : this.detalle.dis);
      if (this.detalle.linea==-1)
      {   
        errores = errores + 1;
        this.error03 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la linea asociada";      
      }
      if (this.detalle.equipo==-1)
      {   
        errores = errores + 1;
        this.error04 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la Máquina asociada";      
      }
      if (this.detalle.fijo == "N")
      {
        if (!this.detalle.desde) 
        {
          errores = errores + 1;
            this.error07 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha de inicio no está permitida";      
        }

        if (!this.detalle.hasta) 
        {
          errores = errores + 1;
            this.error08 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha de fin no está permitida";      
        }

        if (this.detalle.desde && this.detalle.hasta) 
        {
          if (this.detalle.desde > this.detalle.hasta)
          {
            errores = errores + 1;
            this.error07 = true;
            this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La fecha inicial no puede ser mayor a la final";      
          }
        }
      }
    }
    else if (this.miSeleccion == 20)
    {
      this.detalle.multiplicador = !this.detalle.multiplicador ? "1" : this.detalle.multiplicador <= 0 ? "1" : this.detalle.multiplicador > 99999999999999999999 ? 99999999999999999999 : this.detalle.multiplicador;
      this.detalle.base = !this.detalle.base ? "0" : this.detalle.base < 0 ? "0" : this.detalle.base > 99999999999999999999 ? 99999999999999999999 : this.detalle.base;
      this.detalle.sensor = !this.detalle.sensor ? "" : this.detalle.sensor;
      this.detalle.area = !this.detalle.area ? "0" : this.detalle.area;
      this.detalle.clasificacion = !this.detalle.clasificacion ? "0" : this.detalle.clasificacion;
      if (this.detalle.equipo==-1)
      {   
        errores = errores + 1;
        this.error04 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la Máquina asociada";      
      }
      if (this.detalle.sensor=="")
      {   
        errores = errores + 1;
        this.error02 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el ID del sensor";      
      }
    }
    else if (this.miSeleccion == 21)
    {
      this.detalle.desde = !this.detalle.desde ? this.servicio.fecha(1, "", "HH:mm:ss") : this.detalle.desde;
      this.detalle.hasta = !this.detalle.hasta ? "23:59:59" : this.detalle.hasta;
      //this.detalle.hora_inicial = !this.detalle.hora_inicial ? "00:00:00" : this.detalle.hora_inicial;
      //this.detalle.hora_final = !this.detalle.hora_final ? "00:59:59" : this.detalle.hora_final;
      this.detalle.fdesde = !this.detalle.fdesde ? new Date() : this.detalle.fdesde;
      this.detalle.fhasta = !this.detalle.fhasta ? new Date() : this.detalle.fhasta;
      this.detalle.paro = !this.detalle.paro ? "" : this.detalle.paro;
      this.detalle.maquina = !this.detalle.maquina ? "0" : this.detalle.maquina;
      this.detalle.area = !this.detalle.area ? "0" : this.detalle.area;
      this.detalle.tipo = !this.detalle.tipo ? "0" : this.detalle.tipo;
      if (this.detalle.paro=="")
      {   
        errores = errores + 1;
        this.error01 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el nombre del paro";      
      }
      if (this.detalle.tipo==0 && this.detalle.clase ==0 && this.detalle.estado >="L")
      {   
        errores = errores + 1;
        this.error07 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el concepto del paro";      
      }
      if (this.detalle.maquina==0 && this.detalle.clase ==0 && this.detalle.estado >="L")
      {   
        errores = errores + 1;
        this.error02 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Máquina/Equipo asociado al paro";      
      }
      if (this.detalle.area==0 || !this.detalle.area)
      {   
        errores = errores + 1;
        this.error03 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el área asociada";      
      }
      if (this.detalle.clase ==0 && this.detalle.estado >="L")
      {
        if (new Date(this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde) > new Date(this.servicio.fecha(2, this.detalle.fhasta, "yyyy/MM/dd") + " " + this.detalle.hasta)) 
        {
          errores = errores + 1;
          this.error04 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") La hora inicial no puede ser mayor a la hora final";      
        }
        if (new Date(this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde) < new Date())
        {
          errores = errores + 1;
          this.error05 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") El paro debe planearse para una fecha posterior a la actual";      
        }
      }
      
    }
    else if (this.miSeleccion == 27)
    {
      //this.detalle.fecha = !this.detalle.fecha ? this.servicio.fecha(1, "", "dd/MM/yyyy") : this.detalle.fecha;
      this.detalle.rechazo = !this.detalle.rechazo ? "" : this.detalle.rechazo;
      this.detalle.equipo = !this.detalle.equipo ? "0" : this.detalle.equipo;
      this.detalle.area = !this.detalle.area ? "0" : this.detalle.area;
      this.detalle.turno = !this.detalle.turno ? "0" : this.detalle.turno;
      this.detalle.parte = !this.detalle.parte ? "0" : this.detalle.parte;
      this.detalle.lote = !this.detalle.lote ? "0" : this.detalle.lote;
      this.detalle.orden = !this.detalle.orden ? "" : this.detalle.orden;
      this.detalle.tipo = !this.detalle.tipo ? "0" : this.detalle.tipo;
      this.detalle.cantidad = !this.detalle.cantidad ? 0 : this.detalle.cantidad;
      if (this.detalle.rechazo=="")
      {   
        errores = errores + 1;
        this.error01 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el detalle del rechazo";      
      }
      if (this.detalle.area == 0)
      {   
        errores = errores + 1;
        this.error03 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el área asociada al rechazo";      
      }
      if (this.detalle.tipo == 0)
      {   
        errores = errores + 1;
        this.error07 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el tipo de asociado al rechazo";      
      }
      if (this.detalle.equipo == 0)
      {   
        errores = errores + 1;
        this.error02 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Máquina/Equipo asociado al rechazo";      
      }
      
      if (this.detalle.parte == 0)
      {   
        errores = errores + 1;
        this.error04 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Número de parte asociado al rechazo";      
      }

      if (this.detalle.orden == "")
      {   
        errores = errores + 1;
        this.error08 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el Número de parte asociado al rechazo";      
      }
      if (!this.detalle.fecha)
      {   
        errores = errores + 1;
        this.error09 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la fecha asociada al rechazo";      
      }
      if (this.detalle.turno == 0)
      {   
        errores = errores + 1;
        this.error05 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique el turno asociado al rechazo";      
      }
      
      if (this.detalle.cantidad == 0)
      {   
        errores = errores + 1;
        this.error06 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique la cantidad  rechazada";      
      }
      if (!this.cantidadValidada && errores == 0)
      { 
        this.validarCantidad();
        return;      
        
      } 
      
    }
    else if (this.miSeleccion == 29)
    {
      let haySeleccion = false;
      for (var i = 0; i < this.opcionesSel.length; i++) 
      {
        haySeleccion = this.opcionesSel[i].seleccionado;
        if (haySeleccion)
        {
          break;
        }
      }
      if (!haySeleccion)
      {
        errores = errores + 1;
        this.error02 = true;
        this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Especifique al menos una variable para el checklist";
      }
    }
    else if (this.miSeleccion == 30)
    {
      if (this.detalle.checklists != "S")
      {
        let hayUno = false;
        if (!this.lista2.selectedOptions.selected)
        {
          errores = errores + 1;
          this.error02 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Seleccione al menos un checklist";
        }
      }
      if (this.detalle.frecuencia == 1)
      {
        let laFecha = new Date(this.detalle.fdesde + " " + this.detalle.desde);
      
        if (!this.detalle.desde || !this.detalle.fdesde)
        {
          errores = errores + 1;
          this.error04 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Indique una fecha correcta";
        }  
        else if (new Date(this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde) < new Date())
        {
          errores = errores + 1;
          this.error05 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Indique una fecha posterior a la actual"; 
        }
      }
      if (this.detalle.frecuencia != 0 && this.detalle.frecuencia != 1)
      {
        if (!this.detalle.hora)
        {
          errores = errores + 1;
          this.error06 = true;
          this.faltaMensaje = this.faltaMensaje + "<br>" + errores + ") Indique la hora planificada";
        }  
      }
    }
    
    if (errores > 0)
    {
      this.faltaMensaje = "<strong>No se ha guardado el registro por el siguiente mensaje:</strong> " + this.faltaMensaje
      setTimeout(() => {
        if (this.error01 && (this.miSeleccion==27 || this.miSeleccion==21))
        {
          this.txtNombre.nativeElement.focus();
        }
        else if (this.error03 && this.miSeleccion==27)
        {
          this.lstC1.focus();
        }
        else if (this.error07 && this.miSeleccion==27)
        {
          this.lstC5.focus();
        }
        else if (this.error08 && this.miSeleccion==27)
        {
          this.txtT2.nativeElement.focus();
        }
        else if (this.error02 && this.miSeleccion==27)
        {
          this.lstC2.focus();
        }
        else if (this.error02 && this.miSeleccion==29)
        {
          this.lstC5.focus();
        }
        else if (this.error04 && this.miSeleccion==27)
        {
          this.lstC3.focus();
        }
        else if (this.error09 && this.miSeleccion==27)
        {
          this.lstC6.focus();
        }
        else if (this.error05 && this.miSeleccion==27)
        {
          this.lstC4.focus();
        }
        else if (this.error02 && this.miSeleccion==27)
        {
          this.lstC2.focus();
        }
        else if (this.error06 && this.miSeleccion==27)
        {
          this.txtT1.nativeElement.focus();
        }
        else if (this.error07 && this.miSeleccion==21)
        {
          this.lstC4.focus();
        }
        else if (this.error02 && this.miSeleccion==21)
        {
          this.lstC3.focus();
        }
        else if (this.error03 && this.miSeleccion==21)
        {
          this.lstC2.focus();
        }
       
        
        else if (this.error04 && this.miSeleccion == 21)
        {
          this.txtT5.nativeElement.focus();
        }
        else if (this.error05 && this.miSeleccion == 21)
        {
          this.txtT5.nativeElement.focus();
        }
        else if (this.error01)
        {
          this.txtNombre.nativeElement.focus();
        }
        
        else if (this.error02 && this.miSeleccion==17 && this.vista17==1)
        {
          this.txtT1.nativeElement.focus();
        } 
        else if (this.error02 && this.miSeleccion==30)
        {
          this.lstC0.focus();
        }
        else if ((this.error04 || this.error05) && this.miSeleccion==30)
        {
          if (!this.detalle.fdesde)
          {
            this.txtT5.nativeElement.focus();
          }
          else if (!this.detalle.desde)
          {
            this.txtT6.nativeElement.focus();
          }
          else
          {
            this.txtT5.nativeElement.focus();
          }
        }
        else if (this.error06 && this.miSeleccion==30)
        {
          this.txtT7.nativeElement.focus();
        }
        else if (this.error03 && this.miSeleccion>=17)
        {
          this.lstC0.focus();
        }
        else if (this.error04 && this.miSeleccion>=17)
        {
          this.lstC1.focus();
        }
        else if (this.error05 && this.miSeleccion==18)
        {
          this.lstC2.focus();
        }
        else if (this.error06 && this.miSeleccion==18)
        {
          this.lstC3.focus();
        }
        else if (this.error02 && (this.miSeleccion==12 || this.miSeleccion==17 || this.miSeleccion==18 || this.miSeleccion==20))
        {
          this.txtT1.nativeElement.focus();
        }        
        else if (this.error02 && this.miSeleccion==10)
        {
          this.txtTelefonos.nativeElement.focus();
        }
        else if (this.error02 && this.miSeleccion==14)
        {
          this.txtT1.nativeElement.focus();
        }
        
        else if (this.error02)
        {
          this.txtTelefonos.nativeElement.focus();
        }
        else if (this.error03 && this.miSeleccion == 8)
        {
          this.txtT1.nativeElement.focus();
        }
        else if (this.error36 && this.miSeleccion == 8)
        {
          this.txtT1.nativeElement.focus();
        }
        else if (this.error03 && this.miSeleccion == 6)
        {
          this.txtT1.nativeElement.focus();
        }
        else if (this.error03 && this.miSeleccion == 7)
        {
          this.listaListad.focus();
        }
        else if (this.error04 && this.miSeleccion == 7)
        {
          this.txtT1.nativeElement.focus();
        }
        else if (this.error10 && this.miSeleccion == 12)
        {
          const respuesta = this.dialogo.open(DialogoComponent, {
            width: "460px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "El usuario no tiene ninguna opción o funcionalidad. Por favor agregue al menos una opción al usuario", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_grupos" }
          });
          
          this.lista4.focus();
        }
        else if (this.error04)
        {
          this.txtT2.nativeElement.focus();
        }
        else if (this.error20)
        {
          this.lstC0.focus();
        }
        else if (this.error30)
        {
          this.lstC10.focus();
        }
        else if (this.error05)
        {
          this.txtT3.nativeElement.focus();
        }
        else if (this.error06)
        {
          this.txtT4.nativeElement.focus();
        }
        else if (this.error21)
        {
          this.lstC1.focus();
        }
        else if (this.error31)
        {
          this.lstC11.focus();
        }
        else if (this.error07)
        {
          this.txtT5.nativeElement.focus();
        }
        else if (this.error22)
        {
          this.lstC2.focus();
        }
        else if (this.error32)
        {
          this.lstC12.focus();
        }
        else if (this.error08)
        {
          this.txtT6.nativeElement.focus();
        }
        else if (this.error23)
        {
          this.lstC3.focus();
        }
        else if (this.error33)
        {
          this.lstC13.focus();
        }
        else if (this.error09)
        {
          this.txtT7.nativeElement.focus();
        }
        else if (this.error24)
        {
          this.lstC4.focus();
        }
        else if (this.error34)
        {
          this.lstC14.focus();
        }
        else if (this.error10)
        {
          this.txtT8.nativeElement.focus();
        }
        else if (this.error25)
        {
          this.lstC5.focus();
        }
        else if (this.error35)
        {
          this.lstC15.focus();
        }
        this.bot3 = true;
        
      }, 300);
      return;
    }
    this.validarUSER = false;
    this.validarCU = false;
    this.validarM = false;
    this.editando = false;
    this.faltaMensaje = "";
    this.detalle.imagen = !this.detalle.imagen ? "" : this.detalle.imagen;
    this.detalle.url_mmcall = !this.detalle.url_mmcall ? "" : this.detalle.url_mmcall;
    this.detalle.referencia = !this.detalle.referencia ? "" : this.detalle.referencia;
    this.detalle.notas = !this.detalle.notas ? "" : this.detalle.notas; 
    this.detalle.agrupador_1 = !this.detalle.agrupador_1 ? "0" : this.detalle.agrupador_1; 
    this.detalle.agrupador_2 = !this.detalle.agrupador_2 ? "0" : this.detalle.agrupador_2; 
    this.detalle.tipo = !this.detalle.tipo ? "0" : this.detalle.tipo; 
    this.detalle.linea = !this.detalle.linea ? "0" : this.detalle.linea; 
    this.detalle.maquina = !this.detalle.maquina ? "0" : this.detalle.maquina; 
    this.detalle.area = !this.detalle.area ? "0" : this.detalle.area; 
    this.detalle.disponibilidad = !this.detalle.disponibilidad ? "0" : this.detalle.disponibilidad; 
    this.detalle.extraccion = this.nExtraccion + ";" + this.nLapso + ";" + this.nFrecuencia + ";" + this.nHorario 
    let sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_lineas (disponibilidad, nombre, referencia, notas, url_mmcall, imagen, creado, modificado, creacion, modificacion, agrupador_1, agrupador_2) VALUES (" + +this.detalle.disponibilidad + ", '" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.notas + "', '" + this.detalle.url_mmcall + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + this.detalle.agrupador_1 + ", "  + this.detalle.agrupador_2 + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET lineas = NOW();"
    if (this.detalle.id > 0)
    {
      sentencia = "UPDATE " + this.servicio.rBD() + ".cat_lineas SET disponibilidad = " + +this.detalle.disponibilidad + ", nombre = '" + this.detalle.nombre + "', estatus = '" + this.detalle.estatus + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', url_mmcall = '" + this.detalle.url_mmcall + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), agrupador_1 = " + this.detalle.agrupador_1 + ", agrupador_2 = " + this.detalle.agrupador_2 + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET lineas = NOW();";
    }
    if (this.miSeleccion == 2)
    {
      this.detalle.linea = !this.detalle.linea ? "0" : this.detalle.linea; 
      this.detalle.id_mapa = !this.detalle.id_mapa ? "0" : this.detalle.id_mapa; 
      this.detalle.id_mapa2 = !this.detalle.id_mapa2 ? "0" : this.detalle.id_mapa2; 
      this.detalle.id_mapa3 = !this.detalle.id_mapa3 ? "0" : this.detalle.id_mapa3; 
      this.detalle.paro_wip = !this.detalle.paro_wip ? "N" : this.detalle.paro_wip;

      this.detalle.confirmar_reparacion = !this.detalle.confirmar_reparacion ? "N" : this.detalle.confirmar_reparacion
      this.detalle.oee_historico_rate_reiniciar = !this.detalle.oee_historico_rate_reiniciar ? "1" : this.detalle.oee_historico_rate_reiniciar;
      this.detalle.oee_umbral_produccion = !this.detalle.oee_umbral_produccion ? "0" : this.detalle.oee_umbral_produccion; 
      this.detalle.oee_umbral_alerta = !this.detalle.oee_umbral_alerta ? "0" : this.detalle.oee_umbral_alerta; 
      this.detalle.id_mmcall = !this.detalle.id_mmcall ? "" : this.detalle.id_mmcall == "null" ? "" : this.detalle.id_mmcall;
      this.detalle.id_mmcall; 
      this.detalle.tipo_andon = !this.detalle.tipo_andon ? 0 : this.detalle.tipo_andon;
      this.detalle.oee_historico_rate = !this.detalle.oee_historico_rate ? 0 : this.detalle.oee_historico_rate;
      this.detalle.activar_buffer = !this.detalle.activar_buffer ? "N" : this.detalle.activar_buffer
      this.detalle.usuario = !this.detalle.usuario ? 0 : this.detalle.usuario;
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_maquinas (disponibilidad, nombre, referencia, notas, url_mmcall, imagen, creado, modificado, creacion, modificacion, linea, agrupador_1, agrupador_2, tipo, oee, oee_umbral_alerta, id_mapa, id_mapa2, id_mapa3, oee_umbral_produccion, oee_historico_rate, oee_historico_rate_reiniciar, confirmar_reparacion, id_mmcall, usuario, tipo_andon, activar_buffer, paro_wip) VALUES (" + +this.detalle.disponibilidad + ", '" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.notas + "', '" + this.detalle.url_mmcall + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + +this.detalle.linea + ", " + this.detalle.agrupador_1 + ", "  + this.detalle.agrupador_2  + ", "  + this.detalle.tipo + ", '" + this.detalle.oee + "', " + this.detalle.oee_umbral_alerta + ", " + this.detalle.id_mapa + ", " + this.detalle.id_mapa2 + ", " + this.detalle.id_mapa3 + ", " + this.detalle.oee_umbral_produccion + ", " + this.detalle.oee_historico_rate + ", '" + this.detalle.oee_historico_rate_reiniciar + "', '" + this.detalle.confirmar_reparacion + "', '" + this.detalle.id_mmcall + "', " + this.detalle.usuario + ", " + this.detalle.tipo_andon + ", '" + this.detalle.activar_buffer + "', '" + this.detalle.paro_wip + "');UPDATE " + this.servicio.rBD() + ".actualizaciones SET maquinas = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_maquinas SET oee_umbral_alerta = " + this.detalle.oee_umbral_alerta + ", confirmar_reparacion = '" + this.detalle.confirmar_reparacion + "', oee_umbral_produccion = " + this.detalle.oee_umbral_produccion + ", id_mapa = " + this.detalle.id_mapa + ", id_mapa2 = " + this.detalle.id_mapa2 + ", id_mapa3 = " + this.detalle.id_mapa3 + ", oee_historico_rate = " + this.detalle.oee_historico_rate + ", oee_historico_rate_reiniciar = '" + this.detalle.oee_historico_rate_reiniciar + "', oee = '" + this.detalle.oee + "', disponibilidad = " + +this.detalle.disponibilidad + ", nombre = '" + this.detalle.nombre + "', estatus = '" + this.detalle.estatus + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', url_mmcall = '" + this.detalle.url_mmcall + "', id_mmcall = '" + this.detalle.id_mmcall + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), linea = " + +this.detalle.linea + ", agrupador_1 = " + this.detalle.agrupador_1 + ", agrupador_2 = " + this.detalle.agrupador_2 + ", tipo = " + this.detalle.tipo + ", usuario = " + this.detalle.usuario + ", tipo_andon = " + +this.detalle.tipo_andon + ", activar_buffer = '" + this.detalle.activar_buffer + "', paro_wip = '" + this.detalle.paro_wip + "' WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET maquinas = NOW();";
      }
    }
    else if (this.miSeleccion == 3)
    {
      let audios_ruta = ""
      if (this.detalle.audios_ruta)
      {
        audios_ruta = this.detalle.audios_ruta.replace(/\\/g, '/')
      }
      let audios_prefijo = ""
      if (this.detalle.audios_prefijo)
      {
        audios_prefijo = this.detalle.audios_prefijo.replace(/\\/g, '/')
      }
      this.detalle.recipiente = !this.detalle.recipiente ? 0 : this.detalle.recipiente;
      this.detalle.audios_activar = !this.detalle.audios_activar ? "N" : this.detalle.audios_activar;
      this.detalle.audios_general = !this.detalle.audios_general ? "N" : this.detalle.audios_general;
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_areas (nombre, audios_ruta, audios_activar, audios_prefijo, audios_general, referencia, notas, url_mmcall, imagen, creado, modificado, creacion, modificacion, agrupador_1, agrupador_2, id_mmcall, recipiente) VALUES ('" + this.detalle.nombre + "', '" + audios_ruta + "', '" + this.detalle.audios_activar + "', '" + audios_prefijo + "', '" + this.detalle.audios_general + "', '" + this.detalle.referencia + "', '" + this.detalle.notas + "', '" + this.detalle.url_mmcall + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + this.detalle.agrupador_1 + ", "  + this.detalle.agrupador_2 + ", '"  + this.detalle.id_mmcall + "', " + this.detalle.recipiente + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET areas = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_areas SET nombre = '" + this.detalle.nombre + "', audios_ruta = '" + audios_ruta + "', audios_activar = '" + this.detalle.audios_activar + "', audios_prefijo = '" + audios_prefijo + "', audios_general = '" + this.detalle.audios_general + "', estatus = '" + this.detalle.estatus + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', url_mmcall = '" + this.detalle.url_mmcall + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), agrupador_1 = " + this.detalle.agrupador_1 + ", agrupador_2 = " + this.detalle.agrupador_2 + ", id_mmcall = '" + this.detalle.id_mmcall + "', recipiente = " + this.detalle.recipiente + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET areas = NOW();";
      }
    }
    else if (this.miSeleccion == 28)
    {
      this.detalle.van = !this.detalle.van ? 0 : this.detalle.van;
      this.detalle.tope = !this.detalle.tope ? 0 : this.detalle.tope;
      this.detalle.reiniciar_en = !this.detalle.reiniciar_en ? 0 : this.detalle.reiniciar_en;
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_variables (nombre, referencia, prefijo, notas, url_mmcall, imagen, creado, modificado, creacion, modificacion, tipo, unidad, recipiente, tipo_valor, alarma_binaria, minimo, maximo, acumular, requerida, maquinas, van, tope, acumular, reiniciar, sensor) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.prefijo + "', '" + this.detalle.notas + "', '" + this.detalle.url_mmcall + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + this.detalle.tipo + ", "  + this.detalle.unidad + ", " + this.detalle.recipiente + ", " + +this.detalle.tipo_valor + ", " + +this.detalle.alarma_binaria + ", " + +this.detalle.minimo + ", " + +this.detalle.maximo + ", '" + this.detalle.acumular + "', '" + this.detalle.requerida + "', '" + this.detalle.maquinas + "', " + this.detalle.van + ", " + this.detalle.tope + ", '" + this.detalle.acumular + "', '" + this.detalle.reiniciar + "', " + this.detalle.reiniciar_en + ", " + this.detalle.sensor + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET variables = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_variables SET nombre = '" + this.detalle.nombre + "', estatus = '" + this.detalle.estatus + "', prefijo = '" + this.detalle.prefijo + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', url_mmcall = '" + this.detalle.url_mmcall + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), tipo = " + this.detalle.tipo + ", unidad = " + this.detalle.unidad + ", tipo_valor = " + this.detalle.tipo_valor + ", alarma_binaria = " + this.detalle.alarma_binaria + ", minimo = " + this.detalle.minimo + ", maximo = " + this.detalle.maximo + ", por_defecto = '" + this.detalle.por_defecto + "', acumular = '" + this.detalle.acumular + "', requerida = '" + this.detalle.requerida + "', maquinas = '" + this.detalle.maquinas + "', van = " + this.detalle.van + ", tope = " + this.detalle.tope + ", reiniciar = '" + this.detalle.reiniciar + "', reiniciar_en = " + this.detalle.reiniciar_en + ", recipiente = " + this.detalle.recipiente + ",sensor = " + this.detalle.sensor + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET variables = NOW();";
      }
    }
    else if (this.miSeleccion == 29)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_checklists (nombre, referencia, notas, url_mmcall, imagen, creado, modificado, creacion, modificacion, tipo, equipo, departamento, tiempo, recipiente) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.notas + "', '" + this.detalle.url_mmcall + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + this.detalle.tipo + ", "  + this.detalle.equipo + ", "  + this.detalle.departamento + ", " + +this.detalle.tiempo + ", "  + +this.detalle.recipiente + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET checklists = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_checklists SET nombre = '" + this.detalle.nombre + "', estatus = '" + this.detalle.estatus + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', url_mmcall = '" + this.detalle.url_mmcall + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), tipo = " + this.detalle.tipo + ", equipo = " + this.detalle.equipo + ", departamento = " + this.detalle.departamento + ", tiempo = " + this.detalle.tiempo + ", recipiente = " + this.detalle.recipiente + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET checklists = NOW();";
      }
    }
    
    else if (this.miSeleccion == 4)
    {
      if (this.detalle.linea == "S")
      {
        this.detalle.maquina = "S";
      }
      if (this.detalle.codigo == "null")
      {
        this.detalle.codigo = "";
      }
      else
      {
        this.detalle.codigo = !this.detalle.codigo ? "" : this.detalle.codigo;
      }
      this.detalle.afecta_oee = !this.detalle.afecta_oee ? "N" : this.detalle.afecta_oee;
      this.detalle.tipo = !this.detalle.tipo ? "0" : this.detalle.tipo;
      this.detalle.ruta = !this.detalle.ruta ? "0" : this.detalle.ruta; 
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_fallas (nombre, referencia, codigo, notas, url_mmcall, imagen, creado, modificado, creacion, modificacion, agrupador_1, agrupador_2, linea, maquina, area, afecta_oee) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.codigo + "', '" + this.detalle.notas + "', '" + this.detalle.url_mmcall + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + this.detalle.agrupador_1 + ", "  + this.detalle.agrupador_2 + ", '"  + this.detalle.linea + "', '"  + this.detalle.maquina + "', '"  + this.detalle.area + "', '" + this.detalle.afecta_oee + "');UPDATE " + this.servicio.rBD() + ".actualizaciones SET fallas = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_fallas SET nombre = '" + this.detalle.nombre + "', estatus = '" + this.detalle.estatus + "', codigo = '" + this.detalle.codigo + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', afecta_oee = '" + this.detalle.afecta_oee + "', url_mmcall = '" + this.detalle.url_mmcall + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), agrupador_1 = " + this.detalle.agrupador_1 + ", agrupador_2 = " + this.detalle.agrupador_2 + ", linea = '" + this.detalle.linea + "', maquina = '" + this.detalle.maquina + "', area = '" + this.detalle.area + "' WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET fallas = NOW();";
      }
    }
    else if (this.miSeleccion == 25)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_partes (nombre, referencia, notas, imagen, creado, modificado, creacion, modificacion, maquinas, tipo, ruta) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.notas + "', '" + this.detalle.imagen + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), '"  + this.detalle.maquinas + "', " + this.detalle.tipo + ", " + this.detalle.ruta + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET partes = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_partes SET nombre = '" + this.detalle.nombre + "', estatus = '" + this.detalle.estatus + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', imagen = '" + this.detalle.imagen + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), maquinas = '" + this.detalle.maquinas + "', tipo = " + this.detalle.tipo + ", ruta = " + this.detalle.ruta + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET partes = NOW();";
      }
    }
    else if (this.miSeleccion == 5)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_generales (nombre, tabla, url_mmcall, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.nombre + "', " + this.detalle.tabla + ", '" + (this.detalle.tabla == 45 && !this.detalle.url_mmcall ? "N" : this.detalle.url_mmcall) + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET generales = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_generales SET nombre = '" + this.detalle.nombre + "', url_mmcall = '" + (this.detalle.tabla == 45 && !this.detalle.url_mmcall ? "N" : this.detalle.url_mmcall) + "', tabla = " + this.detalle.tabla + ", estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET generales = NOW();";
      }
    }
    else if (this.miSeleccion == 6)
    {
      
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_distribucion (nombre, referencia, telefonos, hora_desde, hora_hasta, correos, mmcall, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.telefonos + "', '" + this.detalle.hora_desde + "', '" + this.detalle.hora_hasta + "', '" + this.detalle.correos + "', '" + this.detalle.mmcall + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET distribucion = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_distribucion SET nombre = '" + this.detalle.nombre + "', telefonos = '" + this.detalle.telefonos + "', referencia = '" + this.detalle.referencia + "', hora_desde = '" + this.detalle.hora_desde + "', hora_hasta = '" + this.detalle.hora_hasta + "', correos = '" + this.detalle.correos + "', mmcall = '" + this.detalle.mmcall + "', estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET distribucion = NOW();";
      }
    }
    else if (this.miSeleccion == 7)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_correos (nombre, para, copia, oculta, titulo, cuerpo, extraccion, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.para + "', '" + this.detalle.copia + "', '" + this.detalle.oculta + "', '" + this.detalle.titulo + "', '" + this.detalle.cuerpo + "', '" + this.detalle.extraccion + "', " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET correos = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_correos SET nombre = '" + this.detalle.nombre + "', para = '" + this.detalle.para + "', copia = '" + this.detalle.copia + "', oculta = '" + this.detalle.oculta + "', titulo = '" + this.detalle.titulo + "', cuerpo = '" + this.detalle.cuerpo + "', extraccion = '" + this.detalle.extraccion + "', estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET correos = NOW();";
      }
    }
    else if (this.miSeleccion == 8)
    {
      
      if (this.seleccionMensaje)
      {
        this.detalle.sms = this.seleccionMensaje.findIndex(c => c=="S") > -1 ? "S" : "N";
        this.detalle.mmcall = this.seleccionMensaje.findIndex(c => c=="M") > -1 ? "S" : "N";
        this.detalle.llamada = this.seleccionMensaje.findIndex(c => c=="L") > -1 ? "S" : "N";
        this.detalle.correo = this.seleccionMensaje.findIndex(c => c=="C") > -1 ? "S" : "N";
        this.detalle.log = this.seleccionMensaje.findIndex(c => c=="G") > -1 ? "S" : "N";
      }
      if (this.seleccionescalar1)
      {
        this.detalle.sms1 = this.seleccionescalar1.findIndex(c => c=="S") > -1 ? "S" : "N";
        this.detalle.mmcall1 = this.seleccionescalar1.findIndex(c => c=="M") > -1 ? "S" : "N";
        this.detalle.llamada1 = this.seleccionescalar1.findIndex(c => c=="L") > -1 ? "S" : "N";
        this.detalle.correo1 = this.seleccionescalar1.findIndex(c => c=="C") > -1 ? "S" : "N";
        this.detalle.log1 = this.seleccionescalar1.findIndex(c => c=="G") > -1 ? "S" : "N";
      }
      if (this.seleccionescalar2)
      {
        this.detalle.sms2 = this.seleccionescalar2.findIndex(c => c=="S") > -1 ? "S" : "N";
        this.detalle.mmcall2 = this.seleccionescalar2.findIndex(c => c=="M") > -1 ? "S" : "N";
        this.detalle.llamada2 = this.seleccionescalar2.findIndex(c => c=="L") > -1 ? "S" : "N";
        this.detalle.correo2 = this.seleccionescalar2.findIndex(c => c=="C") > -1 ? "S" : "N";
        this.detalle.log2 = this.seleccionescalar2.findIndex(c => c=="G") > -1 ? "S" : "N";
      }
      if (this.seleccionescalar3)
      {
        this.detalle.sms3 = this.seleccionescalar3.findIndex(c => c=="S") > -1 ? "S" : "N";
        this.detalle.mmcall3 = this.seleccionescalar3.findIndex(c => c=="M") > -1 ? "S" : "N";
        this.detalle.llamada3 = this.seleccionescalar3.findIndex(c => c=="L") > -1 ? "S" : "N";
        this.detalle.correo3 = this.seleccionescalar3.findIndex(c => c=="C") > -1 ? "S" : "N";
        this.detalle.log3 = this.seleccionescalar3.findIndex(c => c=="G") > -1 ? "S" : "N";
      }
      if (this.seleccionescalar4)
      {
        this.detalle.sms4 = this.seleccionescalar4.findIndex(c => c=="S") > -1 ? "S" : "N";
        this.detalle.mmcall4 = this.seleccionescalar4.findIndex(c => c=="M") > -1 ? "S" : "N";
        this.detalle.llamada4 = this.seleccionescalar4.findIndex(c => c=="L") > -1 ? "S" : "N";
        this.detalle.correo4 = this.seleccionescalar4.findIndex(c => c=="C") > -1 ? "S" : "N";
        this.detalle.log4 = this.seleccionescalar4.findIndex(c => c=="G") > -1 ? "S" : "N";
      }
      if (this.seleccionescalar5)
      {
        this.detalle.sms5 = this.seleccionescalar5.findIndex(c => c=="S") > -1 ? "S" : "N";
        this.detalle.mmcall5 = this.seleccionescalar5.findIndex(c => c=="M") > -1 ? "S" : "N";
        this.detalle.llamada5 = this.seleccionescalar5.findIndex(c => c=="L") > -1 ? "S" : "N";
        this.detalle.correo5 = this.seleccionescalar5.findIndex(c => c=="C") > -1 ? "S" : "N";
        this.detalle.log5 = this.seleccionescalar5.findIndex(c => c=="G") > -1 ? "S" : "N";
      }
      this.detalle.solapar = !this.detalle.solapar ? "S" : this.detalle.solapar;
      this.detalle.mensaje_mmcall = !this.detalle.mensaje_mmcall ? "" : this.detalle.mensaje_mmcall;
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_alertas (proceso, evento, referencia, nombre, solapar, tipo, notas, linea, maquina, area, falla, transcurrido, acumular, acumular_veces, acumular_tiempo, acumular_inicializar, log, sms, correo, llamada, mmcall, lista, escalar1, tiempo1, lista1, log1, sms1, correo1, llamada1, mmcall1, repetir1, veces1, escalar2, tiempo2, lista2, log2, sms2, correo2, llamada2, mmcall2, repetir2, veces2, escalar3, tiempo3, lista3, log3, sms3, correo3, llamada3, mmcall3, repetir3, veces3, escalar4, tiempo4, lista4, log4, sms4, correo4, llamada4, mmcall4, repetir4, veces4, escalar5, tiempo5, lista5, log5, sms5, correo5, llamada5, mmcall5, repetir5, veces5, repetir, repetir_tiempo, repetir_veces, informar_resolucion, resolucion_mensaje, cancelacion_mensaje, tiempo0, mensaje, titulo, mensaje_mmcall, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.proceso + "', " + this.detalle.evento + ", '" + this.detalle.referencia + "', '" + this.detalle.nombre + "', '" + this.detalle.solapar + "', " + this.detalle.tipo + ", '" + this.detalle.notas + "', '" + this.detalle.linea + "', '" + this.detalle.maquina + "', '" + this.detalle.area + "', '" + this.detalle.falla + "', " + this.detalle.transcurrido + ", '" + this.detalle.acumular + "', " + this.detalle.acumular_veces + ", " + this.detalle.acumular_tiempo + ", '" + this.detalle.acumular_inicializar + "', '" + this.detalle.log + "', '" + this.detalle.sms + "', '" + this.detalle.correo + "', '" + this.detalle.llamada + "', '" + this.detalle.mmcall + "', " + this.detalle.lista + ", '" + this.detalle.escalar1 + "', " + this.detalle.tiempo1 + ", " + this.detalle.lista1 + ", '" + this.detalle.log1 + "', '" + this.detalle.sms1 + "', '" + this.detalle.correo1 + "', '" + this.detalle.llamada1 + "', '" + this.detalle.mmcall1 + "', '" + this.detalle.repetir1 + "', " + this.detalle.veces1 + ", '" + this.detalle.escalar2 + "', " + this.detalle.tiempo2 + ", " + this.detalle.lista2 + ", '" + this.detalle.log2 + "', '" + this.detalle.sms2 + "', '" + this.detalle.correo2 + "', '" + this.detalle.llamada2 + "', '" + this.detalle.mmcall2 + "', '" + this.detalle.repetir2 + "', " + this.detalle.veces2 + ", '" + this.detalle.escalar3 + "', " + this.detalle.tiempo3 + ", " + this.detalle.lista3 + ", '" + this.detalle.log3 + "', '" + this.detalle.sms3 + "', '" + this.detalle.correo3 + "', '" + this.detalle.llamada3 + "', '" + this.detalle.mmcall3 + "', '" + this.detalle.repetir3 + "', " + this.detalle.veces3 + ", '" + this.detalle.escalar4 + "', " + this.detalle.tiempo4 + ", " + this.detalle.lista4 + ", '" + this.detalle.log4 + "', '" + this.detalle.sms4 + "', '" + this.detalle.correo4 + "', '" + this.detalle.llamada4 + "', '" + this.detalle.mmcall4 + "', '" + this.detalle.repetir4 + "', " + this.detalle.veces4 + ", '" + this.detalle.escalar5 + "', " + this.detalle.tiempo5 + ", " + this.detalle.lista5 + ", '" + this.detalle.log5 + "', '" + this.detalle.sms5 + "', '" + this.detalle.correo5 + "', '" + this.detalle.llamada5 + "', '" + this.detalle.mmcall5 + "', '" + this.detalle.repetir5 + "', " + this.detalle.veces5 + ", '" + this.detalle.repetir + "', " + this.detalle.repetir_tiempo + ", " + this.detalle.repetir_veces + ", '" + this.detalle.informar_resolucion + "', '" + this.detalle.resolucion_mensaje + "', '" + this.detalle.cancelacion_mensaje + "', " + this.detalle.tiempo0 + ", '" + this.detalle.mensaje + "', '" + this.detalle.titulo + "', '" + this.detalle.mensaje_mmcall + "',  " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET alertas = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_alertas SET estatus = '" + this.detalle.estatus + "', evento = " + this.detalle.evento + ", tiempo0 = " + this.detalle.tiempo0 + ", proceso = '" + this.detalle.proceso + "', referencia = '" + this.detalle.referencia + "', nombre = '" + this.detalle.nombre + "', solapar = '" + this.detalle.solapar + "', tipo = " + this.detalle.tipo + ", notas = '" + this.detalle.notas + "', linea = '" + this.detalle.linea + "', maquina = '" + this.detalle.maquina + "', area = '" + this.detalle.area + "', falla = '" + this.detalle.falla + "', transcurrido = " + this.detalle.transcurrido + ", acumular = '" + this.detalle.acumular + "', acumular_veces = " + this.detalle.acumular_veces + ", acumular_tiempo = " + this.detalle.acumular_tiempo + ", acumular_inicializar = '" + this.detalle.acumular_inicializar + "', log = '" + this.detalle.log + "', sms = '" + this.detalle.sms + "', correo = '" + this.detalle.correo + "', llamada = '" + this.detalle.llamada + "', mmcall = '" + this.detalle.mmcall + "', lista = " + this.detalle.lista + ", escalar1 = '" + this.detalle.escalar1 + "', tiempo1 = " + this.detalle.tiempo1 + ", lista1 = " + this.detalle.lista1 + ", log1 = '" + this.detalle.log1 + "', sms1 = '" + this.detalle.sms1 + "', correo1 = '" + this.detalle.correo1 + "', llamada1 = '" + this.detalle.llamada1 + "', mmcall1 = '" + this.detalle.mmcall1 + "', repetir1 = '" + this.detalle.repetir1 + "', veces1 = " + this.detalle.veces1 + ", escalar2 = '" + this.detalle.escalar2 + "', tiempo2 = " + this.detalle.tiempo2 + ", lista2 = " + this.detalle.lista2 + ", log2 = '" + this.detalle.log2 + "', sms2 = '" + this.detalle.sms2 + "', correo2 = '" + this.detalle.correo2 + "', llamada2 = '" + this.detalle.llamada2 + "', mmcall2 = '" + this.detalle.mmcall2 + "', repetir2 = '" + this.detalle.repetir2 + "', veces2 = " + this.detalle.veces2 + ", escalar3 = '" + this.detalle.escalar3 + "', tiempo3 = " + this.detalle.tiempo3 + ", lista3 = " + this.detalle.lista3 + ", log3 = '" + this.detalle.log3 + "', sms3 = '" + this.detalle.sms3 + "', correo3 = '" + this.detalle.correo3 + "', llamada3 = '" + this.detalle.llamada3 + "', mmcall3 = '" + this.detalle.mmcall3 + "', repetir3 = '" + this.detalle.repetir3 + "', veces3 = " + this.detalle.veces3 + ", escalar4 = '" + this.detalle.escalar4 + "', tiempo4 = " + this.detalle.tiempo4 + ", lista4 = " + this.detalle.lista4 + ", log4 = '" + this.detalle.log4 + "', sms4 = '" + this.detalle.sms4 + "', correo4 = '" + this.detalle.correo4 + "', llamada4 = '" + this.detalle.llamada4 + "', mmcall4 = '" + this.detalle.mmcall4 + "', repetir4 = '" + this.detalle.repetir4 + "', veces4 = " + this.detalle.veces4 + ", escalar5 = '" + this.detalle.escalar5 + "', tiempo5 = " + this.detalle.tiempo5 + ", lista5 = " + this.detalle.lista5 + ", log5 = '" + this.detalle.log5 + "', sms5 = '" + this.detalle.sms5 + "', correo5 = '" + this.detalle.correo5 + "', llamada5 = '" + this.detalle.llamada5 + "', mmcall5 = '" + this.detalle.mmcall5 + "', repetir5 = '" + this.detalle.repetir5 + "', veces5 = " + this.detalle.veces5 + ", repetir = '" + this.detalle.repetir + "', repetir_tiempo = " + this.detalle.repetir_tiempo + ", repetir_veces = " + this.detalle.repetir_veces + ", informar_resolucion = '" + this.detalle.informar_resolucion + "', resolucion_mensaje = '" + this.detalle.resolucion_mensaje + "', cancelacion_mensaje = '" + this.detalle.cancelacion_mensaje + "', mensaje = '" + this.detalle.mensaje + "', titulo = '" + this.detalle.titulo + "', mensaje_mmcall = '" + this.detalle.mensaje_mmcall + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET alertas = NOW();"; 
      }
    }
    else if (this.miSeleccion == 9)
    {
      this.detalle.inicia = !this.detalle.inicia ? this.servicio.fecha(1, "", "HH") + ":00:00" : this.detalle.inicia;
      this.detalle.termina = !this.detalle.termina ? this.servicio.fecha(1, "", "HH") + ":59:59" : this.detalle.termina;
      this.detalle.secuencia = !this.detalle.secuencia ? "1" : this.detalle.secuencia;
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_turnos (nombre, referencia, inicia, termina, cambiodia, especial, tipo, mover, secuencia, creado, modificado, creacion, modificacion, usuario) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.inicia + "', '" + this.detalle.termina + "', '" + this.detalle.cambiodia + "', '" + this.detalle.especial + "', " + +this.detalle.tipo + ", " + +this.detalle.mover + ", " + this.detalle.secuencia + ", " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW(), " + this.detalle.usuario + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET correos = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_turnos SET nombre = '" + this.detalle.nombre + "', secuencia = " + this.detalle.secuencia + ", referencia = '" + this.detalle.referencia + "', inicia = '" + this.detalle.inicia + "', termina = '" + this.detalle.termina + "', cambiodia = '" + this.detalle.cambiodia + "', especial = '" + this.detalle.especial + "', tipo = " + +this.detalle.tipo + ", mover = " + +this.detalle.mover + ", estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW(), usuario = " + this.detalle.usuario + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET correos = NOW();";
      }
    }
    else if (this.miSeleccion == 10)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".traduccion (literal, traduccion) VALUES ('" + this.detalle.literal + "', '" + this.detalle.traduccion + "');"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".traduccion SET literal = '" + this.detalle.literal + "', traduccion = '" + this.detalle.traduccion + "' WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET traducciones = NOW();";
      }
    }
    else if (this.miSeleccion == 12)
    {
      this.detalle.inicia = !this.detalle.inicia ? this.servicio.fecha(1, "", "HH") + ":00:00" : this.detalle.inicia;
      this.detalle.planta = !this.detalle.planta ? 0 : this.detalle.planta;
      this.detalle.departamento = !this.detalle.departamento ? 0 : this.detalle.departamento;
      this.detalle.compania = !this.detalle.compania ? 0 : this.detalle.compania;
      this.detalle.politica  = !this.detalle.politica ? 0 : this.detalle.politica;
      this.detalle.turno  = !this.detalle.turno ? 0 : this.detalle.turno;
      this.detalle.idioma  = !this.detalle.idioma ? 0 : this.detalle.idioma;
      this.detalle.plantas  = !this.detalle.plantas ? "S" : this.detalle.plantas;
      this.detalle.mapa  = !this.detalle.mapa ? "S" : this.detalle.mapa;
      this.detalle.planta_defecto  = !this.detalle.planta_defecto ? 0 : this.detalle.planta_defecto;
      
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".cat_usuarios (nombre, referencia, notas, rol, politica, linea, maquina, area, operacion, imagen, planta, plantas, mapa, departamento, compania, turno, idioma, planta_defecto, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.notas + "', '" + this.detalle.rol + "', " + this.detalle.politica + ", '" + this.detalle.linea + "', '" + this.detalle.maquina + "', '" + this.detalle.area + "', '" + this.detalle.operacion + "', '" + this.detalle.imagen + "', " + this.detalle.planta + ", '" + this.detalle.plantas + "', '" + this.detalle.mapa + "', " + this.detalle.departamento + ", " + this.detalle.compania + ", " + this.detalle.turno  + ", " + this.detalle.idioma  + ", " + this.detalle.planta_defecto + ", " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET usuarios = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".cat_usuarios SET nombre = '" + this.detalle.nombre + "', referencia = '" + this.detalle.referencia + "', notas = '" + this.detalle.notas + "', rol = '" + this.detalle.rol + "', politica = " + this.detalle.politica + ", linea = '" + this.detalle.linea + "', maquina = '" + this.detalle.maquina + "', area = '" + this.detalle.area + "', mapa = '" + this.detalle.mapa + "', plantas = '" + this.detalle.plantas + "', operacion = '" + this.detalle.operacion + "', imagen = '" + this.detalle.imagen + "', planta = " + this.detalle.planta + ", departamento = " + this.detalle.departamento + ", compania = " + this.detalle.compania + ", turno = " + this.detalle.turno + ", idioma = " + this.detalle.idioma + ", planta_defecto = " + this.detalle.planta_defecto + ", estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET usuarios = NOW();";
      }
    }
    
    else if (this.miSeleccion == 14)
    {
      this.detalle.diasvencimiento = !this.detalle.diasvencimiento ? 0 : this.detalle.diasvencimiento;
      this.detalle.aviso = !this.detalle.aviso ? 0 : this.detalle.aviso;
      this.detalle.largo = !this.detalle.largo ? 0 : this.detalle.largo;

      this.detalle.largo = this.detalle.largo < 0 ? 0 : this.detalle.largo > 50 ? 50 : this.detalle.largo;
      this.detalle.diasvencimiento = this.detalle.diasvencimiento < 0 ? 0 : this.detalle.diasvencimiento > 365 ? 365 : this.detalle.diasvencimiento;
      this.detalle.aviso = this.detalle.aviso < 0 ? 0 : this.detalle.aviso > 30 ? 30 : this.detalle.aviso;
      
      this.detalle.especial = "N";
      this.detalle.numeros = "N";
      this.detalle.mayusculas = "N";
      for (var i = 0; i < this.listaComplejidad.selectedOptions.selected.length; i++) 
      {
        if (this.listaComplejidad.selectedOptions.selected[i].value==0)
        {
          this.detalle.especial = "S";
        }
        else if (this.listaComplejidad.selectedOptions.selected[i].value==1)
        {
          this.detalle.numeros = "S";
        }
        else if (this.listaComplejidad.selectedOptions.selected[i].value==2)
        {
          this.detalle.mayusculas = "S";
        }
      }
      this.detalle.complejidad = this.detalle.largo + ";" + this.detalle.especial + ";" + this.detalle.numeros + ";" + this.detalle.mayusculas
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".politicas (nombre, deunsolouso, obligatoria, vence, diasvencimiento, aviso, complejidad, usadas, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.deunsolouso + "', '" + this.detalle.obligatoria + "', '" + this.detalle.vence + "', " + this.detalle.diasvencimiento + ", " + this.detalle.aviso + ", '" + this.detalle.complejidad + "', " + this.detalle.usadas + ", " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET politicas = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".politicas SET nombre = '" + this.detalle.nombre + "', deunsolouso = '" + this.detalle.deunsolouso + "', obligatoria = '" + this.detalle.obligatoria + "', vence = '" + this.detalle.vence + "', diasvencimiento = " + this.detalle.diasvencimiento + ", aviso = " + this.detalle.aviso + ", complejidad = '" + this.detalle.complejidad + "', usadas = " + this.detalle.usadas + ", estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET politicas = NOW();";
      }
    }
    else if (this.miSeleccion == 17 && this.vista17==0)
    {
        if (this.yaValidado==-1)
      {
        this.validarSiExiste(1)
        return;
      }
      else
      {
        this.detalle.id = this.yaValidado;
        this.detalle.alto = !this.detalle.alto ? 0 : this.detalle.alto > 1000 ? 1000 : this.detalle.alto;
        this.detalle.bajo = !this.detalle.bajo ? 0 : this.detalle.bajo > 1000 ? 1000 : this.detalle.bajo < 0 ? 0 : this.detalle.bajo;
        sentencia = "INSERT INTO " + this.servicio.rBD() + ".relacion_partes_equipos (parte, equipo, piezas, unidad, tiempo, bajo, alto) VALUES (" + this.detalle.parte + ", " + this.detalle.equipo + ", " + this.detalle.piezas + ", '" + this.detalle.unidad + "', " + this.detalle.tiempo + ", " + this.detalle.bajo + ", " + this.detalle.alto + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET rates = NOW();"
        if (this.detalle.id > 0)
        {
          sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_partes_equipos SET parte = " + this.detalle.parte + ", equipo = " + this.detalle.equipo + ", piezas = " + this.detalle.piezas + ", unidad = '" + this.detalle.unidad + "', tiempo = " + this.detalle.tiempo + ", bajo = " + this.detalle.bajo + ", alto = " + this.detalle.alto + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET rates = NOW();";
        }
        this.yaValidado = -1;
      }
    }
    else if (this.miSeleccion == 17 && this.vista17 ==1)
    {
      this.detalle.id = this.yaValidado;
      this.detalle.alto = !this.detalle.alto ? 0 : this.detalle.alto > 1000 ? 1000 : this.detalle.alto;
      this.detalle.bajo = !this.detalle.bajo ? 0 : this.detalle.bajo > 1000 ? 1000 : this.detalle.bajo < 0 ? 0 : this.detalle.bajo;
      sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_partes_equipos SET sesion = 'S' WHERE equipo = " + this.equipoAntes + " AND piezas = " + this.piezasAntes + ";"
    }
    else if (this.miSeleccion == 18)
    {
      if (this.yaValidado==-1)
      {
        this.validarSiExiste(2)
        return;
      }
      else
      {
        this.detalle.id = this.yaValidado;
        this.detalle.desde = this.detalle.desde ? this.detalle.desde : "";
        this.detalle.hasta = this.detalle.hasta ? this.detalle.hasta : "";
        sentencia = "INSERT INTO " + this.servicio.rBD() + ".equipos_objetivo (parte, equipo, lote, turno, fijo, desde, hasta, objetivo, reinicio) VALUES (" + this.detalle.parte + ", " + this.detalle.equipo + ", " + this.detalle.lote + ", " + this.detalle.turno + ", '" + this.detalle.fijo + "', " + (this.detalle.desde == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "'")  + ", " + (this.detalle.hasta == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "'")  + ", " + this.detalle.objetivo + ", " + this.detalle.reinicio + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET objetivos = NOW();"
        if (this.detalle.id > 0)
        {
          sentencia = "UPDATE " + this.servicio.rBD() + ".equipos_objetivo SET parte = " + this.detalle.parte + ", reinicio = " + this.detalle.reinicio + ", equipo = " + this.detalle.equipo + ", objetivo = " + this.detalle.objetivo + ", fijo = '" + this.detalle.fijo + "', turno = " + this.detalle.turno + ", lote = " + this.detalle.lote + ", desde = " + (this.detalle.desde == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "'")  + ", hasta = " + (this.detalle.hasta == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "'")  + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET objetivos = NOW();";
        }
        this.yaValidado = -1;
      }
    }
    else if (this.miSeleccion == 19)
    {
      if (this.yaValidado==-1)
      {
        this.validarSiExiste(3)
        return;
      }
      else
      {
        this.detalle.id = this.yaValidado;
        this.detalle.desde = this.detalle.desde ? this.detalle.desde : "";
        this.detalle.hasta = this.detalle.hasta ? this.detalle.hasta : "";
        sentencia = "INSERT INTO " + this.servicio.rBD() + ".estimados (linea, equipo, fijo, desde, hasta, oee, efi, dis, ftq) VALUES (" + this.detalle.linea + ", " + this.detalle.equipo + ", '" + this.detalle.fijo + "', " + (this.detalle.desde == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "'")  + ", " + (this.detalle.hasta == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "'")  + ", " + this.detalle.oee + ", " + this.detalle.efi + ", " + this.detalle.ftq + ", " + this.detalle.dis + ");UPDATE " + this.servicio.rBD() + ".actualizaciones SET estimados = NOW();"
        if (this.detalle.id > 0)
        {
          sentencia = "UPDATE " + this.servicio.rBD() + ".estimados SET linea = " + this.detalle.linea + ", equipo = " + this.detalle.equipo + ", oee = " + this.detalle.oee + ", efi = " + this.detalle.efi + ", dis = " + this.detalle.dis + ", ftq = " + this.detalle.ftq + ", fijo = '" + this.detalle.fijo + "', desde = " + (this.detalle.desde == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "'")  + ", hasta = " + (this.detalle.hasta == "" ? "null" : "'" + this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "'")  + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET estimados = NOW();";
        }
        this.yaValidado = -1;
      }
    }
    else if (this.miSeleccion == 20)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".relacion_procesos_sensores (equipo, sensor, tipo, multiplicador, base, area, clasificacion, creado, modificado, creacion, modificacion) VALUES (" + this.detalle.equipo + ", '" + this.detalle.sensor + "', " + this.detalle.tipo + ", " + this.detalle.multiplicador + ", " + this.detalle.base + ", " + this.detalle.area + ", " + this.detalle.clasificacion + ", " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET sensores = NOW();"
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".relacion_procesos_sensores SET equipo = " + this.detalle.equipo + ", sensor = '" + this.detalle.sensor + "', tipo = " + this.detalle.tipo + ", area = " + this.detalle.area + ", clasificacion = " + this.detalle.clasificacion + ", multiplicador = " +  this.detalle.multiplicador + ", base = " +  this.detalle.base + ", estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET sensores = NOW();";
      }
    }
    else if (this.miSeleccion == 21)
    {
      this.detalle.fecha = this.detalle.fdesde;
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".detalleparos (paro, notas, tipo, area, maquina, inicio, finaliza_sensor, estado, fecha, desde, hasta, origen, tiempo) VALUES ('" + this.detalle.paro + "', '" + this.detalle.notas + "', " + this.detalle.tipo + ", " + this.detalle.area + ", " + this.detalle.maquina + ", " + this.servicio.rUsuario().id + ", '" + this.detalle.finaliza_sensor + "', '" + this.detalle.estado + "', '" +  this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") + "', '" + this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde + "', '" + this.servicio.fecha(2, this.detalle.fhasta, "yyyy/MM/dd") + " " + this.detalle.hasta + "', 'N', TIME_TO_SEC(TIMEDIFF('" + this.servicio.fecha(2, this.detalle.fhasta, "yyyy/MM/dd") + " " + this.detalle.hasta + "', '" + this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde + "')));UPDATE " + this.servicio.rBD() + ".actualizaciones SET paros = NOW();"
      if (this.detalle.id > 0 && this.detalle.clase == 0 && this.detalle.estado >= "L")
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".detalleparos SET paro = '" + this.detalle.paro + "', notas = '" + this.detalle.notas + "', maquina = " + this.detalle.maquina + ", tipo = " + this.detalle.tipo + ", area = " +  this.detalle.area + ", finaliza_sensor = '" +  this.detalle.finaliza_sensor + "', estatus = '" + this.detalle.estatus + "', estado = '" + this.detalle.estado + "', fecha = '" + this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") + "', desde = '" + this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde + "', hasta = '" + this.servicio.fecha(2, this.detalle.fhasta, "yyyy/MM/dd") + " " + this.detalle.hasta + "', tiempo = TIME_TO_SEC(TIMEDIFF('" + this.servicio.fecha(2, this.detalle.fhasta, "yyyy/MM/dd") + " " + this.detalle.hasta + "', '" + this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde + "')) WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET paros = NOW();";
        
      }
      else if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".detalleparos SET paro = '" + this.detalle.paro + "', notas = '" + this.detalle.notas + "', tipo = " + this.detalle.tipo + ", area = " +  this.detalle.area + " WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET paros = NOW();";
        
      }
    }
    else if (this.miSeleccion == 27)
    {
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".detallerechazos (rechazo, tipo, area, equipo, fecha, turno, origen, corte, notas, parte, lote, cantidad, cantidad_tc, usuario, actualizacion) VALUES ('" + this.detalle.rechazo + "', " + this.detalle.tipo + ", " + this.detalle.area + ", " + this.detalle.equipo + ", '" + this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") + "', " + this.detalle.turno + ", "  + this.detalle.origen  + ", " + this.corteActual + ", '" + this.detalle.notas + "', " + this.detalle.parte + ", " + this.detalle.lote + ", " + this.detalle.cantidad + ", " + this.detalle.cantidad * this.rateEquipo + ", " + this.servicio.rUsuario().id + ", NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET rechazos = NOW();"
      if (this.detalle.existe > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".detallerechazos SET rechazo = '" + this.detalle.rechazo + "', tipo = " + this.detalle.tipo + ", area = " + this.detalle.area + ", equipo = " + this.detalle.equipo + ", fecha = '" + this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") + "', turno = " + this.detalle.turno + ", corte = " + this.corteActual + ", notas = '" + this.detalle.notas + "', parte = " + this.detalle.parte + ", lote = " + this.detalle.lote + ", cantidad = " + this.detalle.cantidad + ", cantidad_tc = " + this.detalle.cantidad * this.rateEquipo + ", usuario = " + this.servicio.rUsuario().id + ", actualizacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET rechazos = NOW();";
        
      }
    }
    else if (this.miSeleccion == 30)
    {
      let laFecha = "NULL";
      if (this.detalle.fdesde)
      {
        laFecha = "'" + this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde + "'";
      }
      let laHora = "";
      if (this.detalle.hora)
      {
        laHora =  "'" + (this.detalle.hora.length == 4 ? this.detalle.hora +  ":00" : this.detalle.hora) + "'";
      }
      sentencia = "INSERT INTO " + this.servicio.rBD() + ".plan_checklists (nombre, referencia, imagen, fecha, notas, frecuencia, hora, checklists, anticipacion, tiempo, creado, modificado, creacion, modificacion) VALUES ('" + this.detalle.nombre + "', '" + this.detalle.referencia + "', '" + this.detalle.imagen + "', " + laFecha + ", '" + this.detalle.notas + "', '"  + this.detalle.frecuencia + "', " + laHora + ", '" + this.detalle.checklists + "', '" + this.detalle.anticipacion + "', " + +this.detalle.tiempo + ", " + this.servicio.rUsuario().id + ", " + this.servicio.rUsuario().id + ", NOW(), NOW());UPDATE " + this.servicio.rBD() + ".actualizaciones SET planes_checklists = NOW();";
      if (this.detalle.id > 0)
      {
        sentencia = "UPDATE " + this.servicio.rBD() + ".plan_checklists SET nombre = '" + this.detalle.nombre + "', referencia = '" + this.detalle.referencia + "', imagen = '" + this.detalle.imagen + "', fecha = " +  (!this.detalle.fdesde ? "NULL" : "'" + this.servicio.fecha(2, this.detalle.fdesde, "yyyy/MM/dd") + " " + this.detalle.desde + "'") + ", frecuencia = '" + this.detalle.frecuencia + "', hora = " + laHora + ", checklists = '" + this.detalle.checklists + "', anticipacion = '" + this.detalle.anticipacion + "', notas = '" + this.detalle.notas + "', tiempo = " + +this.detalle.tiempo + ", estatus = '" + this.detalle.estatus + "', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET planes_checklists = NOW();";
        
      }
    }
    
    let campos = {accion: 200, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (this.detalle.id == 0)
      {
        sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_lineas;";
        if (this.miSeleccion == 2)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_maquinas;";
        }
        else if (this.miSeleccion == 3)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_areas;";
        }
        else if (this.miSeleccion == 28)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_variables;";
        }
        else if (this.miSeleccion == 4)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_fallas;";
        }
        else if (this.miSeleccion == 25)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_partes;";
        }
        else if (this.miSeleccion == 5)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_generales;";
        }
        else if (this.miSeleccion == 6)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_distribucion;";
        }
        else if (this.miSeleccion == 7)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_correos;";
        }
        else if (this.miSeleccion == 8)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_alertas;";
        }
        else if (this.miSeleccion == 9)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_turnos;";
        }
        else if (this.miSeleccion == 10)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".traduccion;";
        }
        else if (this.miSeleccion == 12)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".cat_usuarios;";
        }
        else if (this.miSeleccion == 14)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".politicas;";
        }
        else if (this.miSeleccion == 17 && this.vista17==0)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".relacion_partes_equipos;";
        }
        else if (this.miSeleccion == 18)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".equipos_objetivo;";
        }
        else if (this.miSeleccion == 19)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".estimados;";
        }
        else if (this.miSeleccion == 20)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".relacion_procesos_sensores;";
        }
        else if (this.miSeleccion == 21)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".detalleparos;";
        }
        else if (this.miSeleccion == 27)
        {
          sentencia = "SELECT MAX(id) AS nuevoid FROM " + this.servicio.rBD() + ".detallerechazos;";
        }
        let campos = {accion: 100, sentencia: sentencia};  
        this.servicio.consultasBD(campos).subscribe(resp =>
        {
          this.detalle.id = resp[0].nuevoid
          this.detalle.creacion = new Date();
          this.detalle.creado = this.servicio.rUsuario().nombre;
          this.guardar_2();
        })
      }
      else
      {
        this.guardar_2();
      }
      this.detalle.modificado = this.servicio.rUsuario().nombre;
      this.detalle.modificacion = new Date();
      this.bot3 = false;
      this.bot4 = false;
      this.bot5 = true;
      this.bot6 = this.detalle.estatus == "A";
      this.bot7 = true;

      this.bot1Sel = false;
      this.bot2Sel = false;
      this.bot3Sel = false;
      this.bot4Sel = false;
      this.bot5Sel = false;
      this.bot6Sel = false;
      this.bot7Sel = false;
    
      

      let mensajeCompleto: any = [];
      mensajeCompleto.clase = "snack-normal";
      mensajeCompleto.mensaje = "El registro se ha guardado satisfactoriamente";
      mensajeCompleto.tiempo = 2000;
      this.servicio.mensajeToast.emit(mensajeCompleto);
      setTimeout(() => {
        this.txtNombre.nativeElement.focus();
      }, 400);
      
    })
  
  }

  guardar_2()
  {
    let seleccionados
    let seleccionados1
    let seleccionados2
    let seleccionados3
    let seleccionados4
    let seleccionados5
    let seleccionados6
    let seleccionados7
    if (this.miSeleccion == 7)
    {
      seleccionados = this.listaListad.selectedOptions.selected;
    }
    if (this.miSeleccion == 30)
    {
      seleccionados = this.lista2.selectedOptions.selected;
    }
    else if (this.miSeleccion == 12)
    {
      seleccionados1 = this.lista1.selectedOptions.selected;
      seleccionados2 = this.lista2.selectedOptions.selected;
      seleccionados3 = this.lista3.selectedOptions.selected;
      seleccionados4 = this.lista4.selectedOptions.selected;
      if (this.lista5)
      {
        seleccionados5 = this.lista5.selectedOptions.selected;  
      }
      if (this.lista7)
      {
        seleccionados7 = this.lista7.selectedOptions.selected;  
      }
      seleccionados6 = this.lista6.selectedOptions.selected;
      
      
    }
    else if (this.miSeleccion == 4)
    {
      seleccionados1 = this.lista1.selectedOptions.selected;
      seleccionados2 = this.lista2.selectedOptions.selected;
      seleccionados3 = this.lista3.selectedOptions.selected;
    }
    else if (this.miSeleccion == 25)
    {
      seleccionados2 = this.lista2.selectedOptions.selected;
    }
    else if (this.miSeleccion == 17 && this.vista17==1)
    {
      seleccionados5 = this.lista3.selectedOptions.selected;
    }
    if (this.miSeleccion==7)
      {
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".det_correo WHERE correo = " + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".det_correo (correo, reporte) VALUES";
        for (var i = 0; i < seleccionados.length; i++) 
        {
          cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados[i].value + "),";
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }
      if (this.miSeleccion==30)
      {
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".det_plan_checklists WHERE plan = " + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".det_plan_checklists (plan, checklist) VALUES";
        for (var i = 0; i < seleccionados.length; i++) 
        {
          cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados[i].value + "),";
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }

      if (this.miSeleccion==12)
      {
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".relacion_usuarios_opciones WHERE usuario = " + +this.detalle.id + ";DELETE FROM " + this.servicio.rBD() + ".relacion_usuarios_operaciones WHERE usuario = " + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".relacion_usuarios_opciones (usuario, opcion) VALUES";
        for (var i = 0; i < seleccionados4.length; i++) 
        {
          cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados4[i].value + "),";
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        if (seleccionados1.length > 0 || seleccionados2.length > 0 || seleccionados3.length > 0 || seleccionados6.length > 0 || seleccionados7.length > 0)
        {
          cadTablas = cadTablas + ";INSERT INTO " + this.servicio.rBD() + ".relacion_usuarios_operaciones (usuario, proceso, tipo) VALUES";
          for (var i = 0; i < seleccionados1.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados1[i].value + ", 1),";
          }
          for (var i = 0; i < seleccionados2.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados2[i].value + ", 2),";
          }
          for (var i = 0; i < seleccionados3.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados3[i].value + ", 3),";
          }
          if (seleccionados6)
          {
            for (var i = 0; i < seleccionados6.length; i++) 
            {
              cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados6[i].value + ", 4),";
            }
          }
          if (seleccionados5)
          {
            for (var i = 0; i < seleccionados5.length; i++) 
            {
              cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados5[i].value + ", 0),";
            }
            
          }
          if (seleccionados7)
          {
            for (var i = 0; i < seleccionados7.length; i++) 
            {
              cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados7[i].value + ", 6),";
            }
            
          }
          cadTablas = cadTablas.substr(0, cadTablas.length - 1);
          
        }
        
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }

      if (this.miSeleccion==4)
      {
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".relacion_fallas_operaciones WHERE falla = " + +this.detalle.id + ";";
        if (seleccionados1.length > 0 || seleccionados2.length > 0 || seleccionados3.length > 0)
        {
          cadTablas = cadTablas + "INSERT INTO " + this.servicio.rBD() + ".relacion_fallas_operaciones (falla, proceso, tipo) VALUES";
          
          
          for (var i = 0; i < seleccionados1.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados1[i].value + ", 1),";
          }
          for (var i = 0; i < seleccionados2.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados2[i].value + ", 2),";
          }
          for (var i = 0; i < seleccionados3.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados3[i].value + ", 3),";
          }          
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }
      else if (this.miSeleccion == 8)
      {
        seleccionados1 = this.lista1.selectedOptions.selected;
        seleccionados2 = this.lista2.selectedOptions.selected;
        seleccionados3 = this.lista3.selectedOptions.selected;
        seleccionados4 = this.lista4.selectedOptions.selected;
        if (this.lista5)
        {
          seleccionados5 = this.lista5.selectedOptions.selected;  
        }
        else
        {
          seleccionados5 = "";
        }
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".relacion_alertas_operaciones WHERE alerta = " + +this.detalle.id + ";";
        if (seleccionados1.length > 0 || seleccionados2.length > 0 || seleccionados3.length > 0 || seleccionados4.length > 0 || seleccionados5.length > 0)
        {
          cadTablas = cadTablas + "INSERT INTO " + this.servicio.rBD() + ".relacion_alertas_operaciones (alerta, proceso, tipo) VALUES";
          
          
          for (var i = 0; i < seleccionados1.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados1[i].value + ", 1),";
          }
          for (var i = 0; i < seleccionados2.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados2[i].value + ", 2),";
          }
          for (var i = 0; i < seleccionados3.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados3[i].value + ", 3),";
          }
          for (var i = 0; i < seleccionados4.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados4[i].value + ", 4),";
          }
          if (seleccionados5)
          {
            for (var i = 0; i < seleccionados5.length; i++) 
            {
              cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados5[i].value + ", 5),";
            }
          }
                    
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }
      else if (this.miSeleccion == 25)
      {
        let cadTablas = "";
        if (seleccionados2.length > 0)
        {
          cadTablas = cadTablas + "DELETE FROM " + this.servicio.rBD() + ".relacion_partes_maquinas WHERE parte = " + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".relacion_partes_maquinas (parte, maquina) VALUES";
          for (var i = 0; i < seleccionados2.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados2[i].value + "),";
          }
          cadTablas = cadTablas.substr(0, cadTablas.length - 1);
          let campos = {accion: 200, sentencia: cadTablas};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
          });
        }
      }
      else if (this.miSeleccion==28)
      {
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".variables_valores WHERE variable = " + +this.detalle.id + ";";
        if (this.opcionesSel.length > 0)
        {
          cadTablas = cadTablas + "INSERT INTO " + this.servicio.rBD() + ".variables_valores (variable, orden, valor, alarmar, defecto) VALUES";
          for (var i = 0; i < this.opcionesSel.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + (i + 1) + ", '" + this.opcionesSel[i].valor + "', '" + this.opcionesSel[i].alarmar + "', '" + this.opcionesSel[i].defecto + "'),";
          }
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        seleccionados2 = this.lista2.selectedOptions.selected;
        if (seleccionados2.length > 0)
        {
          cadTablas = cadTablas + ";DELETE FROM " + this.servicio.rBD() + ".relacion_variables_equipos WHERE variable = " + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".relacion_variables_equipos (variable, maquina) VALUES";
          for (var i = 0; i < seleccionados2.length; i++) 
          {
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados2[i].value + "),";
          }
          cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        }
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }
      else if (this.miSeleccion==29)
      {
        let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".det_checklist WHERE checklist = " + +this.detalle.id + ";";
        let primero = false;
        for (var i = 0; i < this.opcionesSel.length; i++) 
        {
          if (this.opcionesSel[i].seleccionado)
          {
            if (!primero)
            {
              cadTablas = cadTablas + "INSERT INTO " + this.servicio.rBD() + ".det_checklist (checklist, variable, orden) VALUES";
              primero = true;
            }
            cadTablas = cadTablas +  "(" + this.detalle.id + ", " + this.opcionesSel[i].id + ", " + +(i + 1) + "),";
          }
        }
        cadTablas = cadTablas.substr(0, cadTablas.length - 1);
        let campos = {accion: 200, sentencia: cadTablas};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
        });
      }
      //else if (this.miSeleccion == 21)
      //{
      //  let cadTablas = "";
      //  if (seleccionados2.length > 0)
      //  {
      //    cadTablas = cadTablas + "DELETE FROM " + this.servicio.rBD() + ".relacion_paros_maquinas WHERE paro = " + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".relacion_paros_maquinas (paro, maquina) VALUES";
      //    for (var i = 0; i < seleccionados2.length; i++) 
      //    {
      //      cadTablas = cadTablas +  "(" + this.detalle.id + ", " + seleccionados2[i].value + "),";
      //    }
      //    cadTablas = cadTablas.substr(0, cadTablas.length - 1);
      //    let campos = {accion: 200, sentencia: cadTablas};  
      //    this.servicio.consultasBD(campos).subscribe( resp =>
      //    {
      //    });
      // }
      //}
      else if (this.miSeleccion == 27)
      {
        let cadAdicional = "";
        let cantidadRestar = this.cantidadActual;
        if (this.detalle.campos.length != 4)
        {
          let misCampos = this.detalle.campos.split(";");
          if (misCampos[0] != this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") || misCampos[1] != this.detalle.equipo || misCampos[2] !=  + this.detalle.parte || misCampos[3] !=  + this.detalle.turno || misCampos[4] !=  + this.detalle.lote)
          {
            cadAdicional = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET calidad = calidad - " + +this.cantidadActual + ", calidad_tc = calidad_tc - " + (+this.cantidadActual * this.rateEquipoOriginal) + " WHERE corte = " + this.detalle.corte + ";UPDATE " + this.servicio.rBD() + ".lecturas_cortes SET calidad = calidad - " + +this.cantidadActual + ", calidad_tc = calidad_tc - " + (+this.cantidadActual * this.rateEquipoOriginal) + ", calidad_clasificada = calidad_clasificada - " + this.cantidadActual + " WHERE id = " + this.detalle.corte;
            cantidadRestar = 0;
          }
            
        }
        if (!this.detalle.origen || this.detalle.origen==0)
        {
          let cadTablas = "UPDATE " + this.servicio.rBD() + ".lecturas_cortes SET calidad_clasificada = calidad_clasificada + " + (+this.detalle.cantidad - this.cantidadActual) + " WHERE id = " + this.corteActual;
          let campos = {accion: 200, sentencia: cadTablas};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
          });
        }
        else if (this.detalle.origen == 1)
        {
          let cadTablas = "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET calidad = calidad + " + (+this.detalle.cantidad - cantidadRestar) + ", calidad_tc = calidad_tc + " + (+this.detalle.cantidad - cantidadRestar) * this.rateEquipo + " WHERE corte = " + this.corteActual + ";UPDATE " + this.servicio.rBD() + ".lecturas_cortes SET calidad = calidad + " + (+this.detalle.cantidad - cantidadRestar) + ", calidad_tc = calidad_tc + " + (+this.detalle.cantidad - cantidadRestar) * this.rateEquipo + ", calidad_clasificada = calidad_clasificada + " + +(this.detalle.cantidad - cantidadRestar) + " WHERE id = " + this.corteActual + cadAdicional;
          let campos = {accion: 200, sentencia: cadTablas};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
          });
        }
        this.detalle.campos = this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") + ";" + this.detalle.equipo + ";" + this.detalle.parte + ";" + this.detalle.turno + ";" + this.detalle.lote;
        this.detalle.existe = 1;
        this.buscarRate(1)

        this.detalle.nuevo = false;
        //this.detalle.fecha = new Date(this.detalle.fecha + " 23:00:00")

        this.cantidadActual = this.detalle.cantidad;
        this.detalle.corte = this.corteActual;
        this.cantidadValidada = false;
        
      }
      if (this.miSeleccion==1 || this.miSeleccion==2)
      {
        this.disponibilidad.lunes = !this.disponibilidad.lunes ? 0 : this.disponibilidad.lunes; 
        this.disponibilidad.martes = !this.disponibilidad.martes ? 0 : this.disponibilidad.martes; 
        this.disponibilidad.miercoles = !this.disponibilidad.miercoles ? 0 : this.disponibilidad.miercoles; 
        this.disponibilidad.jueves = !this.disponibilidad.jueves ? 0 : this.disponibilidad.jueves; 
        this.disponibilidad.viernes = !this.disponibilidad.viernes ? 0 : this.disponibilidad.viernes; 
        this.disponibilidad.sabado = !this.disponibilidad.sabado ? 0 : this.disponibilidad.sabado; 
        this.disponibilidad.domingo = !this.disponibilidad.domingo ? 0 : this.disponibilidad.domingo; 

        this.disponibilidad.lunes = this.disponibilidad.lunes < 0 ? 0 : this.disponibilidad.lunes; 
        this.disponibilidad.martes = this.disponibilidad.martes < 0 ? 0 : this.disponibilidad.martes; 
        this.disponibilidad.miercoles = this.disponibilidad.miercoles < 0 ? 0 : this.disponibilidad.miercoles; 
        this.disponibilidad.jueves = this.disponibilidad.jueves < 0 ? 0 : this.disponibilidad.jueves; 
        this.disponibilidad.viernes = this.disponibilidad.viernes < 0 ? 0 : this.disponibilidad.viernes; 
        this.disponibilidad.sabado = this.disponibilidad.sabado < 0 ? 0 : this.disponibilidad.sabado; 
        this.disponibilidad.domingo = this.disponibilidad.domingo < 0 ? 0 : this.disponibilidad.domingo; 

        this.disponibilidad.lunes = this.disponibilidad.lunes > 86400 ? 86400 : this.disponibilidad.lunes; 
        this.disponibilidad.martes = this.disponibilidad.martes > 86400 ? 86400 : this.disponibilidad.martes; 
        this.disponibilidad.miercoles = this.disponibilidad.miercoles > 86400 ? 86400 : this.disponibilidad.miercoles; 
        this.disponibilidad.jueves = this.disponibilidad.jueves > 86400 ? 86400 : this.disponibilidad.jueves; 
        this.disponibilidad.viernes = this.disponibilidad.viernes > 86400 ? 86400 : this.disponibilidad.viernes; 
        this.disponibilidad.sabado = this.disponibilidad.sabado > 86400 ? 86400 : this.disponibilidad.sabado; 
        this.disponibilidad.domingo = this.disponibilidad.domingo > 86400 ? 86400 : this.disponibilidad.domingo; 

          let cadTablas = "DELETE FROM " + this.servicio.rBD() + ".disponibilidad WHERE" + (this.miSeleccion == 1 ? " linea = " : " maquina = ") + +this.detalle.id + ";INSERT INTO " + this.servicio.rBD() + ".disponibilidad (" + (this.miSeleccion == 1 ? "linea" : "maquina") + ", lunes, martes, miercoles, jueves, viernes, sabado, domingo, estatus) VALUES(" + +this.detalle.id + ", " + +this.disponibilidad.lunes + ", " + +this.disponibilidad.martes + ", " + +this.disponibilidad.miercoles + ", " + +this.disponibilidad.jueves + ", " + +this.disponibilidad.viernes + ", " + +this.disponibilidad.sabado + ", " + +this.disponibilidad.domingo + ", '" + (this.detalle.disponibilidad == 0 ? "I" : "A") + "');";
          let campos = {accion: 200, sentencia: cadTablas};  
          this.servicio.consultasBD(campos).subscribe( resp =>
          {
          });
        }
    
      if (this.miSeleccion == 17 && this.vista17 ==1)
      {
        this.sentenciaRate = "";
        for (var i = 0; i < seleccionados5.length; i++) 
        {
          this.actualizarRate(seleccionados5[i].value, i == seleccionados5.length - 1, 1)
        }
      }
  }

  validarCantidad()
  {
    let cantidadRestar = 0
    if (!this.detalle.nuevo) 
    {
      cantidadRestar = this.cantidadActual
    }
    if (this.detalle.origen == 0)
    {
      let sentencia = "SELECT calidad, (calidad_clasificada - " + cantidadRestar + " + " + this.detalle.cantidad + ") AS clasificada FROM " + this.servicio.rBD() + ".lecturas_cortes WHERE id = " + this.corteActual;   
      let campos = {accion: 100, sentencia: sentencia};  
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        if (resp.length > 0)
        {
          if (+resp[0].clasificada > +resp[0].calidad)
          {
            const respuesta = this.dialogo.open(DialogoComponent, {
              width: "480px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "La cantidad total de los rechazos documentados <strong>" + (resp[0].clasificada * 1) + "</strong> superaría la cantidad total de piezas rechazadas para los parámetros establecidos <strong>" + (resp[0].calidad * 1) + "</strong>", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_falla" }
            })
            respuesta.afterClosed().subscribe(result => {
              setTimeout(() => {
                this.txtT1.nativeElement.focus();  
              }, 100);
              
            })
            this.bot3 = true;
            
          }
          else
          {
            this.buscarRate(0)
          }
        }
        else
        {
          this.buscarRate(0)
        }
      })
    }
    else
    {
      
      if (this.detalle.campos.length != 4)
      {
        let misCampos = this.detalle.campos.split(";");
        if (misCampos[0] != this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") || misCampos[1] != this.detalle.equipo || misCampos[2] !=  + this.detalle.parte || misCampos[3] !=  + this.detalle.turno || misCampos[4] !=  + this.detalle.lote)
        {
          cantidadRestar = 0;
        }
           
      }
      let sentencia = "SELECT id, produccion, calidad + " + (+this.detalle.cantidad - cantidadRestar) + " AS calidad FROM " + this.servicio.rBD() + ".lecturas_cortes WHERE equipo = " + this.detalle.equipo + " AND parte = " + this.detalle.parte + " AND turno = " + this.detalle.turno + " AND orden = " + this.detalle.lote + " AND dia = '" + this.servicio.fecha(2, this.detalle.fecha + " 10:00:00", "yyyy/MM/dd") + "' ";   
      let campos = {accion: 100, sentencia: sentencia};  
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        if (resp.length > 0)
        {
          if (+resp[0].calidad > +resp[0].produccion)
          {
            const respuesta = this.dialogo.open(DialogoComponent, {
              width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "La cantidad total de los rechazos documentados <strong>" + (resp[0].calidad * 1) + "</strong> superaría la cantidad total de producción registrada para los parámetros establecidos <strong>" + (resp[0].produccion * 1) + "</strong>", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_falla" }
            })
            respuesta.afterClosed().subscribe(result => {
              setTimeout(() => {
                this.txtT1.nativeElement.focus();  
              }, 100);
              
            })
            this.bot3 = true;
            
          }
          else
          {
            this.corteActual = resp[0].id;
            this.buscarRate(0)
          }
        }
        else
        {
          const respuesta = this.dialogo.open(DialogoComponent, {
            width: "480px", panelClass: 'dialogo_atencion', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "No hay registros de producción con los parámetros establecidos por lo tanto no se pueden registrar rechazos", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_falla" }
          })
          respuesta.afterClosed().subscribe(result => {
            setTimeout(() => {
              this.txtT1.nativeElement.focus();  
            }, 100);
            
          })
          this.bot3 = true;
        }
      })
    }
    
  }

  buscarRate(id: number)
  {
    this.rateEquipo = 1;
    let sentencia = "SELECT 1, piezas, tiempo FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE (equipo = " + this.detalle.equipo + " OR equipo = 0) AND (parte = " + this.detalle.parte + " OR parte = 0) ORDER BY parte DESC, equipo DESC LIMIT 1;";   
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        resp[0].piezas = !resp[0].piezas ? 1 : resp[0].piezas == 0 ? 1 : resp[0].piezas;
        if (resp[0].tiempo == 2)
        {
          this.rateEquipo = 3600 / resp[0].piezas;
        }
        else if (resp[0].tiempo == 1)
        {
          this.rateEquipo = 60 / resp[0].piezas;
        }
        else if (resp[0].tiempo == 0)
        {
          this.rateEquipo = 1 / resp[0].piezas;
        }
        else if (resp[0].tiempo == 3)
        {
          this.rateEquipo = 86400 / resp[0].piezas;
        }
        if (id == 0)
        {
          this.cantidadValidada = true;
          this.guardar()
        }
        else
        {
          this.rateEquipoOriginal = this.rateEquipo;
        }
        
      }
      else
      {
        if (id == 0)
        {
          this.cantidadValidada = true;
          this.guardar()
        }
        else
        {
          this.rateEquipoOriginal = this.rateEquipo;
        }
      }
    })
    
  }
  
  actualizarRate(parte: number, ultimo: boolean, accion: number)
  {
    let sentencia = "";
    if (accion == 1)
    {
      sentencia = "SELECT id FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE equipo = " + this.detalle.equipo + " AND parte = " + parte + ";";
      let campos = {accion: 100, sentencia: sentencia};  
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        this.actualizarRate(parte, ultimo, resp.length == 0 ? 2 : 3);
      })
    }
    else
    {
      if (accion == 2)
      {
        this.sentenciaRate = this.sentenciaRate + "INSERT INTO " + this.servicio.rBD() + ".relacion_partes_equipos (parte, equipo, piezas, unidad, tiempo, bajo, alto) VALUES (" + parte + ", " + this.detalle.equipo + ", " + this.detalle.piezas + ", '" + this.detalle.unidad + "', " + this.detalle.tiempo + ", " + this.detalle.bajo + ", " + this.detalle.alto + ");"
      }
      else
      {
        this.sentenciaRate = this.sentenciaRate + "UPDATE " + this.servicio.rBD() + ".relacion_partes_equipos SET sesion = 'N', equipo = " + this.detalle.equipo + ", piezas = " + this.detalle.piezas + ", unidad = '" + this.detalle.unidad + "', tiempo = " + this.detalle.tiempo + ", bajo = " + this.detalle.bajo + ", alto = " + this.detalle.alto + " WHERE parte = " + parte + " AND equipo = " + this.equipoAntes + ";";
      }
      if (ultimo)
      {
        this.sentenciaRate = this.sentenciaRate + "UPDATE " + this.servicio.rBD() + ".actualizaciones SET rates = NOW();DELETE FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE sesion = 'S' AND piezas = " + this.piezasAntes +  " AND equipo = " + this.equipoAntes + ";";
        let campos = {accion: 200, sentencia: this.sentenciaRate};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
          
        })
      }
    }
  }

  validarSiExiste(tabla: number)
  {
    this.yaValidado = 0;
    let sentencia = "SELECT id FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE parte = " + this.detalle.parte + " AND equipo = " + this.detalle.equipo;
    if (tabla == 2)
    {
      sentencia = "SELECT id FROM " + this.servicio.rBD() + ".equipos_objetivo WHERE parte = " + this.detalle.parte + " AND lote = " + this.detalle.lote + " AND turno = " + this.detalle.turno + " AND equipo = " + this.detalle.equipo;
      if (this.detalle.fijo == 'S')
      {
        sentencia = sentencia + " AND fijo = 'S'"
      }
      else
      {
        sentencia = sentencia + " AND fijo = 'N' AND desde = '" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "' AND hasta = " + this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "'";
      }
    }
    else if (tabla == 3)
    {
      sentencia = "SELECT id FROM " + this.servicio.rBD() + ".estimados WHERE linea = " + this.detalle.linea + " AND equipo = " + this.detalle.equipo;
      if (this.detalle.fijo == 'S')
      {
        sentencia = sentencia + " AND fijo = 'S'"
      }
      else
      {
        sentencia = sentencia + " AND fijo = 'N' AND desde = '" + this.servicio.fecha(2, this.detalle.desde, "yyyy/MM/dd") + "' AND hasta = " + this.servicio.fecha(2, this.detalle.hasta, "yyyy/MM/dd") + "'";
      }
    }
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.yaValidado = resp[0].id;
      }
      this.guardar();
    })

  }

  selectionChange(event){
    console.log('selection changed using keyboard arrow');
  }

  iniLeerBD()
  {
    if (!this.servicio.rConfig().visor_revisar_cada)
    {
      this.elTiempo = 5000;
    }
    else
    {
      this.elTiempo = +this.servicio.rConfig().visor_revisar_cada * 1000;
    }
    setTimeout(() => {
      this.leerBD();
    }, +this.elTiempo);
  }

  regresar()
  {
    if (this.editando && !this.cancelarEdicion)
    {
      this.deshacerEdicion(0, 99)
      return;
    }
    this.volver()
  }

  volver()
  {
    this.bot1Sel = false;
    this.bot2Sel = false;
    this.bot3Sel = false;
    this.bot4Sel = false;
    this.bot5Sel = false;
    this.bot6Sel = false;
    this.bot7Sel = false;
    this.botonera1 = 1;
    this.noLeer = false,
    this.rRegistros(this.miSeleccion);
    this.cambiarVista(0);
    this.contarRegs();
  }

  imagenErrorRegistro()
  {
    //if (this.accion == "in")
    {
      this.mostrarImagenRegistro = "N";
      if (this.detalle.imagen)
      {
        this.mensajeImagen = "Imagen no encontrada...";
      }
      else
      {
        this.mensajeImagen = "Campo opcional";
      }
      
    }
  }

  onFileSelected(event)
  {
    this.bot3 = true;
    this.bot4 = true;
    this.bot5 = false;
    this.bot6 = false;
    this.bot7 = false;
      
    const fd = new FormData();
    fd.append('imagen', event.target.files[0], event.target.files[0].name);
    this.editando = true;
    this.faltaMensaje = "No se han guardado los cambios..."
    this.cancelarEdicion = false;
    this.mensajeImagen = "Campo opcional"
    this.detalle.imagen = this.URL_IMAGENES + event.target.files[0].name;
    this.faltaMensaje = "No se han guardado los cambios..."
    this.cancelarEdicion = false;
        

    /** In Angular 5, including the header Content-Type can invalidate your request */
    this.http.post(this.URL_BASE, fd)
    .subscribe(res => {
      console.log(this.URL_BASE);
      console.log(res);
      
        this.detalle.modificacion = null;
        this.detalle.modificado = "";
        this.cancelarEdicion = false;
        this.mostrarImagenRegistro = "S";
        this.mensajeImagen = "Campo opcional"

        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-normal";
        mensajeCompleto.mensaje = "La imagen fue guardada satisfactoriamente en su servidor";
        mensajeCompleto.tiempo = 3000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      })
  }

cambiando(evento: any)
  {
    if (!this.editando)
    {
      this.bot3 = true;
      this.bot4 = true;
      this.bot5 = false;
      this.bot6 = false;
      this.bot7 = false;
      this.editando = true;
      this.faltaMensaje = "No se han guardado los cambios..."
      this.detalle.modificacion = null;
      this.detalle.modificado = "";
      this.cancelarEdicion = false;
      if (this.miSeleccion== 4)
      {
        this.validarCU = false;
        this.validarM = false;
      }
      this.validarUSER = false;
      
    }
    if (evento.target)
    {
      if (evento.target.name)
      {
        if (evento.target.name == "imagen")
        {
          this.mostrarImagenRegistro = "S";
          this.mensajeImagen = "Campo opcional"
        }
      }
    }
  }
  
  nuevo(modo: number)
  {
    if (modo == 1)
    {
      if (this.editando && !this.cancelarEdicion)
      {
        this.deshacerEdicion(0, 2)
        return;
      } 
      
    } 
    else
    {
      this.modelo = 14;
    }
    this.nuevo_siguiente()
  }
  
  calcularHR(segundos: number)
  {
    let cadHora = "";
    if (!segundos)
    {
      cadHora = "";
    }
    else if (segundos == 0)
    {
      cadHora = "0min";
    }
    else if (segundos > 0 && segundos <= 60)
    {
      cadHora = "1min";
    }
    else if ((segundos / 3600) < 1)
    {
      cadHora = (segundos / 60).toFixed(1) + "min" 
    }
    else
    {
      cadHora = (segundos / 3600).toFixed(2) + "hr" 
    }
    return cadHora
  }

  iniDisp()
  {
    this.disponibilidad.lunes = 86400;
    this.disponibilidad.martes = 86400;
    this.disponibilidad.miercoles = 86400;
    this.disponibilidad.jueves = 86400;
    this.disponibilidad.viernes = 86400;
    this.disponibilidad.sabado = 86400;
    this.disponibilidad.domingo = 86400;
    
  }

  nuevo_siguiente()
  {

      this.iniDisp();
      this.copiandoDesde = 0;
      this.yaValidado = -1;
      this.error01 = false;
      this.error02 = false;
      this.error03 = false;
      this.error04 = false;
      this.error05 = false;
      this.error06 = false;
      this.error07 = false;
      this.error08 = false;
      this.error09 = false;
      this.error10 = false;
      this.error20 = false;
      this.error21 = false;
      this.error22 = false;
      this.error23 = false;
      this.error24 = false;
      this.error25 = false;
      this.error30 = false;
      this.error31 = false;
      this.error32 = false;
      this.error33 = false;
      this.error34 = false;
      this.error35 = false;
      this.despuesBusqueda = 0;
      this.error01 = false;
      this.error02 = false;
      this.verTabla = false;
      this.nExtraccion = "0";
      this.adecuar();
      this.botonera1 = 2;
      this.detalle.referencia = "";
      this.detalle.notas = "";
      this.detalle.literal = "";
      this.detalle.traduccion = "";
      this.detalle.imagen = "";
      this.detalle.nombre = "";
      this.detalle.inicia = this.servicio.fecha(1, "", "HH") + ":00:00";
      this.detalle.termina = this.servicio.fecha(1, "", "HH") + ":59:00";
      this.detalle.hora_desde = "00:00:00";
      this.detalle.hora_hasta = "23:59:00";
      this.detalle.cambiodia = "N";
      this.detalle.especial = "N";
      this.detalle.tipo = "0";
      this.detalle.mover = "0";
      //
      
      this.detalle.telefonos = "";
      this.detalle.mmcall = "";
      this.detalle.correos = "";
      //
      this.detalle.agrupador_1 = "0";
      this.detalle.oee = "N";
      this.detalle.activar_buffer = "N";
      this.detalle.paro_wip = "N";
      this.detalle.agrupador_2 = "0";
      this.detalle.tipo = "0";
      this.mostrarImagenRegistro = "S";
      this.mensajeImagen = "Campo opcional"
      this.detalle.imagen = "";
      
      this.detalle.url_mmcall = "";
      this.detalle.estatus = "A";
      this.detalle.disponibilidad = 0;
      this.detalle.id = 0;
      this.detalle.creado = "";
      this.detalle.modificado = "";
      this.detalle.modificacion = null;
      this.detalle.creacion = null;

      ///
      this.seleccionMensaje = ["M", "C"];
      this.seleccionescalar1 = ["C"];
      this.seleccionescalar2 = ["C"];
      this.seleccionescalar3 = ["C"];
      this.seleccionescalar4 = ["C"];
      this.seleccionescalar5 = ["C"];
      this.detalle.evento = "1";
      this.detalle.tiempo = 0;
      this.detalle.solapar = "S";
      this.detalle.tipo = "1";
      this.detalle.falla = "0";
      this.detalle.acumular = "N";
      this.detalle.repetir_veces = 0;
      this.detalle.repetir_tiempo = 0;
      this.detalle.transcurrido = 0;
      this.detalle.repetir = "N";
      this.detalle.escalar1 = "N";
      this.detalle.escalar2 = "N";
      this.detalle.escalar3 = "N";
      this.detalle.escalar4 = "N";
      this.detalle.escalar5 = "N";
      this.detalle.lista = "0";
      this.detalle.lista1 = "0";
      this.detalle.lista2 = "0";
      this.detalle.lista3 = "0";
      this.detalle.lista4 = "0";
      this.detalle.lista5 = "0";
      this.detalle.mensaje = "";
      this.detalle.mensaje_mmcall = "";
      this.detalle.acumular_veces = 0;
      this.detalle.titulo = "";
      this.detalle.tiempo1 = 0;
      this.detalle.repetir1 = "N";
      this.detalle.veces1 = 0;
      this.detalle.veces2 = 0;
      this.detalle.tiempo2 = 0;
      this.detalle.repetir2 = "N";
      this.detalle.veces3 = 0;
      this.detalle.tiempo3 = 0;
      this.detalle.repetir3 = "N";
      this.detalle.veces4 = 0;
      this.detalle.tiempo4 = 0;
      this.detalle.repetir4 = "N";
      this.detalle.veces5 = 0;
      this.detalle.tiempo5 = 0;
      this.detalle.repetir5 = "N";
      this.detalle.informar_resolucion = "N";
      this.detalle.resolucion_mensaje = "";
      this.detalle.cancelacion_mensaje = "";
      this.detalle.acumular_inicializar = "N";
      this.selListadoT = "S";
      this.detalle.titulo = "";
      this.detalle.cuerpo = "";
      this.detalle.para = "";
      this.detalle.copia = "";
      this.detalle.oculta = "";
      this.nFrecuencia = "T";
      this.nLapso = "0";
      this.nExtraccion = "0";
      this.nHorario = "T";
      this.opciones = "S";
      ///
      this.listarListados(0);
      this.llenarListas(1, this.servicio.rBD() + ".cat_generales", " WHERE tabla = " + this.miSeleccion * 10);
      this.llenarListas(2, this.servicio.rBD() + ".cat_generales", " WHERE tabla = " + (this.miSeleccion * 10 + 5));
      ///
      if (this.miSeleccion==12)
      {
        this.detalle.linea = "S";
        this.detalle.maquina = "S";
        this.detalle.operacion = "S";
        this.detalle.mapa = "S";
        this.detalle.area = "S";     
        this.detalle.compania = "0";     
        this.detalle.planta = "0";
        this.detalle.politica = "0";     
        this.detalle.departamento = "0";     
        this.detalle.turno = "0";     
        this.detalle.inicializada=='S';   
        this.asociarTablas(0);
      }
      else if (this.miSeleccion==4)
      {
        this.detalle.linea = "S";
        this.detalle.maquina = "S";
        this.detalle.area = "S";
        this.detalle.afecta_oee = "N";  
        this.detalle.codigo = ""   
        
        this.asociarTablasFalla(0);
      }
      else if (this.miSeleccion==5)
      {
        this.detalle.tabla = "10";
      }
      else if (this.miSeleccion==2)
      {
        this.detalle.oee_historico_rate = 0;
      this.detalle.usuario = 0;
      }
      else if (this.miSeleccion==3)
      {
        this.detalle.audios_activar = "N";
        this.detalle.audios_general = "N";
        this.detalle.recipiente = 0;
      }
      else if (this.miSeleccion==25)
      {
        this.detalle.maquinas = "S";
        this.detalle.tipo = "0";
        this.detalle.ruta = "0";
        this.asociarTablasHerramental(0);
        this.llenarListas(93, this.servicio.rBD() + ".cat_rutas", "");
      }
      else if (this.miSeleccion==14)
      {
        this.detalle.deunsolouso = "N";
        this.detalle.obligatoria = "S";
        this.detalle.vence = "S";     
        this.detalle.diasvencimiento = 365;   
        this.detalle.aviso = 7;   
        this.detalle.largo = 10;
        this.detalle.especial = "S";
        this.detalle.numeros = "S";
        this.detalle.mayusculas = "S";
        this.detalle.usadas = "5";
        this.llenarListas(10120, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 120 " );
        this.llenarListas(10130, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 130 " );
     
      }
      else
      {
        this.detalle.linea = "0";
        this.detalle.maquina = "0";
        this.detalle.area = "0";
      }
      if (this.miSeleccion == 2) 
      {
        this.llenarListas(3, this.servicio.rBD() + ".cat_lineas", "");
        this.llenarListas(6, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 50 ");
        this.llenarListas(22, this.servicio.rBD() + ".cat_usuarios", "");
      }
      else if (this.miSeleccion==8) 
      {
        this.detalle.evento = "0";
        this.detalle.linea = "S";
        this.detalle.falla = "S";
        this.detalle.proceso = "S";
        this.detalle.maquina = "S";
        this.detalle.area = "S";     
        this.asociarTablasAlerta(0);
        this.llenarListas(9, this.servicio.rBD() + ".cat_distribucion", "");
        this.detalle.escalar1 = "N";
        this.detalle.escalar2 = "N";
        this.detalle.escalar3 = "N";
        this.detalle.escalar4 = "N";
        this.detalle.escalar5 = "N";
        let filtroTabla = " WHERE estatus = 'A' AND (alerta < 200" 
        if (this.servicio.rVersion().modulos[5] == 1)
        {
          filtroTabla = filtroTabla + " OR alerta BETWEEN 200 AND 300"
        }
        if (this.servicio.rVersion().modulos[4] == 1)
        {
          filtroTabla = filtroTabla + " OR alerta BETWEEN 300 AND 400"
        }
        if (this.servicio.rVersion().modulos[6] == 1)
        {
          filtroTabla = filtroTabla + " OR alerta BETWEEN 400 AND 500"
        }
        filtroTabla = filtroTabla + ")"
        this.llenarListas(31, this.servicio.rBD() + ".int_eventos", filtroTabla);
      }
      else if (this.miSeleccion == 28) 
      {
        this.llenarListas(1110, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 110 ");
        this.llenarListas(1115, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 115 ");
        this.llenarListas(9, this.servicio.rBD() + ".cat_distribucion", "");
        this.asociarValores(0);
        this.asociarVariablesMaquinas(0);
        this.detalle.unidad = "0";
        this.detalle.tipo = "0";
        this.detalle.maquinas = "S";
        this.detalle.minimo = "";
        this.detalle.maximo = "";
        this.detalle.por_defecto = "";
        this.detalle.lista = "";
        this.detalle.tipo_valor = 0;
        this.activarNumero = true;
        this.detalle.alarma_binaria = 0;
        this.detalle.acumular = 0;
        this.detalle.requerida = 0;
        this.detalle.prefijo = "";
        this.detalle.recipiente = 0;
        this.detalle.url_mmcall = "";
      }
      else if (this.miSeleccion == 29) 
      {
        this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
        this.llenarListas(10, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 70 ");
        this.llenarListas(1120, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 120 ");
        this.detalle.departamento = "0";
        this.detalle.tipo = "0";
        this.detalle.equipo = "0";
        this.detalle.tiempo = "0";
        this.detalle.recipiente = "0";
        this.detalle.variables = "S";
        this.variables(0);
      }
      else if (this.miSeleccion == 30) 
      {
        this.detalle.fdesde = "";
        this.detalle.desde = "";
        this.detalle.frecuencia = "T";
        this.llenarListas(10150, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND (campo = 10 OR campo = 150) " );
        this.checklistPlan(0);
        this.detalle.anticipacion = "N";
        this.detalle.tiempo = 0;
      }
      else if (this.miSeleccion == 5) 
      {
        this.llenarListas(5, this.servicio.rBD() + ".cat_areas", "");
        let filtroTabla = "WHERE id <> 0" 
        if (this.servicio.rVersion().modulos[5] == 0)
        {
          filtroTabla = filtroTabla + " AND id <> 105 "
        }
        if (this.servicio.rVersion().modulos[6] == 0)
        {
          filtroTabla = filtroTabla + " AND id NOT IN (110, 115, 120) "
        }
        if (this.servicio.rVersion().modulos[3] == 0)
        {
          filtroTabla = filtroTabla + " AND id <> 100 "
        }
        this.llenarListas(7, this.servicio.rBD() + ".tablas", filtroTabla);

      }
      else if (this.miSeleccion == 2) 
      {
        this.llenarListas(6, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 50 ");
      }
      else if (this.miSeleccion == 12) 
      {
        this.detalle.admin = 'N';
        this.detalle.rol = "O";
        this.detalle.pantas = "S";
        this.detalle.idioma = 0;
        this.detalle.planta_defecto = 0;
        this.colocarOpciones()
        this.llenarListas(10, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 70 ");
        this.llenarListas(11, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 80 ");
        this.llenarListas(12, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 90 ");
        this.llenarListas(14, this.servicio.rBD() + ".cat_turnos", "");
        this.llenarListas(13, this.servicio.rBD() + ".politicas", "" );
        this.llenarListas(105, this.servicio.rBD() + ".cat_idiomas", "" );
      }
      else if (this.miSeleccion == 17) 
      {
        this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
        this.llenarListas(15, this.servicio.rBD() + ".cat_partes", ""); 
        this.detalle.parte = "-1";
        this.detalle.equipo = "-1";
        this.detalle.tiempo = "0";
        this.detalle.piezas = "0";
        this.detalle.unidad = "";
        if (this.vista17==1)
        {
          this.piezasAntes = 0;
          this.equipoAntes = -1;
          this.llenarPartes(true);
          this.detalle.parte = "N";
          this.detalle.piezas = "";
        }
      }
      else if (this.miSeleccion == 18) 
      {
        this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
        this.llenarListas(15, this.servicio.rBD() + ".cat_partes", "");
        this.llenarListas(17, this.servicio.rBD() + ".lotes", "WHERE a.estado <> 99 AND a.estatus = 'A'");
        this.llenarListas(18, this.servicio.rBD() + ".cat_turnos", "");
        this.detalle.parte = "-1";
        this.detalle.equipo = "-1";
        this.detalle.turno = "-1";
        this.detalle.lote = "-1";
        this.detalle.objetivo = "0";
        this.detalle.reinicio = "0";
        this.detalle.fijo = "S";
        this.detalle.desde = "";
        this.detalle.hasta = "";
      }
      else if (this.miSeleccion == 19) 
      {
        this.llenarListas(16, this.servicio.rBD() + ".cat_maquinas", "");
        this.llenarListas(19, this.servicio.rBD() + ".cat_lineas", "");
        this.detalle.linea = "-1";
        this.detalle.equipo = "-1";
        this.detalle.oee = "0";
        this.detalle.ftq = "0";
        this.detalle.dis = "0";
        this.detalle.efi = "0";
        this.detalle.fijo = "S";
        this.detalle.desde = "";
        this.detalle.hasta = "";
      }
      else if (this.miSeleccion == 20) 
      {
        this.llenarListas(20, this.servicio.rBD() + ".cat_maquinas", "");
        this.llenarListas(10140, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 140 " );
        this.llenarListas(5, this.servicio.rBD() + ".cat_areas", "");
        this.llenarListas(107, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 105 " );
     
        this.detalle.equipo = "-1";
        this.detalle.multiplicador = "1";
        this.detalle.base = "0";
        this.detalle.sensor = "";
        this.detalle.tipo = "0";
        this.detalle.area = "0";
        this.detalle.clasificacion = "0";
      }
      else if (this.miSeleccion == 21) 
      {
        this.paroEnCurso = false;
        this.detalle.maquina = "0";
        this.llenarListas(23, this.servicio.rBD() + ".cat_areas", "");
        this.llenarListas(6, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 45 ");
        this.llenarListas(4, this.servicio.rBD() + ".cat_maquinas", " WHERE a.oee = 'S' ");    
        this.detalle.tipo = "0";
        this.detalle.estado = "P";
        this.detalle.clase = 0;
        this.detalle.area = "0";
        this.detalle.paro = "";
        this.detalle.finaliza_sensor = "S";
        this.detalle.desde = "00:00:00";
        this.detalle.hasta = "23:59:59";
        this.detalle.notas = "";
        //this.detalle.masivo = "N";
        //this.detalle.hora_inicial = "00:00:00";
        //this.detalle.hora_final = "00:59:59";
        this.detalle.fdesde = new Date();
        this.detalle.fhasta = new Date();
      }
      else if (this.miSeleccion == 27) 
      {
        this.detalle.parte = "0";
        this.detalle.turno = "0";
        this.detalle.equipo = "0";
        if (this.loteLista)
        {
          this.detalle.lote = "0";
          this.lotes = [];
        }
        else
        {
          this.detalle.orden = "";
          this.detalle.lote = "0";
          this.fechasLote = [];
          this.turnosLote = [];
        }
        this.detalle.area = "0";
        this.detalle.tipo = "0";
        this.detalle.rechazo = "";
        this.detalle.notas = "";
        this.detalle.origen = "1";
        this.detalle.cantidad = "0";
        this.detalle.existe = 0;
        this.detalle.nuevo = true;
        this.detalle.campos = ";;;;";
        this.corteActual = 0;
        this.detalle.fecha = "0"; //new Date();
        this.llenarListas(23, this.servicio.rBD() + ".cat_areas", "");
        this.llenarListas(115, this.servicio.rBD() + ".cat_partes", "");
        this.llenarListas(118, this.servicio.rBD() + ".cat_turnos", "");
        this.llenarListas(106, this.servicio.rBD() + ".cat_generales", " WHERE tabla = 105 " );
        this.servicio.mensajeInferior.emit("Edición de rechazos");    
        this.llenarListas(104, this.servicio.rBD() + ".cat_maquinas", " WHERE a.oee = 'S' ");  
        this.cantidadValidada = false;   
        this.cantidadActual = 0; 
      }
      else if (this.miSeleccion == 9) 
      {
        this.detalle.usuario = 0;
        this.llenarListas(22, this.servicio.rBD() + ".cat_usuarios", "");
      }
      else if (this.miSeleccion == 7) 
      {
        this.llenarListas(10010, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 10 " );
        this.llenarListas(10020, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 20 " );
        this.llenarListas(10030, this.servicio.rBD() + ".traduccion_when", " WHERE idioma = " + this.servicio.rUsuario().idioma + " AND campo = 30 " );
      
      }
      this.bot1Sel = false;
      this.bot2Sel = false;
      this.bot3Sel = false;
      this.bot4Sel = false;
      this.bot5Sel = false;
      this.bot6Sel = false;
      this.bot7Sel = false;
      this.bot3 = true;
      this.bot4 = true;
      this.bot5 = false;
      this.bot6 = false;
      this.bot7 = false;
      this.editando = true;
      this.faltaMensaje = "No se han guardado los cambios..."
      setTimeout(() => {
        if (this.miSeleccion < 17 || this.miSeleccion == 21 || this.miSeleccion == 25 || this.miSeleccion == 27 || this.miSeleccion >= 28)
        {
          if (this.txtNombre)
          {
            this.txtNombre.nativeElement.focus();
          }  
        }
        else
        {
          if (this.lstC0)
          {
            if (this.vista17== 1)
            {
              this.txtT1.nativeElement.focus();
            }
            else
            {
              this.lstC0.focus();
            }
          }
        }
        
        this.animando = true;       
      }, 400);
}


  edicionCancelada()
  {
    let mensajeCompleto: any = [];
    mensajeCompleto.clase = "snack-normal";
    mensajeCompleto.mensaje = "La edición ha sido cancelado por el usuario";
    mensajeCompleto.tiempo = 2000;
    this.servicio.mensajeToast.emit(mensajeCompleto);
  }

  cancelar()
  {
    if (this.bot4 && this.modelo == 4)
    {
      this.bot4Sel = false;
      this.edicionCancelada();              
      this.despuesBusqueda = 0;
      if (this.detalle.id == 0)
      {
        this.inicializarPantalla();
        return;
      }
      else
      {
        this.editar(-1)
      }
    }
  }

  inicializarPantalla()
  {
    this.editando = false;
    this.detalle = [];
    this.detalle.admin = 'N';
    this.detalle.id = 0;
    this.error01 = false;
    this.error02 = false;
    this.error03 = false;
    this.error04 = false;
    this.error05 = false;
    this.error06 = false;
    this.error07 = false;
    this.error08 = false;
    this.error09 = false;
    this.error10 = false;
    this.error20 = false;
    this.error21 = false;
    this.error22 = false;
    this.error23 = false;
    this.error24 = false;
    this.error25 = false;
    this.error30 = false;
    this.error31 = false;
    this.error32 = false;
    this.error33 = false;
    this.error34 = false;
    this.error35 = false;
    this.faltaMensaje = "";
    //
      
    this.detalle.nombre = "";
      this.detalle.referencia = "";
      this.detalle.notas = "";
      this.detalle.imagen = "";
      this.detalle.nombre = "";
      //
      this.detalle.linea = "0";
      this.detalle.maquina = "0";
      this.detalle.area = "0";
      this.detalle.telefonos = "";
      this.detalle.mmcall = "";
      this.detalle.correos = "";
      //
      this.detalle.agrupador_1 = "0";
      this.detalle.agrupador_2 = "0";
      this.detalle.tipo = "0";
      this.mostrarImagenRegistro = "S";
      this.mensajeImagen = "Campo opcional"
      this.detalle.imagen = "";
      this.detalle.url_mmcall = "";
      this.detalle.estatus = "A";
      this.detalle.id = 0;
      this.detalle.creado = "";
      this.detalle.modificado = "";
      this.detalle.modificacion = null;
      this.detalle.creacion = null;
    //
    this.detalle.referencia = "";
    this.detalle.disponibilidad = "0";
    this.detalle.nombre = "";
    this.detalle.inicia = this.servicio.fecha(1, "", "HH") + ":00:00";
    this.detalle.termina = this.servicio.fecha(1, "", "HH") + ":59:00";
    this.detalle.cambiodia = "N";
    this.detalle.especial = "N";
    this.detalle.tipo = "0";
    this.detalle.mover = "0";
      
    this.cancelarEdicion = false;
    this.mostrarImagenRegistro = "S";
    this.editando = false;
    this.detalle.estatus = "A"
    this.bot1Sel = false;
    this.bot2Sel = false;
    this.bot3Sel = false;
    this.bot4Sel = false;
    this.bot5Sel = false;
    this.bot6Sel = false;
    this.bot7Sel = false;
    this.bot3 = false;
    this.bot4 = false;
    this.bot5 = false;
    this.bot6 = false;
    this.bot7 = false;
    if (this.miSeleccion==12)
    {
      this.detalle.area = "S";
      this.detalle.maquina = "S";
      this.detalle.operacion = "S";
      this.detalle.mapa = "S";
      this.detalle.linea = "S";
      this.detalle.plantas = "S";
      this.detalle.idioma = 0;
      this.detalle.planta_defecto = 0;
      this.asociarTablas(0);
    }
    else if (this.miSeleccion==4)
    {
      this.detalle.area = "S";
      this.detalle.maquina = "S";
      this.detalle.linea = "S";
      this.asociarTablasFalla(0);
    
    }
    else if (this.miSeleccion==25)
    {
      this.detalle.maquinas = "S";
      this.asociarTablasHerramental(0);
    
    }
    else if (this.miSeleccion==28)
    {
      this.detalle.maquinas = "S";
      this.asociarVariablesMaquinas(0);
      this.asociarValores(0);
    }
    else if (this.miSeleccion==17)
    {
      this.piezasAntes = 0;
      this.equipoAntes = -1;
      if (this.vista17==0)
      {
        this.detalle.equipo = "-1";
        this.detalle.parte = "-1";
        this.detalle.tiempo = "0";
        this.detalle.piezas = 0;
        this.detalle.alta = 0;
        this.detalle.baja = 0;
        this.detalle.unidad = "";
      
      }
      else
      {
        this.detalle.equipo = "-1";
        this.detalle.parte = "N";
        this.detalle.tiempo = "0";
        this.detalle.piezas = 0;
        this.detalle.alta = 0;
        this.detalle.baja = 0;
        this.detalle.unidad = "";
      }  
    
    }
    else if (this.miSeleccion==18)
    {
      this.detalle.parte = "-1";
      this.detalle.equipo = "-1";
      this.detalle.turno = "-1";
      this.detalle.lote = "-1";
      this.detalle.objetivo = "0";
      this.detalle.fijo = "S";
      this.detalle.desde = "";
      this.detalle.hasta = "";
      this.detalle.reinicio = "0";
    }

    else if (this.miSeleccion==19)
    {
      this.detalle.linea = "-1";
      this.detalle.equipo = "-1";
      this.detalle.oee = "0";
      this.detalle.dis = "0";
      this.detalle.ftq = "0";
      this.detalle.efi = "0";
      this.detalle.fijo = "S";
      this.detalle.desde = "";
      this.detalle.hasta = "";
    }
    else if (this.miSeleccion==20)
    {
      this.detalle.equipo = "-1";
      this.detalle.multiplicador = "1";
      this.detalle.base = "0";
      this.detalle.tipo = "0";
      this.detalle.clasificacion = "0";
      this.detalle.area = "0";
    }
    else if (this.miSeleccion==21)
    {
      this.detalle.maquinas = "S";
      this.llenarListas(4, this.servicio.rBD() + ".cat_maquinas", "");
      this.detalle.tipo = "0";
      this.detalle.estado = "P";
      this.detalle.area = "";
      this.detalle.paro = "";
      this.detalle.clase = 0;
      this.detalle.finaliza_sensor = "S";
      this.detalle.desde = "00:00:00";
      this.detalle.hasta = "23:59:59";
      this.detalle.fdesde = new Date();
      this.detalle.fhasta = new Date();
    }
    else if (this.miSeleccion == 27) 
      {
        this.detalle.campos = ";;;;";
        this.detalle.nuevo = true;
        this.detalle.parte = "0";
        this.detalle.turno = "0";
        this.detalle.equipo = "0";
        this.detalle.lote = "0";
        this.detalle.orden = "";
        this.detalle.tipo = "0";
        this.detalle.area = "0";
        this.detalle.rechazo = "";
        this.detalle.notas = "";
        this.detalle.origen = "1";
        this.corteActual = 0;
        this.detalle.cantidad = 0;
        this.cantidadActual = 0;
        this.detalle.fecha = new Date();
      }
      else if (this.miSeleccion == 30) 
      {
        this.detalle.frecuencia = "T";
        this.detalle.fdesde = "";
        this.detalle.desde = "";
        this.detalle.checklists = "S";
        this.detalle.anticipacion = "N";
        this.detalle.tiempo = 0;
      }
      else if(this.miSeleccion == 8)
      {
        this.detalle.evento = "0";
        this.detalle.linea = "S";
        this.detalle.falla = "S";
        this.detalle.proceso = "S";
        this.detalle.maquina = "S";
        this.detalle.area = "S";     
        this.asociarTablasAlerta(0);
        this.detalle.escalar1 = "N";
        this.detalle.escalar2 = "N";
        this.detalle.escalar3 = "N";
        this.detalle.escalar4 = "N";
        this.detalle.escalar5 = "N";
      }
    setTimeout(() => {
        this.txtNombre.nativeElement.focus();
    }, 300);
  }

  copiar()
  {
    if (this.miSeleccion == 21 && this.detalle.estado =='C')
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "Este paro NO se puede copiar", tiempo: 0, mensaje: "El paro que desea copiar está en curso", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "", icono2: "", boton3STR: "", icono3: "", icono0: "i_falla" }
      });
      return;
    }
    if (this.bot5)
    {
      if (this.editando && !this.cancelarEdicion)
      {
        this.deshacerEdicion(0, 3)
        return;
      } 
      
      this.despuesBusqueda = 1;
      this.editar(-1);
      this.yaValidado = -1;
      
    } 
  }

  deshacerEdicion(parametro: number, desde: number)
  {
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "520px", panelClass: 'dialogo', data: { titulo: "Registro no guardado", tiempo: 0, mensaje: "Ha efectuado cambios en el registro que no se han guardado. <br><br><strong>¿Qué desea hacer?</strong>", alto: "60", id: 0, accion: 0, botones: 3, boton1STR: "Guardar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_guardar" }
    });
    respuesta.afterClosed().subscribe(result => {
      if (result.accion == 1) 
      {
        this.cancelarEdicion = true;
        this.guardar();     
        if (desde == 99)
        {
          this.volver()
          //this.procesarPantalla(parametro)
        }
        else if (desde == 2)
        {
          this.nuevo_siguiente();
        }
        else if (desde == 3)
        {
          this.despuesBusqueda = 1;
          this.editar(-1);
        }
      }
      else if (result.accion == 2) 
      {
        this.cancelarEdicion = true;
        this.edicionCancelada();      
        if (desde == 99)
        {
          this.volver()
          //this.procesarPantalla(parametro)
        }
        else if (desde == 2)
        {
          this.nuevo_siguiente();
        }
        else if (desde == 3)
        {
          this.despuesBusqueda = 1;
          this.editar(-1);
        }
      }
    });
  }

  llenarListas(arreglo: number, nTabla: string, cadWhere: string)
  {
    let sentencia = "SELECT id, nombre FROM " + nTabla + " " + cadWhere + " ORDER BY nombre";
    if (arreglo == 15 || arreglo == 115)
    {
      sentencia = "SELECT a.id, IF(ISNULL(a.referencia), a.nombre, CONCAT(a.nombre, ' (Ref: ', a.referencia, ')')) AS nombre FROM " + this.servicio.rBD() + ".cat_partes a " + cadWhere  + " ORDER BY a.nombre ";
    }
    else if (arreglo == 31)
    {
      sentencia = "SELECT alerta, nombre FROM " + nTabla + " " + cadWhere + " ORDER BY nombre";
    }
    else if (arreglo == 16 || arreglo == 4 || arreglo == 104 || arreglo == 20)
    {
      sentencia = "SELECT a.id, IF(ISNULL(b.nombre), a.nombre, CONCAT(a.nombre, ' / ', b.nombre)) AS nombre FROM " + nTabla + " a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas b ON a.linea = b.id " + cadWhere + " ORDER BY nombre";
    }
    else if (arreglo == 17 || arreglo == 117)
    {
      sentencia = "SELECT a.id, CONCAT(a.numero, ' / ', c.nombre) AS nombre FROM " + this.servicio.rBD() + ".lotes a LEFT JOIN " + this.servicio.rBD() + ".cat_partes c ON a.parte = c.id " + cadWhere  + " ORDER BY a.numero ";
    }
    else if (arreglo > 10000)
    {
      sentencia = "SELECT id, nombre FROM " + nTabla + " " + cadWhere + " ORDER BY orden";
    }
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if ((arreglo != 7 && arreglo!= 9 && arreglo < 15) ||  arreglo == 30 ||  arreglo == 22 ||  arreglo == 1110 ||  arreglo == 1115 ||  arreglo == 1120 || arreglo == 107 || arreglo == 93)
      {
        resp.splice(0, 0, {id: "0", nombre: "(NO ASOCIADA)"});  
      }
      else if (arreglo == 105)
      {
        resp.splice(0, 0, {id: "0", nombre: "(NO ASOCIADO)"});  
      }
      else if (arreglo == 16 || arreglo == 19)
      {
        resp.splice(0, 0, {id: "0", nombre: "(CUALQUIERA)"});  
      }
      else if (arreglo == 15 || (arreglo >= 17 && arreglo <= 19))
      {
        resp.splice(0, 0, {id: "0", nombre: "(CUALQUIER)"});  
      }
      if (arreglo == 1)
      {
        this.agrupadores1 = resp
      }
      else if (arreglo == 2)
      {
        this.agrupadores2 = resp
      }
      else if (arreglo == 3 || arreglo == 19)
      {
        this.lineas = resp
      }
      else if (arreglo == 4 || arreglo == 104 || arreglo == 16 || arreglo == 20)
      {
        this.maquinas = resp
      }
      else if (arreglo == 5 || arreglo == 23)
      {
        this.areas = resp
      }
      else if (arreglo == 6 || arreglo == 106 || arreglo == 107 || arreglo == 1115)
      {
        this.tipos = resp
      }
      else if (arreglo == 7)
      {
        this.tablas = resp
      }
      else if (arreglo == 8)
      {
        this.fallas = resp
      }
      else if (arreglo == 9)
      {
        this.listas = resp
      }
      else if (arreglo == 93)
      {
        this.listas = resp
      }
      else if (arreglo == 10)
      {
        this.listas = resp
      }
      else if (arreglo == 105)
      {
        this.idiomas = resp
      }
      else if (arreglo == 11 || arreglo == 1110 || arreglo == 1120)
      {
        this.fallas = resp
      }
      else if (arreglo == 12 || arreglo == 32)
      {
        this.tipos = resp
      }
      else if (arreglo == 13)
      {
        this.tablas = resp
      }
      else if (arreglo == 14 || arreglo == 18 || arreglo == 118)
      {
        this.turnos = resp
      }
      else if (arreglo == 15 || arreglo == 115)
      {
        this.partes = resp
      }
      else if (arreglo == 17 || arreglo == 117)
      {
        this.lotes = resp
      }
      else if (arreglo == 21)
      {
        this.paros = resp
      }
      else if (arreglo == 22)
      {
        this.usuarios = resp
      }
      else if (arreglo == 30)
      {
        this.procesos = resp
      }
      else if (arreglo == 31)
      {
        this.eventos = resp
      }
      else if (arreglo == 10010 || arreglo == 10140  || arreglo == 10150)
      {
        this.wFechas = resp
      }
      else if (arreglo == 10020)
      {
        this.wHorarios = resp
      }
      else if (arreglo == 10030)
      {
        this.wPeriodos = resp
      }
      else if (arreglo == 10100)
      {
        this.wEstatus = resp
      }
      else if (arreglo == 10110)
      {
        this.wSINO = resp
      }
      else if (arreglo == 10120)
      {
        this.wSINO2 = resp
      }
      else if (arreglo == 10130)
      {
        this.wUso = resp
      }
    }, 
    error => 
      {
        console.log(error)
      })
  }

  actualizar()
  {
    this.textoBuscar = "";
    this.modelo = this.modelo == 3 ? 13 : 12;
    this.rRegistros(this.miSeleccion);
  }

  adecuar()
  {
    this.verTabla = false;
    if (this.miSeleccion == 1)
    {
      this.titulos = ["", "1.1. Nombre de la línea", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.4. Notas explicativas", "1.5. Foto asociada a la línea", "1.8. Estatus del registro", "1.9. Fecha de creación", "1.10 Fecha de la última actualización", "1.11. Usuario que creó el registro", "1.12. Usuario que modificó el registro", "1.13 ID del registro", "1.12", "1.6. Agrupador de líneas (1)", "1.7. Agrupador de líneas (2)" ];
      this.ayudas = ["", "Especifique el nombre o la descripción de la línea", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la línea (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la línea (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique la línea asociada" ];
    }
    else if (this.miSeleccion == 2)
    {
      this.titulos = ["", "1.1. Nombre de la máquina", "1.3. Referencia", "1.4. Dirección(es) para el web-service de MMCall.", "1.5. Notas explicativas", "1.6. Foto asociada a la máquina", "1.24. Estatus del registro", "1.26. Fecha de creación", "1.27. Fecha de la última actualización", "1.28. Usuario que creó el registro", "1.29. Usuario que modificó el registro", "1.30. ID del registro", "1.13", "1.8. Agrupador de máquinas (1)", "1.9. Agrupador de máquinas (2)", "1.7. Tipo de máquina", "1.16", "1.17", "1.18", "1.19", "1.2. Línea asociada" ];
      this.ayudas = ["", "Especifique el nombre o la descripción de la máquina", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la máquina (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la máquina (esto servirá para consultas, reportes y gráficas)", "Especifique el tipo de máquina, si aplica", "16", "17", "18", "19", "Especifique la línea asociada" ];
    }
    else if (this.miSeleccion == 3)
    {
      this.titulos = ["", "1.1. Nombre del área", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.4. Notas explicativas", "1.5. Foto asociada al área", "1.10. Estatus del registro", "1.11. Fecha de creación", "1.12. Fecha de la última actualización", "1.13. Usuario que creó el registro", "1.14. Usuario que modificó el registro", "1.15. ID del registro", "12", "1.6. Agrupador de áreas (1)", "1.7. Agrupador de áreas (2)",,,,,,,,,,,,,,,,,,,,,,,"1.8. ANDON afecta OAE" ];
      this.ayudas = ["", "Especifique el nombre o la descripción del área", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para el área (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para el área (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique la línea asociada",,,,,,,,,,,,,,,,,"Indique si los reportes ANDON abiertos asociados a esta área afectan OAE",7,8,9,10 ];
    }
    else if (this.miSeleccion == 28)
    {
      this.titulos = ["", "1.1. Nombre de la variable", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.4. Notas explicativas", "1.5. Foto asociada a la variable", "1.11. Estatus del registro", "1.12. Fecha de creación", "1.13. Fecha de la última actualización", "1.14. Usuario que creó el registro", "1.15. Usuario que modificó el registro", "1.16. ID del registro", "12", "1.6. Agrupador de áreas (1)", "1.7. Agrupador de áreas (2)",,,,,,,,,,,,,,,,,,,,,,,"1.8. ANDON afecta OAE" ];
      this.ayudas = ["", "Especifique el nombre o la descripción de la variable", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para el área (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para el área (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique la línea asociada",,,,,,,,,,,,,,,,,"Indique si los reportes ANDON abiertos asociados a esta área afectan OAE",7,8,9,10 ];
    }
    else if (this.miSeleccion == 29)
    {
      this.titulos = ["", "1.1. Nombre del checklist", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.4. Notas explicativas", "1.5. Foto asociada al checklist", "1.11. Estatus del registro", "1.12. Fecha de creación", "1.13. Fecha de la última actualización", "1.14. Usuario que creó el registro", "1.15. Usuario que modificó el registro", "1.16. ID del registro", "12", "1.6. Agrupador de áreas (1)", "1.7. Agrupador de áreas (2)",,,,,,,,,,,,,,,,,,,,,,,"1.8. ANDON afecta OAE" ];
      this.ayudas = ["", "Especifique el nombre o la descripción del checklist", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para el área (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para el área (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique la línea asociada",,,,,,,,,,,,,,,,,"Indique si los reportes ANDON abiertos asociados a esta área afectan OAE",7,8,9,10 ];
    }
    else if (this.miSeleccion == 30)
    {
      this.titulos = ["", "1. Nombre del plan", "2. Referencia", "3. Notas explicativas", "3. Notas explicativas", "4. Foto asociada al plan", "11. Estatus del registro", "12. Fecha de creación", "13. Fecha de la última actualización", "14. Usuario que creó el registro", "15. Usuario que modificó el registro", "16. ID del registro", "12", "9. Agrupador de fallas (1)", "10. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada", "2. Tabla asociada", "2. Número(s) de Teléfono", "3. Dirección(es) de correo", "4. Web services de MMCall ", "2. Lista de direcciones de correo a donde se enviará el reporte", "3. Lista de direcciones de correo a quienes se les copiará el reporte", "4. Lista de direcciones de correo a quiene se les copiará de forma oculta el reporte", "5. Título que llevará el correo", "6. Texto que se escribirá en el cuerpo del correo ", "7. Marque el reporte o los reportes que se enviarán en este correo", "8. Período a recorrer para la extracción de los datos", "9. Frecuencia de envío del reporte", "10. Hora de envío", "11. Fecha del último envío"   ];
      this.ayudas = ["", "Especifique el nombre del correo/reporte", "Referencia para otros sistemas", "", "", "", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área", "Indique la tabla asociada a este registro", "Especifique los números de teléfono a los cuales se llamará o se enviarán SMS. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo a los cuales se les enviará un correo. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de web service a los cuales se les enviará un mensaje de MMCall. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo electrónico a quienes llegará el reporte. Separe con punto y coma en caso de haber más de una.", "Separe con punto y coma en caso de haber más de una.", "Separe con punto y coma en caso de haber más de una.", "Especifique el texto que aparecerá como título del correo", "Especifique el texto que aparecerá como cuerpo del correo", "Seleccione el o los reportes que serán adjuntados al correo", "Período de tiempo que la aplicación consultará para producir el reporte", "Frecuencia de envío del reporte", "Hora del día en que se enviará el reporte"    ];
    }
    else if (this.miSeleccion == 4)
    {
      this.titulos = ["", "1.1. Nombre de la falla", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.4. Notas explicativas", "1.5. Foto asociada a la falla", "1.10. Estatus del registro", "1.11. Fecha de creación", "1.12. Fecha de la última actualización", "1.13. Usuario que creó el registro", "1.14. Usuario que modificó el registro", "1.15. ID del registro", "1.8. Código único para ANDON directo", "1.6. Agrupador de fallas (1)", "1.7. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada","1","2","3","4","5","6","7","8","9","10","1.9. ANDON afecta OAE","d1","d2","d3","1.9. ANDON afecta OAE","d5","d6","10"  ];
      this.ayudas = ["", "Especifique el nombre o la descripción de la falla", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","Especifique el código quse usará para el ANDON directo", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área",,,,,,,,,,,,,,,"Indique si los reportes ANDON abiertos asociados a esta falla afectan OAE" ];
    }
    else if (this.miSeleccion == 25)
    {
      this.titulos = ["", "1.1. Nombre del Número de parte", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.3. Notas explicativas", "1.4. Foto asociada al Número de parte", "1.8. Estatus del registro", "1.9. Fecha de creación", "1.10. Fecha de la última actualización", "1.11. Usuario que creó el registro", "1.12. Usuario que modificó el registro", "1.13. ID del registro", "1.8. Código único para ANDON directo", "1.6. Agrupador de fallas (1)", "1.7. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "1.5. Máquinas asociada", "4. Área asociada","1","2","3","4","5","6","7","8","9","10","1.9. ANDON afecta OAE","d1","d2","d3","1.9. ANDON afecta OAE","d5","d6","10"  ];
      this.ayudas = ["", "Especifique el nombre o la descripción del Número de parte", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","Especifique el código quse usará para el ANDON directo", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área",,,,,,,,,,,,,,,"Indique si los reportes ANDON abiertos asociados a esta falla afectan OAE" ];
    }
    else if (this.miSeleccion == 5)
    {
      this.titulos = ["", "1. Descripción del registro", "2. Tabla asociada", "3. URL de MMCall", "4", "85", "5. Estatus del registro", "6. Fecha de creación", "7. Fecha de la última actualización", "8. Usuario que creó el registro", "9. Usuario que modificó el registro", "10. ID del registro", "12", "9. Agrupador de fallas (1)", "10. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada", "2. Tabla asociada", "3. Dirección(es) para el web-service de MMCall.", "4. Habilitar en la pantalla de Paro manual." ];
      this.ayudas = ["", "Especifique la descripción del registro", "Tabla asociada al registro", "", "", "", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área", "Indique la tabla asociada a este registro", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Especifique si este concepto de paro se habilita en la pantalla de Paro manual" ];
    }
    else if (this.miSeleccion == 6)
    {
      this.titulos = ["", "1. Nombre del recipiente", "6. Referencia", "3", "4", "85", "7. Estatus del registro", "8. Fecha de creación", "9. Fecha de la última actualización", "10. Usuario que creó el registro", "11. Usuario que modificó el registro", "12. ID del registro", "12", "9. Agrupador de fallas (1)", "10. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada", "2. Tabla asociada", "2. Número(s) de Teléfono", "4. Dirección(es) de correo", "5. Web services de MMCall " ];
      this.ayudas = ["", "Especifique el nombre del recipiente", "Referencia para otros sistemas", "", "", "", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área", "Indique la tabla asociada a este registro", "Especifique los números de teléfono a los cuales se llamará o se enviarán SMS. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo a los cuales se les enviará un correo. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de web service a los cuales se les enviará un mensaje de MMCall. Separe con punto y coma en caso de haber más de uno." ];
    }
    else if (this.miSeleccion == 7)
    {
      this.titulos = ["", "1. Nombre del correo/reporte", "5. Referencia", "3", "4", "85", "12. Estatus del registro", "13. Fecha de creación", "14. Fecha de la última actualización", "15. Usuario que creó el registro", "16. Usuario que modificó el registro", "17. ID del registro", "12", "9. Agrupador de fallas (1)", "10. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada", "2. Tabla asociada", "2. Número(s) de Teléfono", "3. Dirección(es) de correo", "4. Web services de MMCall ", "2. Lista de direcciones de correo a donde se enviará el reporte", "3. Lista de direcciones de correo a quienes se les copiará el reporte", "4. Lista de direcciones de correo a quiene se les copiará de forma oculta el reporte", "5. Título que llevará el correo", "6. Texto que se escribirá en el cuerpo del correo ", "7. Marque el reporte o los reportes que se enviarán en este correo", "8. Período a recorrer para la extracción de los datos", "9. Frecuencia de envío del reporte", "10. Hora de envío", "11. Fecha del último envío"   ];
      this.ayudas = ["", "Especifique el nombre del correo/reporte", "Referencia para otros sistemas", "", "", "", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área", "Indique la tabla asociada a este registro", "Especifique los números de teléfono a los cuales se llamará o se enviarán SMS. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo a los cuales se les enviará un correo. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de web service a los cuales se les enviará un mensaje de MMCall. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo electrónico a quienes llegará el reporte. Separe con punto y coma en caso de haber más de una.", "Separe con punto y coma en caso de haber más de una.", "Separe con punto y coma en caso de haber más de una.", "Especifique el texto que aparecerá como título del correo", "Especifique el texto que aparecerá como cuerpo del correo", "Seleccione el o los reportes que serán adjuntados al correo", "Período de tiempo que la aplicación consultará para producir el reporte", "Frecuencia de envío del reporte", "Hora del día en que se enviará el reporte"    ];
    }
    else if (this.miSeleccion == 8)
    {
      this.titulos = ["", "1. Nombre del recipiente", "5. Referencia", "3", "4", "85", "23. Estatus del registro", "12. Fecha de creación", "13. Fecha de la última actualización", "14. Usuario que creó el registro", "15. Usuario que modificó el registro", "16. ID del registro", "12", "9. Agrupador de fallas (1)", "10. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada", "2. Tabla asociada", "2. Número(s) de Teléfono", "3. Dirección(es) de correo", "4. Web services de MMCall " ];
      this.ayudas = ["", "Especifique el nombre del recipiente", "Referencia para otros sistemas", "", "", "", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área", "Indique la tabla asociada a este registro", "Especifique los números de teléfono a los cuales se llamará o se enviarán SMS. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo a los cuales se les enviará un correo. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de web service a los cuales se les enviará un mensaje de MMCall. Separe con punto y coma en caso de haber más de uno." ];
    }
    else if (this.miSeleccion == 9)
    {
      this.titulos = ["", "1. Nombre del turno", "9. Referencia", "3", "4", "85", "10. Estatus del registro", "11. Fecha de creación", "12. Fecha de la última actualización", "13. Usuario que creó el registro", "14. Usuario que modificó el registro", "14. I5 del registro", "12", "9. Agrupador de fallas (1)", "10. Agrupador de fallas (2)", "15", "16", "17", "18", "19", "2. Línea asociada", "3. Máquina asociada", "4. Área asociada", "2. Tabla asociada", "2. Número(s) de Teléfono", "3. Dirección(es) de correo", "4. Web services de MMCall " ];
      this.ayudas = ["", "Especifique el nombre del turno", "Referencia para otros sistemas", "", "", "", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la falla (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique si la falla sólo se ocupa en una línea", "Especifique si la falla sólo se ocupa en una máquina", "Especifique si la falla sólo se atiende por un área", "Indique la tabla asociada a este registro", "Especifique los números de teléfono a los cuales se llamará o se enviarán SMS. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de correo a los cuales se les enviará un correo. Separe con punto y coma en caso de haber más de uno.", "Especifique las dirección(es) de web service a los cuales se les enviará un mensaje de MMCall. Separe con punto y coma en caso de haber más de uno." ];
    }
    else if (this.miSeleccion == 12)
    {
      this.titulos = ["", "1.1. Nombre del usuario", "1.2. Perfil de usuario", "1.3. Rol del usuario dentro de la aplicación.", "1.4. Notas explicativas", "1.5. Foto asociada al usuario", "1.12 Estatus del registro", "1.13. Fecha de creación", "1.14 Fecha de la última actualización", "1.15 Usuario que creó el registro", "1.16 Usuario que modificó el registro", "1.17 ID del registro", "1.13", "1.6. Política de seguridad", "3.1 Líneas/Células", "3.2 Máquinas", "3.3 Áreas", "1.17", "1.7 Compañía (contable) dónde labora el usuario", "1.8 Departamento dónde labora el usuario", "1.9 Planta dónde labora el usuario", "1.10 Turno FIJO asociado", "1.11. Idioma del usuario" ];
      this.ayudas = ["", "Especifique el nombre del usuario", "Perfil de usuario para iniciar sesión", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Política de contraseña asociada al usuario", "Especifique la línea/célula que el usuario podrá acceder en la aplicación", "Especifique la máquina que el usuario podrá acceder en la aplicación", "Especifique el área que el usuario podrá acceder en la aplicación", "16", "Compañía a la que pertenece el usuario", "Departamento a la que pertenece el usuario", "Planta a la que pertenece el usuario", "Especifique el turno para FIJO para este usuario", "Especifique el idioma que utilizará la aplicación para este usuario" ];
    }

    else if (this.miSeleccion == 14)
    {
      this.titulos = ["", "1. Nombre de la política", "1.2. Referencia", "1.3. Rol del usuario dentro de la aplicación.", "1.4. Notas explicativas", "1.5. Foto asociada al usuario", "10. Estatus del registro", "11. Fecha de creación", "12. Fecha de la última actualización", "13. Usuario que creó el registro", "14. Usuario que modificó el registro", "15. ID del registro", "1.13", "1.6. Política de seguridad", "3.1 Líneas/Células", "3.2 Máquinas", "3.3 Áreas", "1.17", "1.7 Compañía a la que pertenece el usuario", "1.8 Departamento", "1.9 Planta asociada" ];
      this.ayudas = ["", "Especifique el nombre de la política", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Política de contraseña asociada al usuario", "Especifique la línea/célula que el usuario podrá acceder en la aplicación", "Especifique la máquina que el usuario podrá acceder en la aplicación", "Especifique el área que el usuario podrá acceder en la aplicaciónEspecifique el tipo de máquina, si aplica", "16", "Compañía a la que pertenece el usuario", "Departamento a la que pertenece el usuario", "Planta a la que pertenece el usuario", "Especifique la línea asociada" ];
    }


    //
    if (this.miSeleccion == 1)
    {
      this.titulos = ["", "1.1. Nombre de la linea/celula", "1.2. Referencia", "1.3. Dirección(es) para el web-service de MMCall.", "1.4. Notas explicativas", "1.5. Foto asociada a la línea", "1.8. Estatus del registro", "1.9. Fecha de creación", "1.10 Fecha de la última actualización", "1.11. Usuario que creó el registro", "1.12. Usuario que modificó el registro", "1.13 ID del registro", "1.12", "1.6. Agrupador de líneas (1)", "1.7. Agrupador de líneas (2)" ];
      this.ayudas = ["", "Especifique el nombre o la descripción la línea", "Referencia para otros sistemas", "Dirección(es) para el web-service de MMCall. Separe con punto y coma en caso de haber más de una", "Notas explicativas del registro", "Foto asociada al registro", "Al inactivar el registro ya no estará disponible en el sistema", "7", "8", "9", "10", "11","12", "Especifique el agrupador para la línea (esto servirá para consultas, reportes y gráficas)", "Especifique el agrupador para la línea (esto servirá para consultas, reportes y gráficas)", "15", "16", "17", "18", "19", "Especifique la línea asociada" ];
    }


  }

  inactivar()
  {
    if (this.miSeleccion == 21 && this.paroEnCurso)
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "Este paro NO se puede inactivar", tiempo: 0, mensaje: "El paro que desea inactivar está en curso o finalizado", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "", icono2: "", boton3STR: "", icono3: "", icono0: "i_falla" }
      });
      return;
    }
    let adicional: string = "";
    let mensajeEliminar = "Esta acción inactivará el registro seleccionado y no estará disponible en el sistema<br><br><strong>¿Desea continuar con la operación?</strong>";
    if (this.miSeleccion == 21)
    {
      mensajeEliminar = "Esta acción inactivará el paro seleccionado y su efecto en los gráficos de OAE<br><br><strong>¿Desea continuar con la operación?</strong>";
    }
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "520px", panelClass: 'dialogo_atencion', data: { titulo: "INACTIVAR REGISTRO", mensaje: mensajeEliminar, id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Inactivar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_inactivar" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result)
        {
          if (result.accion == 1) 
          {
            let sentencia = "UPDATE " + this.servicio.rBD() + ".cat_lineas SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET lineas = NOW();";
            if (this.miSeleccion == 2)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_maquinas SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET maquinas = NOW();";
            }
            else if (this.miSeleccion == 3)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_areas SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET areas = NOW();";
            }
            else if (this.miSeleccion == 28)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_variables SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET variables = NOW();";
            }
            else if (this.miSeleccion == 29)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_checklists SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET checklists = NOW();";
            }
            else if (this.miSeleccion == 4)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_fallas SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET fallas = NOW();";
            }
            else if (this.miSeleccion == 5)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_generales SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET generales = NOW();";
            }
            else if (this.miSeleccion == 6)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_distribucion SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET distribucion = NOW();";
            }
            else if (this.miSeleccion == 7)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_correos SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW() WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET correos = NOW();";
            }
            else if (this.miSeleccion == 8)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_alertas SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW()  WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET alertas = NOW();";
            }
            else if (this.miSeleccion == 9)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_turnos SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW()  WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET turnos = NOW();";
            }
            else if (this.miSeleccion == 12)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".cat_usuarios SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW()  WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET usuarios = NOW();";
            }
            else if (this.miSeleccion == 14)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".politicas SET estatus = 'I', modificado = " + this.servicio.rUsuario().id + ", modificacion = NOW()  WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".politicas SET usuarios = NOW();";
            }
            else if (this.miSeleccion == 21)
            {
              sentencia = "UPDATE " + this.servicio.rBD() + ".detalleparos SET estatus = 'I' WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET usuarios = NOW();";
            }
            let campos = {accion: 200, sentencia: sentencia};  
            this.servicio.consultasBD(campos).subscribe( resp =>
            {
              this.detalle.estatus = "I";
              this.bot6 = false;
              let mensajeCompleto: any = [];
              mensajeCompleto.clase = "snack-error";
              mensajeCompleto.mensaje = "El registro ha sido inactivado satisactoriamente";
              mensajeCompleto.tiempo = 2000;
              this.servicio.mensajeToast.emit(mensajeCompleto);
            })
          }
          else
          {
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "Acción cancelada por el usuario";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
          }
        }
        else
        {
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-error";
          mensajeCompleto.mensaje = "Acción cancelada por el usuario";
          mensajeCompleto.tiempo = 2000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      
    })
  }

  eliminar()
  {
    if (this.miSeleccion == 27 && this.detalle.existe==0)
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "Este rechazo NO se puede eliminar", tiempo: 0, mensaje: "Los rechazos generados desde la aplicación de OAE no se pueden eliminar del sistema", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "", icono2: "", boton3STR: "", icono3: "", icono0: "i_falla" }
      });
      return;
    }
    if (this.miSeleccion == 21 && this.paroEnCurso)
    {
      const respuesta = this.dialogo.open(DialogoComponent, {
        width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "Este paro NO se puede eliminar", tiempo: 0, mensaje: "El paro que desea eliminar está en curso o finalizado", alto: "60", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "", icono2: "", boton3STR: "", icono3: "", icono0: "i_falla" }
      });
      return;
    }
    let adicional: string = "";
    let mensajeEliminar = "Esta acción ELIMINARÁ PERMANENTEMENTE el registro seleccionado y no estará disponible<br><br><strong>¿Desea continuar con la operación?</strong>";
    if (this.miSeleccion == 21)
    {
      mensajeEliminar = "Esta acción ELIMINARÁ PERMANENTEMENTE el paro seleccionado y su efecto en los gráficos de OAE<br><br><strong>¿Desea continuar con la operación?</strong>";
    }
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "520px", panelClass: 'dialogo_atencion', data: { titulo: "ELIMINAR REGISTRO", mensaje: mensajeEliminar, id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Eliminar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_eliminar" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result)
        {
          if (result.accion == 1) 
          {
            let sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_lineas WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET lineas = NOW();";
            if (this.miSeleccion == 2)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_maquinas WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET maquinas = NOW();";
            }
            else if (this.miSeleccion == 3)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_areas WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET areas = NOW();";
            }
            else if (this.miSeleccion == 28)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_variables WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET variables = NOW();";
            }
            else if (this.miSeleccion == 29)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_checklists WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET checklists = NOW();";
            }
            else if (this.miSeleccion == 4)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_fallas WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET fallas = NOW();";
            }
            else if (this.miSeleccion == 5)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_generales WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET generales = NOW();";
            }
            else if (this.miSeleccion == 6)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_distribucion WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET distribucion = NOW();";
            }
            else if (this.miSeleccion == 7)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_correos WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET correos = NOW();";
            }
            else if (this.miSeleccion == 8)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_alertas WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET alertas = NOW();";
            }
            else if (this.miSeleccion == 9)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_turnos WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET turnos = NOW();";
            }
            else if (this.miSeleccion == 10)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".traduccion WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET traducciones = NOW();";
            }
            else if (this.miSeleccion == 12)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".cat_usuarios WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET usuarios = NOW();";
            }
            else if (this.miSeleccion == 14)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".politicas WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET politicas = NOW();";
            }
            else if (this.miSeleccion == 17)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET rates = NOW();";
              if (this.vista17 == 1)
              {
                sentencia = "DELETE FROM " + this.servicio.rBD() + ".relacion_partes_equipos WHERE equipo = " + +this.equipoAntes + " AND piezas = " + this.detalle.piezas + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET rates = NOW();";
              }
            }
            else if (this.miSeleccion == 18)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".equipos_objetivo WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET objetivos = NOW();";
            }
            else if (this.miSeleccion == 19)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".estimados WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET estimados = NOW();";
            }
            else if (this.miSeleccion == 20)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".relacion_procesos_sensores WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET sensores = NOW();";
            }
            else if (this.miSeleccion == 21)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".detalleparos WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET paros = NOW();";
            }
            else if (this.miSeleccion == 27)
            {
              sentencia = "DELETE FROM " + this.servicio.rBD() + ".detallerechazos WHERE id = " + +this.detalle.id + ";UPDATE " + this.servicio.rBD() + ".actualizaciones SET rechazos = NOW();";
              if (!this.detalle.origen || this.detalle.origen==0)
              {
                sentencia = sentencia + "UPDATE " + this.servicio.rBD() + ".lecturas_cortes SET calidad_clasificada = calidad_clasificada - " + (+this.detalle.cantidad - this.cantidadActual) + " WHERE id = " + this.detalle.corte;
              }
              else if (this.detalle.origen == 1)
              {
                sentencia = sentencia + "UPDATE " + this.servicio.rBD() + ".relacion_maquinas_lecturas SET calidad = calidad - " + +this.detalle.cantidad + ", calidad_tc = calidad_tc - " + +this.detalle.cantidad * this.rateEquipo + " WHERE corte = " + this.detalle.corte + ";UPDATE " + this.servicio.rBD() + ".lecturas_cortes SET calidad = calidad - " + +this.detalle.cantidad + ", calidad_tc = calidad_tc - " + +this.detalle.cantidad * this.rateEquipo + ", calidad_clasificada = calidad_clasificada - " + +this.detalle.cantidad + " WHERE id = " + this.detalle.corte
              }
            }
            let campos = {accion: 200, sentencia: sentencia};  
            this.servicio.consultasBD(campos).subscribe( resp =>
            {
              this.detalle.estatus = "I";
              let mensajeCompleto: any = [];
              mensajeCompleto.clase = "snack-error";
              mensajeCompleto.mensaje = "El registro ha sido eliminado satisactoriamente";
              mensajeCompleto.tiempo = 2000;
              this.servicio.mensajeToast.emit(mensajeCompleto);
              this.regresar();
            })
          }
          else
          {
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "Acción cancelada por el usuario";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
          }
        }
        else
        {
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-error";
          mensajeCompleto.mensaje = "Acción cancelada por el usuario";
          mensajeCompleto.tiempo = 2000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }
    })
  }

  exportar()
  {
    let nombreReporte = "catalogo_lineas.csv";
    let catalogo = "Catalogo de lineas";
    if (this.miSeleccion == 2)
    {
      nombreReporte = "catalogo_maquinas.csv";
      catalogo = "Catalogo de maquinas";
    }
    else if (this.miSeleccion == 3)
    {
      nombreReporte = "catalogo_areas.csv";
      catalogo = "Catalogo de areas";
    }
    else if (this.miSeleccion == 28)
    {
      nombreReporte = "catalogo_variables.csv";
      catalogo = "Catalogo de variables";
    }
    else if (this.miSeleccion == 29)
    {
      nombreReporte = "catalogo_clists.csv";
      catalogo = "Catalogo de checklists";
    }
    else if (this.miSeleccion == 4)
    {
      if (this.vezExportar == 0)
      {
        nombreReporte = "catalogo_fallas.csv";
        catalogo = "Catalogo de fallas";
      }
      else
      {
        nombreReporte = "relacion_fallas.csv";
        catalogo = "Relacion de fallas";
        this.vezExportar = 0;
      }
      
    }
    else if (this.miSeleccion == 5)
    {
      nombreReporte = "catalogo_generales.csv";
      catalogo = "Catalogo de registros generaless";
    }
    else if (this.miSeleccion == 6)
    {
      nombreReporte = "recipientes.csv";
      catalogo = "Catalogo de recipientes";
    }
    else if (this.miSeleccion == 7)
    {
      nombreReporte = "correos.csv";
      catalogo = "Catalogo de correos/reportes";
      
    }
    else if (this.miSeleccion == 8)
    {
      nombreReporte = "alertas.csv";
      catalogo = "Catalogo de alertas";
    }
    else if (this.miSeleccion == 9)
    {
      nombreReporte = "turnos.csv";
      catalogo = "Catalogo de turnos";
    }
    else if (this.miSeleccion == 10)
    {
      nombreReporte = "traducciones.csv";
      catalogo = "Catalogo de traducciones";
    }
    else if (this.miSeleccion == 14)
    {
      nombreReporte = "politicas.csv";
      catalogo = "Catalogo de politicas";
    }
    else if (this.miSeleccion == 12)
    {
      nombreReporte = "usuarios.csv";
      catalogo = "Catalogo de usuarios";
    }
    else if (this.miSeleccion == 17)
    {
      nombreReporte = "rates.csv";
      catalogo = "Catalogo de rates";
    }
    else if (this.miSeleccion == 18)
    {
      nombreReporte = "objetivos.csv";
      catalogo = "Catalogo de objetivos";
    }
    else if (this.miSeleccion == 19)
    {
      nombreReporte = "estimados.csv";
      catalogo = "Catalogo de estimados";
    }
    else if (this.miSeleccion == 20)
    {
      nombreReporte = "sensores.csv";
      catalogo = "Catalogo de sensores";
    }
    else if (this.miSeleccion == 21)
    {
      nombreReporte = "paros.csv";
      catalogo = "Paros";
    }
    
    let campos = {accion: 100, sentencia: this.sentenciaR};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {

        if (this.miSeleccion == 27)
        {
          resp.splice(0, 0, {a01: 'ID documento', a02: "ID registro sensor", a03: "Fecha de reporte", a04: 'Cantidad en piezas', a05: "Texto del rechazo", a06: "Notas del rechazo", a07: "Area asociada", a08: "ID del area", a09: "Equipo asociado", a10: "ID del equipo", a11: 'Linea asociada', a12: 'ID de la linea', a13: 'Clasificacion del rechazo', a14: 'ID de la clasificacion', a15: 'Numero de parte', a16: 'ID del numero de parte', a17: 'Turno asociado', a18: 'ID del turno', a19: 'Numero de lote', a20: 'ID del lote', a21: 'Facha de actualizacion', a22: 'Nombre del usuario que documento', a23: 'ID del usuario' })
          nombreReporte = "rechazos.csv";
          catalogo = "Rechazos";
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-normal";
          mensajeCompleto.mensaje = "En la exportación sólo se aplica el filtro por fecha...";
          mensajeCompleto.tiempo = 3000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }

        this.servicio.generarReporte(resp, catalogo, nombreReporte)
        if (this.vezExportar == 0 && this.miSeleccion==4)
        {
          this.vezExportar = 1;
          this.exportar();
        }
      }
    })
  }

  listarListados(id: number)
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.reporte), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".int_listados a LEFT JOIN " + this.servicio.rBD() + ".det_correo b ON a.id = b.reporte AND b.correo = " + id + " WHERE a.estatus = 'A' ORDER BY seleccionado DESC, a.orden;"
    this.listados = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      setTimeout(() => {
        this.listados = resp;  
      }, 200);
      
    });
  }

  asociarTablasHerramental(id: number)
  {
    let sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, IF(ISNULL(b.parte), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".relacion_partes_maquinas b ON a.id = b.maquina AND b.parte = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.maquinasSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.maquinasSel = resp;  
    });
  }

  asociarVariablesMaquinas(id: number)
  {
    let sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, IF(ISNULL(b.variable), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".relacion_variables_equipos b ON a.id = b.maquina AND b.variable = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, a.nombre"
    if (id == 0)
    {
      sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.maquinasSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.maquinasSel = resp;  
    });
  }

  asociarValores(id: number)
  {
    this.arreHover1 = [];
  
    let sentencia = "SELECT * FROM " + this.servicio.rBD() + ".variables_valores WHERE variable = " + id + " ORDER BY orden"
    this.opcionesSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      this.arreHover1.length = resp.length
      this.opcionesSel = resp;  
    });
  }

  asociarTablasFalla(id: number)
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".relacion_fallas_operaciones b ON a.id = b.proceso AND b.tipo = 1 AND b.falla = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.lineasSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.lineasSel = resp;  
      
    });
    sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".relacion_fallas_operaciones b ON a.id = b.proceso AND b.tipo = 2 AND b.falla = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.maquinasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.maquinasSel = resp;  
      
    });
    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".relacion_fallas_operaciones b ON a.id = b.proceso AND b.tipo = 3 AND b.falla = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.areasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.areasSel = resp;  
      
    });
    
  
  }

  asociarTablasAlerta(id: number)
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".relacion_alertas_operaciones b ON a.id = b.proceso AND b.tipo = 1 AND b.alerta = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.lineasSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.lineasSel = resp;  
      
    });
    sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".relacion_alertas_operaciones b ON a.id = b.proceso AND b.tipo = 2 AND b.alerta = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, IF(ISNULL(c.nombre), a.nombre, CONCAT(a.nombre, ' / ',  c.nombre)) AS nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.maquinasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.maquinasSel = resp;  
      
    });
    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".relacion_alertas_operaciones b ON a.id = b.proceso AND b.tipo = 3 AND b.alerta = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.areasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.areasSel = resp;  
      
    });

    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_fallas a LEFT JOIN " + this.servicio.rBD() + ".relacion_alertas_operaciones b ON a.id = b.proceso AND b.tipo = 4 AND b.alerta = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_fallas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.fallasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.fallasSel = resp;  
      
    });

    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_procesos a LEFT JOIN " + this.servicio.rBD() + ".relacion_alertas_operaciones b ON a.id = b.proceso AND b.alerta = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_procesos a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.areasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.operacionesSel = resp;  
      
    });
  
  }

  asociarTablas(id: number)
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_operaciones b ON a.id = b.proceso AND b.tipo = 1 AND b.usuario = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_lineas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.lineasSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.lineasSel = resp;  
      
    });
    sentencia = "SELECT a.id, a.nombre, c.nombre as nlinea, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_operaciones b ON a.id = b.proceso AND b.tipo = 2 AND b.usuario = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, c.nombre as nlinea, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.maquinasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.maquinasSel = resp;  
      
    });
    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_operaciones b ON a.id = b.proceso AND b.tipo = 3 AND b.usuario = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_areas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.areasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.areasSel = resp;  
      
    });

    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".mapas a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_operaciones b ON a.id = b.proceso AND b.tipo = 6 AND b.usuario = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".mapas a WHERE a.activo <> 9 ORDER BY a.nombre"
    }
    this.mapasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.mapasSel = resp;  
      
    });

    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_plantas a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_operaciones b ON a.id = b.proceso AND b.tipo = 4 AND b.usuario = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_plantas a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.plantasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.plantasSel = resp;  
      
    });

    sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.proceso), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_procesos a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_operaciones b ON a.id = b.proceso AND b.tipo = 0 AND b.usuario = " + id + " ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_procesos a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.areasSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.operacionesSel = resp;  
      
    });
    
    sentencia = "SELECT a.id, CASE WHEN a.rol ='*' THEN '(Todos los roles)' WHEN a.rol = 'A' THEN 'ADMINISTRADOR' WHEN a.rol = 'G' THEN 'Gestor de la aplicación' WHEN a.rol = 'S' THEN 'Supervisor' WHEN a.rol = 'T' THEN 'Técnico' WHEN a.rol = 'O' THEN 'Operador' END AS erol, a.nombre, IF(ISNULL(b.opcion), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones a LEFT JOIN " + this.servicio.rBD() + ".relacion_usuarios_opciones b ON a.id = b.opcion AND b.usuario = " + id + " WHERE a.visualizar = 'S' ORDER BY seleccionado DESC, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, CASE WHEN a.rol ='*' THEN '(Todos los roles)' WHEN a.rol = 'A' THEN 'ADMINISTRADOR' WHEN a.rol = 'G' THEN 'Gestor de la aplicación' WHEN a.rol = 'S' THEN 'Supervisor' WHEN a.rol = 'T' THEN 'Técnico' WHEN a.rol = 'O' THEN 'Operador' END AS erol, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones a WHERE a.visualizar = 'S' ORDER BY a.nombre"
    }
    this.opcionesSel = [];
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.opcionesSel = resp;  
      
    });

    
  }

  
  llenarVariables(id: number)
  {
    let sentencia = "SELECT a.*, b.orden, '' AS valor, IFNULL(c.nombre, '') AS unidad FROM " + this.servicio.rBD() + ".cat_variables a LEFT JOIN " + this.servicio.rBD() + ".det_checklist b ON a.id = b.variable AND b.checklist = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_generales c ON a.unidad = c.id ORDER BY b.orden, a.nombre"
    this.cVariables = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.cVariables = resp;  
      
    });
  }

  variables(id: number)
  {
    let cadAdicional = "";
    if (this.detalle.equipo != 0)
    {
      cadAdicional = " WHERE a.maquinas = 'S' OR (SELECT COUNT(*) FROM " + this.servicio.rBD() + ".relacion_variables_equipos WHERE variable = a.id AND maquina = " + this.detalle.equipo + ") > 0 "
    }
    let sentencia = "SELECT a.id, b.orden, a.nombre, IFNULL(c.nombre, '') AS unidad, IF(ISNULL(b.checklist), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_variables a LEFT JOIN " + this.servicio.rBD() + ".det_checklist b ON a.id = b.variable AND b.checklist = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_generales c ON a.unidad = c.id " + cadAdicional + " ORDER BY seleccionado DESC, b.orden, a.nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, 0 AS orden, a.nombre, IFNULL(c.nombre, '') AS unidad, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_variables a LEFT JOIN " + this.servicio.rBD() + ".cat_generales c ON a.unidad = c.id " + cadAdicional + " ORDER BY a.nombre"
    }
    this.opcionesSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        for (var i = 0; i < resp.length; i++) 
        {
          resp[i].orden = !resp[i].orden ? (i + 1) : resp[i].orden;
          resp[i].seleccionado = resp[i].seleccionado == 1;
        }
        this.opcionesSel = resp;  
      
    });
  }

  equiposVariables(id: number)
  {
    let sentencia = "SELECT a.id, IFNULL(c.nombre, a.nombre, CONCAT(a.nombre, ' / ', c.nombre)) AS nombre, IF(ISNULL(b.variable), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".relacion_variables_equipos b ON a.id = b.equipo AND b.variable = " + id + " LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id ORDER BY seleccionado DESC, nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, IFNULL(c.nombre, a.nombre, CONCAT(a.nombre, ' / ', c.nombre)) AS nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_maquinas a LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON a.linea = c.id WHERE a.estatus = 'A' ORDER BY nombre"
    }
    this.opcionesSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.opcionesSel = resp;  
      
    });
  }

  checklistPlan(id: number)
  {
    let sentencia = "SELECT a.id, a.nombre, IF(ISNULL(b.checklist), 0, 1) AS seleccionado FROM " + this.servicio.rBD() + ".cat_checklists a LEFT JOIN " + this.servicio.rBD() + ".det_plan_checklists b ON a.id = b.checklist AND b.plan = " + id + " ORDER BY seleccionado DESC, nombre"
    if (id==0)
    {
      sentencia = "SELECT a.id, a.nombre, 0 AS seleccionado FROM " + this.servicio.rBD() + ".cat_checklists a WHERE a.estatus = 'A' ORDER BY a.nombre"
    }
    this.opcionesSel = [];
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
        this.opcionesSel = resp;  
      
    });
  }

  modTabla(event: any)
  {
    if (event.value == 45)
    {
      if (this.detalle.url_mmcall == "")
      {
        this.detalle.url_mmcall = "N"
      }
    }
    else
    {
      if (this.detalle.url_mmcall = "N" || this.detalle.url_mmcall == "S")
      {
        this.detalle.url_mmcall = "";
      }
    }
  }

  seleccion(tipo: number, event: any) 
    {
      if (event.value == 1 || event.value == 0)
      {
        if (tipo == 0)
        {
          for (var i = 0; i < this.operacionesSel.length; i++) 
          {
            this.operacionesSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.operacion = "N";  
          }, 300);
        }
        if (tipo == 9)
        {
          for (var i = 0; i < this.plantasSel.length; i++) 
          {
            this.plantasSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.plantas = "N";  
          }, 300);
        }
        else if (tipo == 1)
        {
          for (var i = 0; i < this.lineasSel.length; i++) 
          {
            this.lineasSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.linea = "N";  
          }, 300);
        }
        else if (tipo == 11)
        {
          for (var i = 0; i < this.mapasSel.length; i++) 
          {
            this.mapasSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.mapa = "N";  
          }, 300);
        }
        else if (tipo == 6)
        {
          for (var i = 0; i < this.listados.length; i++) 
          {
            this.listados[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.selListadoT = "N";  
          }, 300);
        }
        else if (tipo == 2)
        {
          for (var i = 0; i < this.maquinasSel.length; i++) 
          {
            this.maquinasSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.maquinas = "N";
            if (this.miSeleccion==4 || this.miSeleccion==12 || this.miSeleccion==8)
            {
              this.detalle.maquina = "N";
            }
              
          }, 300);
        }
        else if (tipo == 13)
        {
          for (var i = 0; i < this.partesSel.length; i++) 
          {
            this.partesSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.parte = "N";  
          }, 300);
        }
        else if (tipo == 3)
        {
          for (var i = 0; i < this.areasSel.length; i++) 
          {
            this.areasSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.area = "N";  
          }, 300);
        }
        else if (tipo == 4)
        {
          for (var i = 0; i < this.opcionesSel.length; i++) 
          {
            this.opcionesSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.opciones = "N";  
          }, 300);
        }
        else if (tipo == 7)
        {
          for (var i = 0; i < this.fallasSel.length; i++) 
          {
            this.fallasSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.area = "N";  
          }, 300);
        }
  
        else if (tipo == 8)
        {
          for (var i = 0; i < this.opcionesSel.length; i++) 
          {
            this.opcionesSel[i].seleccionado = event.value == 1;
          }
          setTimeout(() => {
            this.detalle.variables = "N";  
          }, 1000);
        }
        else if (tipo == 10)
        {
          for (var i = 0; i < this.opcionesSel.length; i++) 
          {
            this.opcionesSel[i].seleccionado = event.value;
          }
          setTimeout(() => {
            this.detalle.checklists = "N";  
          }, 300);
        }
      }
      
      else if (tipo == 5)
      {
        let sentencia = ""
        if (event.value == "A") 
        {
          sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, 1 AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
        }
        else if (event.value == "G") 
        {
          sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'G' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
        }
        else if (event.value == "S") 
        {
          sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'S' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
        }
        else if (event.value == "T") 
        {
          sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'T' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
        }
        else if (event.value == "O") 
        {
          sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'O' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
        }

        this.opcionesSel = [];
        let campos = {accion: 100, sentencia: sentencia};  
        this.servicio.consultasBD(campos).subscribe( resp =>
        {
          this.opcionesSel = resp;  
        });
      }
    }  

    colocarOpciones()
    {
      let sentencia = ""
      if (this.detalle.rol == "A") 
      {
        sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, 1 AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
      }
      else if (this.detalle.rol == "G") 
      {
        sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'G' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
      }
      else if (this.detalle.rol == "S") 
      {
        sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'S' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
      }
      else if (this.detalle.rol == "T") 
      {
        sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'T' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
      }
      else if (this.detalle.rol == "O") 
      {
        sentencia = "SELECT id, CASE WHEN rol ='*' THEN '(Todos los roles)' WHEN rol = 'A' THEN 'ADMINISTRADOR' WHEN rol = 'G' THEN 'Gestor de la aplicación' WHEN rol = 'S' THEN 'Supervisor' WHEN rol = 'T' THEN 'Técnico' WHEN rol = 'O' THEN 'Operador' END AS erol, nombre, IF(rol = 'O' OR rol = '*', 1, 0) AS seleccionado FROM " + this.servicio.rBD() + ".int_opciones WHERE visualizar = 'S' ORDER BY seleccionado DESC, nombre"
      }

      this.opcionesSel = [];
      let campos = {accion: 100, sentencia: sentencia};  
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        this.opcionesSel = resp;  
      });
    }

  reiniciar()
  {
    let adicional: string = "";
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "480px", panelClass: 'dialogo', data: { titulo: "REINICIAR CONTRASEÑA", mensaje: "Esta acción reiniciará la contraseña del usuario seleccionado y la deberá cambiar en sl siguiente inicio de sesión<br><br><strong>¿Desea continuar con la operación?</strong>", id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Reiniciar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_grupos" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result)
        {
          if (result.accion == 1) 
          {
            let sentencia = "UPDATE " + this.servicio.rBD() + ".cat_usuarios SET inicializada = 'S' WHERE id = " + this.detalle.id;
            let campos = {accion: 200, sentencia: sentencia};  
            this.servicio.consultasBD(campos).subscribe( resp =>
            {
              
              this.detalle.inicializada = "S";
              let mensajeCompleto: any = [];
              mensajeCompleto.clase = "snack-normal";
              mensajeCompleto.mensaje = "La contraseña del usuario se ha inicializado";
              mensajeCompleto.tiempo = 2500;
              this.servicio.mensajeToast.emit(mensajeCompleto);
            })
          }
          else
          {
            let mensajeCompleto: any = [];
            mensajeCompleto.clase = "snack-error";
            mensajeCompleto.mensaje = "Acción cancelada por el usuario";
            mensajeCompleto.tiempo = 2000;
            this.servicio.mensajeToast.emit(mensajeCompleto);
          }
        }
        else
        {
          let mensajeCompleto: any = [];
          mensajeCompleto.clase = "snack-error";
          mensajeCompleto.mensaje = "Acción cancelada por el usuario";
          mensajeCompleto.tiempo = 2000;
          this.servicio.mensajeToast.emit(mensajeCompleto);
        }
      
    })
  }

  vista(id: number)
  {
    if (id==17)
    {
      this.vista17 = this.vista17 == 0 ? 1 : 0;
      if (this.vista17 == 0)
      {
        this.litVista17 = "Por equipo";
        this.icoVista17 = "i_maquina";
      }
      else
      {
        this.litVista17 = "Por rate";
        this.icoVista17 = "i_rates";
      }
      this.rRegistros(this.miSeleccion)
    }
  }

  filtrarParo()
  {
    if (this.miSeleccion==21)
    {
      const respuesta = this.dialogo.open(FiltroparoComponent, {
        width: "500px", panelClass: 'dialogo', data: { titulo: "Filtrar paro", tiempo: 0, mensaje: "Esta acción iniciará <strong>un paro no planeado</strong> en la máquina seleccionada.<br><br><strong>¿Qué desea hacer?</strong>", alto: "300", id: 0, accion: 0, botones: 2, boton1STR: "Iniciar paro", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_paro" }
      });
      respuesta.afterClosed().subscribe(result => {
        if (result.accion==1)
        {
          
          this.rRegistros(this.miSeleccion)
          return;
        }
        this.primeraVez = true;
        this.servicio.activarSpinner.emit(false);     
        this.servicio.activarSpinnerSmall.emit(false);
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "No se realizó ningún filtro";
        mensajeCompleto.tiempo = 1000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      })
    }
    else
    {
      const respuesta = this.dialogo.open(FiltrorechazoComponent, {
        width: "500px", panelClass: 'dialogo', data: { titulo: "Filtrar paro", tiempo: 0, mensaje: "Esta acción iniciará <strong>un paro no planeado</strong> en la máquina seleccionada.<br><br><strong>¿Qué desea hacer?</strong>", alto: "300", id: 0, accion: 0, botones: 2, boton1STR: "Iniciar paro", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_paro" }
      });
      respuesta.afterClosed().subscribe(result => {
        if (result.accion==1)
        {
          this.rRegistros(this.miSeleccion)
          return;
        }
        this.servicio.activarSpinner.emit(false);     
        this.servicio.activarSpinnerSmall.emit(false);
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-error";
        mensajeCompleto.mensaje = "No se realizó ningún filtro";
        mensajeCompleto.tiempo = 1000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
      })
    }
    
    
  }

  filtrarSubParo(filtro: number)
  {
    this.verSubParos = filtro;
    this.rRegistros(this.miSeleccion)
  }

  buscarIndice(index: number, item) {
    return item.id;
  }

  buscarLotes()
  {
    this.llenarListas(117, this.servicio.rBD() + ".lotes", "WHERE a.estatus = 'A' AND a.parte = " + +this.detalle.parte);
  }

  verMacros()
  {
    let mensajeTotal = "<strong>[0]</strong> Número del reporte.<br><strong>[1]</strong> Línea asociada.<br><strong>[2]</strong> Máquina asociada.<br><strong>[3]</strong> Área asociada.<br><strong>[4]</strong> Falla asociada.<br><strong>[5]</strong> Fecha y hora del mensaje.<br><br><strong>[11]</strong> Tiempo transcurrido.<br>";
    if (this.servicio.rVersion().modulos[5] == 1)
    {
      mensajeTotal = mensajeTotal + "<strong>[12]</strong> Indice del rate.<br><strong>[13]</strong> Indice del OAE.<br><br>";
    }
    mensajeTotal = mensajeTotal + "<strong>[20]</strong> Número de repetición.<br><strong>[30]</strong> Nivel de escalamiento.<br><strong>[31]</strong> Repeticiones escalamiento 1.<br><strong>[32]</strong> Repeticiones escalamiento 2.<br><strong>[33]</strong> Repeticiones escalamiento 3.<br><strong>[34]</strong> Repeticiones escalamiento 4.<br><strong>[35]</strong> Repeticiones escalamiento 5.<br>";
    if (this.servicio.rVersion().modulos[4] == 1)
    {
      mensajeTotal = mensajeTotal + "<strong>WIP general</strong><br><strong>[40]</strong> Proceso asociado.<br><strong>[41]</strong> Número de lote.<br><strong>[42]</strong> Referencia del Número de parte.<br><strong>[43]</strong> Descripción del Número de parte.<br><strong>[44]</strong> Operación asociada.<br><strong>[45]</strong> Secuencia de la operación en la ruta.<br><strong>Tiempo de stock excedido</strong><br><strong>[50]</strong> Fecha de entrada a stock.<br><strong>[51]</strong> Fecha estimada de salida.<br><strong>[52]</strong> Demora en el estado de stock.<br><strong>Tiempo de proceso excedido</strong><br><strong>[60]</strong> Operación desde.<br><strong>[61]</strong> Equipo asociado.<br><strong>[62]</strong> Fecha de entrada al proceso.<br><strong>[63]</strong> Fecha estimada de salida del proceso.<br><strong>[64]</strong> Demora en el proceso.<br><strong>Saltos de operación</strong><br><strong>[70]</strong> Operación desde.<br><strong>[71]</strong> Secuencia desde.<br><strong>[72]</strong> Operación hasta.<br><strong>[73]</strong> Secuencia hasta.<br><strong>Programación (cargas)</strong><br><strong>[80]</strong> Número de carga.<br><strong>[81]</strong> Fecha promesa.<br><strong>[82]</strong> Demora o retraso.<br><strong>[83]</strong> Hora anticipada.<br><strong>[84]</strong> Resolución de la carga.<br>";
    }
    mensajeTotal = mensajeTotal + "<strong>[90]</strong> Salto de línea (sólo correo).";
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "400px", panelClass: 'dialogo', data: { titulo: "Macros para mensajes de alerta", tiempo: -1, mensaje: mensajeTotal, alto: "300", id: 0, accion: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Volver a la edición", icono3: "i_edicion", icono0: "i_general" }
    });
  }

  defecto(id: number)
  {
    this.opcionesSel[id].defecto = this.opcionesSel[id].defecto == "S" ? "N" : "S";

    if (this.opcionesSel[id].defecto == "S")
    {
      for (var i = 0; i < this.opcionesSel.length; i++) 
      {
        if (i != id)
        {
          this.opcionesSel[i].defecto = "N"
        }
      }
    }
  }

  alarmar(id: number)
  {
    this.opcionesSel[id].alarmar = this.opcionesSel[id].alarmar == "S" ? "N" : "S";
  }

  subir(id: number)
  {
    this.opcionesSel.splice(id - 1, 0, this.opcionesSel[id])
    this.opcionesSel.splice(id + 1, 1);
    for (var i = 0; i < this.opcionesSel.length ; i++) 
    {
      this.opcionesSel[i].orden = i + 1;
    }
    let alfa: any;
    this.cambiando(alfa)
  }

  bajar(id: number)
  {
    this.opcionesSel.splice(id + 2, 0, this.opcionesSel[id])
    this.opcionesSel.splice(id, 1);
    for (var i = 0; i < this.opcionesSel.length ; i++) 
    {
      this.opcionesSel[i].orden = i + 1;
    }
    let alfa: any;
    this.cambiando(alfa)
  }

  inicializarValores()
  {
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "400px", panelClass: 'dialogo_atencion', data: { titulo: "INCIALIZAR LISTA DE VALORES", mensaje: "Esta acción inicializará la lista de valores de esta variable<br><br><strong>¿Desea continuar?</strong>", id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Inicializar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_inactivar" }
    });
    respuesta.afterClosed().subscribe(result => 
    {
      if (result)
        {
          if (result.accion == 1) 
          {
            this.opcionesSel = [];
            let alfa: any;
            this.cambiando(alfa)
          }
        }
    })
  }

  agregarValor()
  {
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "400px", panelClass: 'dialogo', data: { agregarValor: 1, totalValores: this.opcionesSel.length, orden: -1, titulo: "AGREGAR VALOR A VARIABLE", mensaje: "", id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "i_variables" }
    });
    respuesta.afterClosed().subscribe(result => 
      {
        if (result)
          {
            if (result.accion == 1) 
            {
              let posicion = this.opcionesSel.length + 1;
              if (result.orden > 1)
              {
                posicion = result.orden;
                for (var i = posicion - 1; i < this.opcionesSel.length; i++) 
                {
                  this.opcionesSel[i].orden = +this.opcionesSel[i].orden + 1;
                }
              }
              else if (result.orden == 0)
              {
                posicion = 1;
                for (var i = 0; i < this.opcionesSel.length; i++) 
                {
                  this.opcionesSel[i].orden = +this.opcionesSel[i].orden + 1;
                }
              }
              this.opcionesSel.splice(posicion - 1, 0, {orden: posicion, equipo: 0, variable: this.detalle.id, alarmar: "N", defecto: "N", valor: result.valorVariable });
              let alfa: any;
              this.cambiando(alfa)
            }
          }
      })
  }

  modificarValor(id: number)
  {
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "400px", panelClass: 'dialogo', data: { valorVariable: this.opcionesSel[id].valor, agregarValor: 2, totalValores: this.opcionesSel.length, orden: id, titulo: "MODIFICAR VALOR A VARIABLE", mensaje: "", id: 0, accion: 0, tiempo: 0, botones: 3, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Quitar", icono3: "i_eliminar", icono0: "i_variables" }
    });
    respuesta.afterClosed().subscribe(result => 
      {
        if (result)
          {
            if (result.accion == 1) 
            {
              if (result.orden == 0 && id == 0 || result.orden == 1 && id == this.opcionesSel.length - 1 || result.orden > 1 && result.orden == id + 1)
              {
                this.opcionesSel[id].valor = result.valorVariable;
              }
              else
              {
                this.opcionesSel.splice(id, 1);
                let posicion = this.opcionesSel.length + 1;
                if (result.orden > 1)
                {
                  posicion = result.orden;
                }
                else if (result.orden == 0)
                {
                  posicion = 1;
                }
                this.opcionesSel.splice(posicion - 1, 0, {orden: posicion, equipo: 0, variable: this.detalle.id, alarmar: "N", defecto: "N", valor: result.valorVariable });
                for (var i = 0; i < this.opcionesSel.length; i++) 
                {
                  this.opcionesSel[i].orden = i + 1;
                }
                
              }
              let alfa: any;
              this.cambiando(alfa)
            }
            else if (result.accion == 3) 
            {
              this.opcionesSel.splice(id, 1);
              if (id < this.opcionesSel.length)
              {
                for (var i = id; i < this.opcionesSel.length + 1; i++) 
                {
                  if (i < this.opcionesSel.length)
                  {
                    this.opcionesSel[i].orden = i + 1;
                  }
                }
              }
              let alfa: any;
              this.cambiando(alfa)
            }
          }
      })
  }

  iniVariable(id: number)
  {
    const respuesta = this.dialogo.open(DialogoComponent, {
      width: "400px", panelClass: 'dialogo', data: { valorVariable: this.detalle.van, modificarVan: true, totalValores: this.opcionesSel.length, orden: id, titulo: "VALOR ACTUAL DE VARIABLE", mensaje: "", id: 0, accion: 0, tiempo: 0, botones: 2, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", boton3STR: "Quitar", icono3: "i_eliminar", icono0: "i_variables" }
    });
    respuesta.afterClosed().subscribe(result => 
      {
        if (result)
          {
            if (result.accion == 1) 
            {
              if (result.valorVariable >= +this.detalle.tope)
              {
                let mensajeCompleto: any = [];
                mensajeCompleto.clase = "snack-error";
                mensajeCompleto.mensaje = "El valor ingresado sobrecarga la variable";
                mensajeCompleto.tiempo = 4000;
                this.servicio.mensajeToast.emit(mensajeCompleto);
              }
              else
              {
                let mensajeCompleto: any = [];
                mensajeCompleto.clase = "snack-normal";
                mensajeCompleto.mensaje = "Se ha cambiado el valor actual acumulado de la variable";
                mensajeCompleto.tiempo = 4000;
                this.servicio.mensajeToast.emit(mensajeCompleto);
              }
              this.detalle.van = result.valorVariable; 
              let alfa: any;
              this.cambiando(alfa)
            }
          }
      })
  }

  buscarListas(id: number)
  {
    let sentencia = "SELECT id FROM " + this.servicio.rBD() + ".lotes WHERE numero = '" + this.detalle.orden + "' AND estatus = 'A'";
    
    if (id == 0)
    {
      this.detalle.lote = 0;
    }
    if (id == 1)
    {
      sentencia = "SELECT dia AS fecha FROM " + this.servicio.rBD() + ".lecturas_cortes WHERE orden = " + this.detalle.lote + " AND equipo = " + this.detalle.equipo + " GROUP BY fecha ORDER BY fecha ";
      this.fechasLote = [];
    }
    else if (id == 2)
    {
      if ((this.detalle.fecha).length != 10)
      {
        this.detalle.fecha = this.datepipe.transform(this.detalle.fecha, "yyyy/MM/dd");
      }
      let miFecha = this.servicio.fecha(2, this.detalle.fecha + " 10:00:00", "yyyy/MM/dd");
      
      this.turnosLote = [];
      sentencia = "SELECT a.turno AS id, b.nombre FROM " + this.servicio.rBD() + ".lecturas_cortes a LEFT JOIN " + this.servicio.rBD() + ".cat_turnos b ON a.turno = b.id WHERE a.orden = " + this.detalle.lote + " AND equipo = " + this.detalle.equipo + " AND dia = '" + miFecha + "' GROUP BY id, b.nombre ORDER BY b.nombre ";
    }
    else if (id == 3)
    {
      this.maquinas = [];
      sentencia = "SELECT a.equipo AS id,  IF(ISNULL(c.nombre), b.nombre, CONCAT(b.nombre, ' / ', c.nombre)) AS nombre FROM " + this.servicio.rBD() + ".lecturas_cortes a LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas b ON a.equipo = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_lineas c ON b.linea = c.id WHERE a.orden = " + this.detalle.lote + " GROUP BY id, b.nombre ORDER BY b.nombre ";
    }
    else if (id == 4)
    {
      this.partes = [];
      sentencia = "SELECT a.parte AS id, IF(ISNULL(b.referencia), b.nombre, CONCAT(b.nombre, ' (Ref: ', b.referencia, ')')) AS nombre FROM " + this.servicio.rBD() + ".lecturas_cortes a LEFT JOIN " + this.servicio.rBD() + ".cat_partes b ON a.parte = b.id WHERE a.orden = " + this.detalle.lote + " GROUP BY id, nombre ORDER BY nombre ";
    }
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        if (id == 0)
        {
          this.detalle.lote = resp[0].id;
          this.buscarListas(4)
                    
        }
        if (id == 1)
        {
          for (var i = 0; i < resp.length; i++) 
          {
            this.fechasLote.push({ fecha: this.servicio.fecha(2, resp[i].fecha + " 10:00:00", "yyyy/MM/dd") });
          }
          ;
          if (resp.length == 1)
          {
            this.detalle.fecha = this.servicio.fecha(2, resp[0].fecha + " 10:00:00", "yyyy/MM/dd");
            this.buscarListas(2);
          }
          else if (this.editando)
          {
            this.detalle.fecha = "0";
            this.detalle.turno = "0";
          }
          else
          {
            this.buscarListas(2);
          }
        }
        else if  (id == 2)
        {
          this.turnosLote = resp;
          if (resp.length == 1)
          {
            this.detalle.turno = resp[0].id; 
          }
          else if (this.editando)
          {
            this.detalle.turno = "0";
          }
          else
          {
            this.detalle.campos = this.servicio.fecha(2, this.detalle.fecha, "yyyy/MM/dd") + ";" + this.detalle.equipo + ";" + this.detalle.parte + ";" + this.detalle.turno + ";" + this.detalle.lote;
          }
        }
        else if  (id == 3)
        {
          this.maquinas = resp;
          if (resp.length == 1)
          {
            this.detalle.equipo = resp[0].id; 
            this.buscarListas(1);
          }
          else if (this.editando)
          {
            this.detalle.equipo = "0";
            this.detalle.fecha = "0";
            this.detalle.turno = "0";
          }
          else
          {
            this.buscarListas(1);
            
          }
        }
        else if  (id == 4)
        {
          this.partes = resp;
          if (resp.length == 1)
          {
            this.detalle.parte = resp[0].id; 
            this.buscarListas(3);
          }
          else if (this.editando)
          {
            this.detalle.parte = "0";
            this.detalle.equipo = "0";
            this.detalle.fecha = "0";
            this.detalle.turno = "0";
          }
        }
      }
      else
      {
        this.detalle.lote = 0;
        this.detalle.parte = "0";
        this.detalle.equipo = "0";
        this.detalle.fecha = "0";
        this.detalle.turno = "0";
      }
    });
  }

  iniListas()
  {
    this.turnosLote = [];
    this.fechasLote = [];
    this.detalle.lote = "0";
    this.detalle.parte = "0";
    this.detalle.equipo = "0";
    this.detalle.fecha = "0";
    this.detalle.turno = "0";
  }

}

