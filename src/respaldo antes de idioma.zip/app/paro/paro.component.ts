import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { ServicioService } from '../servicio/servicio.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-paro',
  templateUrl: './paro.component.html',
  styleUrls: ['./paro.component.css']
})
export class ParoComponent implements OnInit {

  @ViewChild("txtNotas", { static: false }) txtNotas: ElementRef;

  conceptos = [];
  areas = [];
  movil: boolean = false;
  validar01: boolean = false;
  validar02: boolean = false;
  validar03: boolean = false;
  tipoResumen: string = "";

  constructor(
    public servicio: ServicioService,
    public dialogRef: MatDialogRef<ParoComponent>, 
    @Inject(MAT_DIALOG_DATA) public datos: any
  ) 
  {
    
  }

  ngOnInit() {
    this.carrusel();
  }

  carrusel()
 {
    let sentencia = "SELECT id, nombre FROM " + this.servicio.rBD() + ".cat_generales WHERE tabla = 45 AND url_mmcall = 'S' AND estatus = 'A' ORDER BY nombre;"
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.conceptos = resp;
      }
    });
    sentencia = "SELECT id, nombre FROM " + this.servicio.rBD() + ".cat_areas WHERE estatus = 'A' ORDER BY nombre;"
    campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.areas = resp;
      }
    })

    if (this.datos.accion==0)
   {
    this.datos.finaliza_sensor = "S";
    this.datos.tiempo = "0";
    this.datos.paro = "PARO MANUAL (USUARIO)"
    this.calcularHR(0);
    this.datos.notas = "";
   }
   else
   {
    let sentencia = "SELECT paro, area, tipo, notas, tiempo, finaliza_sensor FROM " + this.servicio.rBD() + ".detalleparos WHERE id = " + this.datos.accion;
    let campos = {accion: 100, sentencia: sentencia};  
    this.servicio.consultasBD(campos).subscribe( resp =>
    {
      if (resp.length > 0)
      {
        this.datos.finaliza_sensor = resp[0].finaliza_sensor;
        this.datos.tiempo = +resp[0].tiempo;
        this.datos.paro = resp[0].paro;
        this.datos.notas = resp[0].notas;
        this.datos.area = resp[0].area;
        this.datos.concepto = resp[0].tipo;
        this.calcularHR(+this.datos.tiempo);
        setTimeout(() => {
          this.txtNotas.nativeElement.focus();
        }, 100);
      }
    });
    
   }


  }


  validar(id: number)
  {
    this.datos.accion = id;
    this.dialogRef.close(this.datos);
  }

  
  calcularHR(segundos: number)
  {
    let cadHora = "";
    if (!segundos)
    {
      cadHora = "";
    }
    else if (segundos == 0)
    {
      cadHora = "0min";
    }
    else if (segundos > 0 && segundos <= 60)
    {
      cadHora = "1min";
    }
    else if ((segundos / 3600) < 1)
    {
      cadHora = (segundos / 60).toFixed(1) + "min" 
    }
    else
    {
      cadHora = (segundos / 3600).toFixed(2) + "hr" 
    }
    return cadHora
  }



}


