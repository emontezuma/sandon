import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { ServicioService } from '../servicio/servicio.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { DialogoComponent } from '../dialogo/dialogo.component';

@Component({
  selector: 'app-contabiliza',
  templateUrl: './contabiliza.component.html',
  styleUrls: ['./contabiliza.component.css']
})
export class ContabilizaComponent implements OnInit {

  @ViewChild("txtT1", { static: false }) txtT1: ElementRef;

  clave: string = "";
  licencia: string = "";
  movil: boolean = false;
  validar01: boolean = false;
  validar02: boolean = false;
  validar03: boolean = false;
  encontrado: boolean = false;
  sioNo: string = "";
  reporte: number = null;
  detalle: any = {fecha_reporte: "-", nsolicitante: "-", nmaquina: "-", nfalla: "-", nestatus: "-", contabilizar: ""};
  tituloBoton: string = "NO afectar indicadores";
  

  constructor(
    public servicio: ServicioService,
    public dialogo: MatDialog, 
    public dialogRef: MatDialogRef<ContabilizaComponent>, 
    @Inject(MAT_DIALOG_DATA) public datos: any
  ) 
  {
    
  }

  ngOnInit() {
  }

  validar(id: number)
  {
    if (id == 1)
    {
      let sentencia = "UPDATE " + this.servicio.rBD() + ".reportes SET contabilizar = IF(contabilizar = 'S', 'N', 'S'), contabilizar_fecha = NOW(), contabilizar_usuario = " + this.servicio.rUsuario().id + " WHERE id = " + this.reporte;
      let campos = {accion: 200, sentencia: sentencia};
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        this.reporte = null;
        let mensaje = "El reporte ya se puede contabilizar";
        if (this.tituloBoton == "NO afectar indicadores")
        {
          mensaje = "El reporte ya no afecta  los indicadores";
        }
        this.detalle = {fecha_reporte: "-", nsolicitante: "-", nmaquina: "-", nfalla: "-", nestatus: "-", contabilizar: ""};
        this.tituloBoton = "NO afectar indicadores";
        this.encontrado = false;
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-normal"
        if (mensaje == "El reporte ya no afecta  los indicadores")
        {
          mensajeCompleto.clase = "snack-error"
        }
        this.validar01 = false;
        this.validar02 = false;
        mensajeCompleto.mensaje = mensaje;
        mensajeCompleto.tiempo = 2000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
        setTimeout(() => {
          this.txtT1.nativeElement.focus();  
        }, 100);
        
      });
    }
    else
    {
      this.datos.accion = id;
      this.dialogRef.close(this.datos);
    }
  }


buscarReporte()
{
  let sentencia = "SELECT c.id, c.contabilizar_fecha, IFNULL(i.nombre, 'N/A') AS ncambio, c.contabilizar, c.fecha_reporte, IF(c.estatus = 0, 'Sin atender', IF(c.estatus = 10, 'En reparacion', IF(c.estatus = 100, 'Por documentar', 'Cerrado'))) AS nestatus, IFNULL(e.nombre, 'N/A') AS nsolicitante, c.estatus, IFNULL(a.nombre, 'N/A') AS nlinea, IFNULL(g.nombre, 'N/A') AS nmaquina, IFNULL(d.nombre, 'N/A') AS narea,  IFNULL(h.nombre, 'N/A') AS nfalla, IFNULL(f.nombre, 'N/A') AS ntecnico FROM " + this.servicio.rBD() + ".reportes c LEFT JOIN " + this.servicio.rBD() + ".cat_lineas a ON c.linea = a.id LEFT JOIN " + this.servicio.rBD() + ".cat_areas d ON c.area = d.id LEFT JOIN " + this.servicio.rBD() + ".cat_maquinas g ON c.maquina = g.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios e ON c.solicitante = e.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios f ON c.tecnico = f.id LEFT JOIN " + this.servicio.rBD() + ".cat_usuarios i ON c.contabilizar_usuario = i.id LEFT JOIN " + this.servicio.rBD() + ".cat_fallas h ON c.falla_ajustada = h.id WHERE c.id = " + this.reporte;
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe( resp =>
  {
    if (resp.length > 0)
    {
      if (resp[0].estatus < 1000)
      {
        
        const respuesta = this.dialogo.open(DialogoComponent, {
          width: "430px", panelClass:  'dialogo_atencion', data: { titulo: "Operacion inválida", mensaje: "Antes de inactivar el reporte, éste debe estar cerrado y documentado, por favor contacte a las áreas involucraas para que completen el reporte y luego proceda con su inactivación.<br><br>Este reporte está en estatus de <strong>" + resp[0].nestatus + "</strong>", alto: "40", id: 0, accion: 0, tiempo: 0, botones: 1, boton1STR: "Aceptar", icono1: "in_seleccionado", boton2STR: "Cancelar", icono2: "i_cancelar", icono0: "in_detener" }
        });
        return;
      }

      this.encontrado = true;
      this.detalle = resp[0];
      this.sioNo = resp[0].contabilizar=="S" ? "SI" : "NO"
      if (resp[0].contabilizar == "S")
      {
        this.tituloBoton = "NO afectar indicadores";
      }
      else
      {
        this.tituloBoton = "Afectar indicadores";
      }

    }
    else
    {
      let mensajeCompleto: any = [];
      mensajeCompleto.clase = "snack-normal";
      mensajeCompleto.mensaje = "Este reporte no existe";
      mensajeCompleto.tiempo = 2000;
      this.servicio.mensajeToast.emit(mensajeCompleto);
      this.detalle = {fecha_reporte: "-", nsolicitante: "-", nmaquina: "-", nfalla: "-", nestatus: "-", contabilizar: ""};
      this.tituloBoton = "NO afectar indicadores";
      this.encontrado = false;
    }
  })
}

iniReporte()
{
  this.detalle = {fecha_reporte: "-", nsolicitante: "-", nmaquina: "-", nfalla: "-", nestatus: "-", contabilizar: ""};
  this.tituloBoton = "NO afectar indicadores";
  this.encontrado = false;
}

}
