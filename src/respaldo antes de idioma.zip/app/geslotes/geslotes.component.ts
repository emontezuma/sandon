import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { ServicioService } from '../servicio/servicio.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-geslotes',
  templateUrl: './geslotes.component.html',
  styleUrls: ['./geslotes.component.css']
})
export class GeslotesComponent implements OnInit {

  @ViewChild("txtT1", { static: false }) txtT1: ElementRef;

  clave: string = "";
  licencia: string = "";
  movil: boolean = false;
  validar01: boolean = false;
  validar02: boolean = false;
  validar03: boolean = false;
  encontrado: boolean = false;
  sioNo: string = "";
  reporte: number = null;
  detalle: any = {ruta_secuencia: "-", estatus: "-", referencia: "-", nombre: "-", nproceso: "-"};
  tituloBoton: string = "Inactivar lote";
  

  constructor(
    public servicio: ServicioService,
    public dialogRef: MatDialogRef<GeslotesComponent>, 
    @Inject(MAT_DIALOG_DATA) public datos: any
  ) 
  {
    
  }

  ngOnInit() {
  }

  validar(id: number)
  {
    if (id == 1)
    {
      let sentencia = "UPDATE " + this.servicio.rBD() + ".lotes SET estatus = '" + (this.tituloBoton == "Inactivar lote" ? "I" : "A") + "' WHERE numero = '" + this.reporte + "'";
      let campos = {accion: 200, sentencia: sentencia};
      this.servicio.consultasBD(campos).subscribe( resp =>
      {
        this.reporte = null;
        let mensaje = "El lote ya se puede utilizar";
        if (this.tituloBoton == "Inactivar lote")
        {
          mensaje = "El lote ya no se puede utilizar";
        }
        this.detalle = {ruta_secuencia: "-", estatus: "-", referencia: "-", nombre: "-", nproceso: "-"};
        this.tituloBoton = "Inactivar lote";
        this.encontrado = false;
        let mensajeCompleto: any = [];
        mensajeCompleto.clase = "snack-normal"
        if (mensaje == "El lote ya no se puede utilizar")
        {
          mensajeCompleto.clase = "snack-error"
        }
        this.validar01 = false;
        this.validar02 = false;
        mensajeCompleto.mensaje = mensaje;
        mensajeCompleto.tiempo = 2000;
        this.servicio.mensajeToast.emit(mensajeCompleto);
        setTimeout(() => {
          this.txtT1.nativeElement.focus();  
        }, 100);
        
      });
    }
    else
    {
      this.datos.accion = id;
      this.dialogRef.close(this.datos);
    }
  }


buscarReporte()
{
  let sentencia = "SELECT a.estatus, a.ruta_secuencia, IFNULL(b.referencia, 'N/A') AS referencia, IFNULL(b.nombre, 'N/A') AS nombre, IFNULL(c.nombre, 'N/A') AS nproceso FROM " + this.servicio.rBD() + ".lotes a LEFT JOIN " + this.servicio.rBD() + ".cat_partes b ON a.parte = b.id LEFT JOIN " + this.servicio.rBD() + ".cat_procesos c ON a.proceso = c.id WHERE a.numero = '" + this.reporte + "'";
  let campos = {accion: 100, sentencia: sentencia};  
  this.servicio.consultasBD(campos).subscribe( resp =>
  {
    if (resp.length > 0)
    {
      this.encontrado = true;
      this.detalle = resp[0];
      this.sioNo = resp[0].estatus == "S" ? "SI" : "NO"
      if (resp[0].estatus == "A")
      {
        this.tituloBoton = "Inactivar lote";
      }
      else
      {
        this.tituloBoton = "Reactivar lote";
      }

    }
    else
    {
      let mensajeCompleto: any = [];
      mensajeCompleto.clase = "snack-normal";
      mensajeCompleto.mensaje = "Este lote no existe";
      mensajeCompleto.tiempo = 2000;
      this.servicio.mensajeToast.emit(mensajeCompleto);
      this.detalle = {ruta_secuencia: "-", estatus: "-", referencia: "-", nombre: "-", nproceso: "-"};
      this.tituloBoton = "Inactivar lote";
      this.encontrado = false;
    }
  })
}

iniReporte()
{
  this.detalle = {ruta_secuencia: "-", estatus: "-", referencia: "-", nombre: "-", nproceso: "-"};
  this.tituloBoton = "Inactivar lote";
  this.encontrado = false;
}

}
